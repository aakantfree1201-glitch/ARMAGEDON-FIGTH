/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { CharacterConfig, Move, GameSettings } from '../types';
import { Sparkles, Image as ImageIcon, Plus, Trash2, BookOpen, AlertTriangle, Play, CheckCircle, Upload, HelpCircle, Target, Eye, EyeOff, Grid, RefreshCw, Database, Download, Copy, FileJson } from 'lucide-react';
import audioSynth from '../audio';
import { HitboxCanvasPreview } from './HitboxCanvasPreview';
import { defaultCharacters } from '../characters';

// Custom character sprite/background helper interface
interface SpriteStateBoxProps {
  label: string;
  labelEn: string;
  subLabel: string;
  value: string | string[] | undefined;
  onChange: (val: string[] | string | undefined) => void;
}

const SpriteStateBox: React.FC<SpriteStateBoxProps> = ({
  label,
  labelEn,
  subLabel,
  value,
  onChange
}) => {
  const [currentFrameIdx, setCurrentFrameIdx] = useState(0);
  const [rawText, setRawText] = useState('');

  const frames = Array.isArray(value) ? value : value ? [value] : [];

  // Looping animation effect for preview
  React.useEffect(() => {
    if (frames.length <= 1) return;
    const interval = setInterval(() => {
      setCurrentFrameIdx((prev) => (prev + 1) % frames.length);
    }, 150);
    return () => clearInterval(interval);
  }, [frames.length]);

  // Sync rawText with value when value changes externally
  React.useEffect(() => {
    if (Array.isArray(value)) {
      setRawText(value.join('\n'));
    } else if (value) {
      setRawText(value);
    } else {
      setRawText('');
    }
  }, [value]);

  const handleFiles = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []) as File[];
    if (files.length === 0) return;

    // Sort files numerically/alphabetically
    files.sort((a, b) => a.name.localeCompare(b.name, undefined, { numeric: true, sensitivity: 'base' }));

    const promises = files.map(file => {
      return new Promise<string>((resolve) => {
        const reader = new FileReader();
        reader.onload = (ev) => {
          resolve(ev.target?.result as string || '');
        };
        reader.readAsDataURL(file);
      });
    });

    Promise.all(promises).then((results) => {
      const filtered = results.filter(r => r !== '');
      onChange(filtered);
    });
  };

  const handleTextChange = (text: string) => {
    setRawText(text);
    const lines = text.split('\n').map(l => l.trim()).filter(l => l.length > 0);
    if (lines.length === 0) {
      onChange(undefined);
    } else if (lines.length === 1) {
      onChange(lines[0]);
    } else {
      onChange(lines);
    }
  };

  return (
    <div className="bg-slate-900/40 p-4 rounded-xl border border-slate-800/80 flex flex-col gap-3 relative text-right" dir="rtl">
      <div className="flex justify-between items-start gap-2 flex-row-reverse">
        <div className="text-right">
          <span className="text-xs font-bold text-cyan-400 block">{label}</span>
          <span className="text-[10px] text-slate-500 font-mono block">{labelEn}</span>
        </div>
        {frames.length > 0 && (
          <span className="text-[9px] bg-cyan-950 text-cyan-400 px-2 py-0.5 rounded font-mono font-bold">
            {frames.length} {frames.length > 1 ? 'فریم' : 'فریم'}
          </span>
        )}
      </div>

      {/* Preview Container */}
      <div className="relative w-full aspect-square max-h-36 bg-slate-950 rounded-lg flex items-center justify-center overflow-hidden border border-slate-800">
        {frames.length > 0 ? (
          <>
            <img 
              src={frames[currentFrameIdx % frames.length]} 
              alt={label} 
              referrerPolicy="no-referrer"
              className="h-full object-contain" 
            />
            <button
              type="button"
              onClick={() => onChange(undefined)}
              className="absolute top-1.5 right-1.5 bg-red-500/80 hover:bg-red-500 text-white rounded-full p-1 transition z-10"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
            {frames.length > 1 && (
              <div className="absolute bottom-1.5 left-1/2 -translate-x-1/2 bg-black/60 px-2 py-0.5 rounded text-[8px] text-slate-300 font-mono">
                Frame {currentFrameIdx + 1}/{frames.length}
              </div>
            )}
          </>
        ) : (
          <div className="flex flex-col items-center justify-center p-3 text-center gap-1.5 text-slate-500">
            <Upload className="w-6 h-6" />
            <span className="text-[10px] text-slate-400">تصویری ثبت نشده</span>
            <span className="text-[8px] text-slate-600">از دکمه آپلود یا جعبه متنی زیر استفاده کنید</span>
          </div>
        )}
      </div>

      {/* Upload and Paste controllers */}
      <div className="flex flex-col gap-2 mt-1">
        {/* File input (Supports Multiple) */}
        <label className="bg-slate-950 hover:bg-slate-900 border border-slate-800 hover:border-slate-700 text-slate-300 py-1.5 px-3 rounded-lg text-xs cursor-pointer active:scale-95 transition text-center flex items-center justify-center gap-1.5">
          <Upload className="w-3.5 h-3.5" />
          <span>بارگذاری فریم‌ها (تکی یا گروهی)</span>
          <input
            type="file"
            multiple
            accept="image/*"
            className="hidden"
            onChange={handleFiles}
          />
        </label>

        {/* Text Area for URL pasting */}
        <div className="flex flex-col gap-1">
          <label className="text-[9px] text-slate-500">یا لینک‌های آپلود شده را وارد کنید (هر لینک در یک خط):</label>
          <textarea
            rows={2}
            value={rawText}
            onChange={(e) => handleTextChange(e.target.value)}
            placeholder="https://example.com/frame1.png&#10;https://example.com/frame2.png"
            className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-[10px] font-mono text-slate-300 outline-none focus:border-cyan-500/60 leading-relaxed resize-y min-h-[50px] text-left"
            dir="ltr"
          />
        </div>
        <span className="text-[9px] text-slate-500 font-mono text-center block mt-0.5">{subLabel}</span>
      </div>
    </div>
  );
};

interface AssetManagerProps {
  characters: CharacterConfig[];
  onUpdateCharacters: (chars: CharacterConfig[]) => void;
  settings: GameSettings;
  onUpdateSettings: (settings: GameSettings) => void;
}

export const AssetManager: React.FC<AssetManagerProps> = ({
  characters,
  onUpdateCharacters,
  settings,
  onUpdateSettings,
}) => {
  const [activeTab, setActiveTab] = useState<'guide' | 'customize' | 'background' | 'hitbox' | 'database'>('guide');
  const [editCharId, setEditCharId] = useState<string>(characters[0]?.id || '');
  const [dragActive, setDragActive] = useState(false);

  const handleAddNewCharacter = () => {
    const id = `custom_${Date.now()}`;
    const newChar: CharacterConfig = {
      id,
      name: `Fighter ${characters.length + 1}`,
      nameFa: `رزمجو ${characters.length + 1}`,
      avatar: '🥋',
      avatarColor: '#10b981',
      speed: 4,
      maxHealth: 100,
      customWidth: 60,
      customHeight: 115,
      customFloorOffset: 0,
      hitboxConfig: {
        hurtboxWidthPercent: 100,
        hurtboxHeightPercent: 100,
        hurtboxOffsetX: 0,
        hurtboxOffsetY: 0,
        punchRange: 65,
        punchHeight: 50,
        punchOffsetY: 15,
        kickRange: 75,
        kickHeight: 50,
        kickOffsetY: 35,
      },
      sprites: {
        idle: [{ x: 0, y: 0, width: 55, height: 115, color: '#10b981' }],
        walk: [{ x: 0, y: 0, width: 55, height: 115, color: '#059669' }],
        jump: [{ x: 0, y: 0, width: 55, height: 105, color: '#047857' }],
        punch: [{ x: 0, y: 0, width: 75, height: 115, color: '#10b981' }],
        kick: [{ x: 0, y: 0, width: 85, height: 115, color: '#10b981' }],
        special: [{ x: 0, y: 0, width: 80, height: 115, color: '#059669' }],
        hit: [{ x: 0, y: 0, width: 55, height: 115, color: '#ef4444' }],
        block: [{ x: 0, y: 0, width: 50, height: 115, color: '#eab308' }],
        ko: [{ x: 0, y: 0, width: 115, height: 45, color: '#7f1d1d' }],
      },
      moves: [
        { id: 'punch', name: 'Punch Strike', type: 'punch', damage: 8, range: 65, cooldown: 12, duration: 12, key: 'F', isSpecial: false, color: '#10b981' },
        { id: 'kick', name: 'Kick Smash', type: 'kick', damage: 14, range: 75, cooldown: 20, duration: 16, key: 'G', isSpecial: false, color: '#eab308' },
      ],
    };
    onUpdateCharacters([...characters, newChar]);
    setEditCharId(id);
    audioSynth.playAnnouncer('select');
  };

  const handleDeleteCharacter = () => {
    if (characters.length <= 2) {
      alert("حداقل دو کاراکتر برای بازی الزامی است!");
      return;
    }
    const filtered = characters.filter(c => c.id !== editCharId);
    onUpdateCharacters(filtered);
    setEditCharId(filtered[0].id);
    audioSynth.playAnnouncer('select');
  };

  const handleResetDatabase = () => {
    if (window.confirm("آیا مطمئن هستید که می‌خواهید کل دیتابیس کاراکترها را به حالت اولیه بازنشانی کنید؟ تمام شخصی‌سازی‌های شما پاک خواهند شد.")) {
      localStorage.removeItem('retro_fighter_characters');
      onUpdateCharacters(defaultCharacters);
      setEditCharId(defaultCharacters[0].id);
      audioSynth.playAnnouncer('fight');
      alert("دیتابیس کاراکترها به حالت اولیه بازنشانی شد!");
    }
  };

  // Character editing fields
  const activeChar = characters.find(c => c.id === editCharId) || characters[0];
  const [newName, setNewName] = useState(activeChar?.name || '');
  const [newNameFa, setNewNameFa] = useState(activeChar?.nameFa || '');
  const [newAvatar, setNewAvatar] = useState(activeChar?.avatar || '🥋');
  const [newColor, setNewColor] = useState(activeChar?.avatarColor || '#ff4500');
  const [newSpeed, setNewSpeed] = useState(activeChar?.speed || 4);
  const [newHealth, setNewHealth] = useState(activeChar?.maxHealth || 100);
  const [newWidth, setNewWidth] = useState(activeChar?.customWidth || 60);
  const [newHeight, setNewHeight] = useState(activeChar?.customHeight || 115);
  const [newFloorOffset, setNewFloorOffset] = useState(activeChar?.customFloorOffset || 0);
  const [newMenuPortrait, setNewMenuPortrait] = useState<string | undefined>(activeChar?.menuPortrait);

  // Hitbox settings state
  const [hurtboxWidthPercent, setHurtboxWidthPercent] = useState(100);
  const [hurtboxHeightPercent, setHurtboxHeightPercent] = useState(100);
  const [hurtboxOffsetX, setHurtboxOffsetX] = useState(0);
  const [hurtboxOffsetY, setHurtboxOffsetY] = useState(0);

  const [punchRange, setPunchRange] = useState(65);
  const [punchHeight, setPunchHeight] = useState(50);
  const [punchOffsetY, setPunchOffsetY] = useState(15);

  const [kickRange, setKickRange] = useState(75);
  const [kickHeight, setKickHeight] = useState(50);
  const [kickOffsetY, setKickOffsetY] = useState(35);

  const [previewState, setPreviewState] = useState<'idle' | 'walk' | 'punch' | 'kick' | 'block' | 'hit' | 'ko'>('idle');
  const [previewDirection, setPreviewDirection] = useState<1 | -1>(1);
  const [showGrid, setShowGrid] = useState<boolean>(true);

  const [spriteIdle, setSpriteIdle] = useState<string | string[] | undefined>(activeChar?.customSprites?.idle);
  const [spriteWalk, setSpriteWalk] = useState<string | string[] | undefined>(activeChar?.customSprites?.walk);
  const [spriteJump, setSpriteJump] = useState<string | string[] | undefined>(activeChar?.customSprites?.jump);
  const [spritePunch, setSpritePunch] = useState<string | string[] | undefined>(activeChar?.customSprites?.punch);
  const [spriteKick, setSpriteKick] = useState<string | string[] | undefined>(activeChar?.customSprites?.kick);
  const [spriteSpecial, setSpriteSpecial] = useState<string | string[] | undefined>(activeChar?.customSprites?.special);
  const [spriteHit, setSpriteHit] = useState<string | string[] | undefined>(activeChar?.customSprites?.hit);
  const [spriteBlock, setSpriteBlock] = useState<string | string[] | undefined>(activeChar?.customSprites?.block);
  const [spriteKo, setSpriteKo] = useState<string | string[] | undefined>(activeChar?.customSprites?.ko);

  // Sync edits when character changes
  React.useEffect(() => {
    if (activeChar) {
      setNewName(activeChar.name);
      setNewNameFa(activeChar.nameFa);
      setNewAvatar(activeChar.avatar);
      setNewColor(activeChar.avatarColor);
      setNewSpeed(activeChar.speed);
      setNewHealth(activeChar.maxHealth);
      setNewWidth(activeChar.customWidth || 60);
      setNewHeight(activeChar.customHeight || 115);
      setNewFloorOffset(activeChar.customFloorOffset || 0);
      setNewMenuPortrait(activeChar.menuPortrait);
      setSpriteIdle(activeChar.customSprites?.idle);
      setSpriteWalk(activeChar.customSprites?.walk);
      setSpriteJump(activeChar.customSprites?.jump);
      setSpritePunch(activeChar.customSprites?.punch);
      setSpriteKick(activeChar.customSprites?.kick);
      setSpriteBlock(activeChar.customSprites?.block);
      setSpriteHit(activeChar.customSprites?.hit);
      setSpriteSpecial(activeChar.customSprites?.special);
      setSpriteKo(activeChar.customSprites?.ko);

      // Sync hitboxes
      const hc = activeChar.hitboxConfig || {
        hurtboxWidthPercent: 100,
        hurtboxHeightPercent: 100,
        hurtboxOffsetX: 0,
        hurtboxOffsetY: 0,
        punchRange: 65,
        punchHeight: 50,
        punchOffsetY: 15,
        kickRange: 75,
        kickHeight: 50,
        kickOffsetY: 35,
      };
      setHurtboxWidthPercent(hc.hurtboxWidthPercent);
      setHurtboxHeightPercent(hc.hurtboxHeightPercent);
      setHurtboxOffsetX(hc.hurtboxOffsetX);
      setHurtboxOffsetY(hc.hurtboxOffsetY);
      setPunchRange(hc.punchRange);
      setPunchHeight(hc.punchHeight);
      setPunchOffsetY(hc.punchOffsetY);
      setKickRange(hc.kickRange);
      setKickHeight(hc.kickHeight);
      setKickOffsetY(hc.kickOffsetY);
    }
  }, [editCharId, activeChar]);

  // Handle Drag-and-Drop for background uploading
  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const processFile = (file: File) => {
    if (file && file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          onUpdateSettings({
            ...settings,
            bgUrl: event.target.result as string,
            useCustomBg: true,
          });
          audioSynth.playAnnouncer('select');
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      processFile(e.target.files[0]);
    }
  };

  // Reset background
  const handleResetBg = () => {
    onUpdateSettings({
      ...settings,
      useCustomBg: false,
    });
    audioSynth.playPunch();
  };

  // Save Character Changes
  const handleSaveCharacter = (e: React.FormEvent) => {
    e.preventDefault();
    const updated = characters.map(c => {
      if (c.id === editCharId) {
        return {
          ...c,
          name: newName,
          nameFa: newNameFa,
          avatar: newAvatar,
          avatarColor: newColor,
          speed: Number(newSpeed),
          maxHealth: Number(newHealth),
          customWidth: Number(newWidth),
          customHeight: Number(newHeight),
          customFloorOffset: Number(newFloorOffset),
          menuPortrait: newMenuPortrait,
          customSprites: {
            idle: spriteIdle,
            walk: spriteWalk,
            jump: spriteJump,
            punch: spritePunch,
            kick: spriteKick,
            special: spriteSpecial,
            hit: spriteHit,
            block: spriteBlock,
            ko: spriteKo,
          }
        };
      }
      return c;
    });
    onUpdateCharacters(updated);
    audioSynth.playAnnouncer('perfect');
    alert("تغییرات کارکتر با موفقیت ذخیره شد!");
  };

  // Save Hitbox Changes
  const handleSaveHitboxes = (e: React.FormEvent) => {
    e.preventDefault();
    const updated = characters.map(c => {
      if (c.id === editCharId) {
        return {
          ...c,
          customWidth: Number(newWidth),
          customHeight: Number(newHeight),
          customFloorOffset: Number(newFloorOffset),
          hitboxConfig: {
            hurtboxWidthPercent: Number(hurtboxWidthPercent),
            hurtboxHeightPercent: Number(hurtboxHeightPercent),
            hurtboxOffsetX: Number(hurtboxOffsetX),
            hurtboxOffsetY: Number(hurtboxOffsetY),
            punchRange: Number(punchRange),
            punchHeight: Number(punchHeight),
            punchOffsetY: Number(punchOffsetY),
            kickRange: Number(kickRange),
            kickHeight: Number(kickHeight),
            kickOffsetY: Number(kickOffsetY),
          }
        };
      }
      return c;
    });
    onUpdateCharacters(updated);
    audioSynth.playAnnouncer('perfect');
    alert("تنظیمات فیزیک و هیت‌باکس با موفقیت ذخیره شد!");
  };

  // Database Import/Export states
  const [dbImportText, setDbImportText] = useState('');
  const [dbError, setDbError] = useState('');

  const handleExportJson = () => {
    try {
      const json = JSON.stringify(characters, null, 2);
      const blob = new Blob([json], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `fighters-database-${Date.now()}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      audioSynth.playAnnouncer('perfect');
    } catch (e) {
      alert('خطا در خروجی گرفتن از پایگاه داده!');
    }
  };

  const handleImportJson = (text: string) => {
    try {
      const parsed = JSON.parse(text);
      if (Array.isArray(parsed) && parsed.length > 0) {
        const isValid = parsed.every(c => c.id && c.name && c.nameFa && c.moves);
        if (isValid) {
          onUpdateCharacters(parsed);
          setDbError('');
          audioSynth.playAnnouncer('fight');
          alert('پایگاه داده کاراکترها با موفقیت درون‌ریزی و جایگزین شد!');
        } else {
          setDbError('ساختار فایل JSON معتبر نیست. لطفاً فایلی را بارگذاری کنید که قبلاً از این برنامه خروجی گرفته شده است.');
        }
      } else {
        setDbError('ساختار JSON نامعتبر است. فرمت دریافتی باید یک آرایه از کاراکترها باشد.');
      }
    } catch (e) {
      setDbError('خطا در تحلیل کد JSON. لطفاً از صحت فرمت متن مطمئن شوید.');
    }
  };

  const handleFileUploadDb = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string || '';
      handleImportJson(text);
    };
    reader.readAsText(file);
  };

  const handleCopyToClipboard = () => {
    try {
      const json = JSON.stringify(characters, null, 2);
      navigator.clipboard.writeText(json);
      audioSynth.playAnnouncer('select');
      alert('کد کل پایگاه داده در حافظه موقت (Clipboard) کپی شد!');
    } catch (e) {
      alert('محیط اجرای مرورگر اجازه کپی خودکار نمی‌دهد. لطفاً کد را به صورت دستی کپی کنید.');
    }
  };

  return (
    <div id="asset-manager-panel" className="w-full bg-slate-950 rounded-2xl border border-slate-800 overflow-hidden shadow-2xl">
      {/* Tab Selectors */}
      <div className="flex border-b border-slate-800 bg-slate-900/60 p-1">
        <button
          onClick={() => setActiveTab('guide')}
          className={`flex-1 flex items-center justify-center gap-2 py-3 px-4 font-bold text-xs rounded-xl transition ${
            activeTab === 'guide' 
              ? 'bg-slate-950 text-yellow-400 shadow-[0_2px_10px_rgba(234,179,8,0.15)] border-b-2 border-yellow-400' 
              : 'text-slate-400 hover:text-white hover:bg-slate-800/30'
          }`}
        >
          <BookOpen className="w-4 h-4" />
          راهنمای آماده‌سازی دارایی‌ها (Guide)
        </button>
        <button
          onClick={() => setActiveTab('customize')}
          className={`flex-1 flex items-center justify-center gap-2 py-3 px-4 font-bold text-xs rounded-xl transition ${
            activeTab === 'customize' 
              ? 'bg-slate-950 text-cyan-400 shadow-[0_2px_10px_rgba(6,182,212,0.15)] border-b-2 border-cyan-400' 
              : 'text-slate-400 hover:text-white hover:bg-slate-800/30'
          }`}
        >
          <Sparkles className="w-4 h-4" />
          شخصی‌سازی جنگجویان (Fighters)
        </button>
        <button
          onClick={() => setActiveTab('background')}
          className={`flex-1 flex items-center justify-center gap-2 py-3 px-4 font-bold text-xs rounded-xl transition ${
            activeTab === 'background' 
              ? 'bg-slate-950 text-orange-400 shadow-[0_2px_10px_rgba(249,115,22,0.15)] border-b-2 border-orange-400' 
              : 'text-slate-400 hover:text-white hover:bg-slate-800/30'
          }`}
        >
          <ImageIcon className="w-4 h-4" />
          بارگذاری پس‌زمینه (Background)
        </button>
        <button
          onClick={() => setActiveTab('hitbox')}
          className={`flex-1 flex items-center justify-center gap-2 py-3 px-4 font-bold text-xs rounded-xl transition ${
            activeTab === 'hitbox' 
              ? 'bg-slate-950 text-emerald-400 shadow-[0_2px_10px_rgba(16,185,129,0.15)] border-b-2 border-emerald-400' 
              : 'text-slate-400 hover:text-white hover:bg-slate-800/30'
          }`}
        >
          <Target className="w-4 h-4" />
          تنظیم هیت‌باکس‌ها (Hitboxes)
        </button>
        <button
          onClick={() => setActiveTab('database')}
          className={`flex-1 flex items-center justify-center gap-2 py-3 px-4 font-bold text-xs rounded-xl transition ${
            activeTab === 'database' 
              ? 'bg-slate-950 text-violet-400 shadow-[0_2px_10px_rgba(139,92,246,0.15)] border-b-2 border-violet-400' 
              : 'text-slate-400 hover:text-white hover:bg-slate-800/30'
          }`}
        >
          <Database className="w-4 h-4" />
          بانک اطلاعاتی (Database)
        </button>
      </div>

      {/* TAB CONTENT 1: FULL USER GUIDE (Direct response to their exact query) */}
      {activeTab === 'guide' && (
        <div className="p-6 flex flex-col gap-6 text-right" dir="rtl">
          <div>
            <h4 className="text-xl font-black text-yellow-400 mb-2 flex items-center gap-2 justify-end">
              <span>راهنمای جامع آماده‌سازی و پیاده‌سازی بازی</span>
              <HelpCircle className="w-5 h-5 text-yellow-400" />
            </h4>
            <p className="text-sm text-slate-300 leading-relaxed">
              بسیار عالی! اینکه شما <strong>کارکتر اصلی</strong>، <strong>حرکات اصلی</strong> و <strong>بک‌گراند (پس‌زمینه)</strong> را آماده کرده‌اید، به این معنی است که نیمی از راه طلایی را رفته‌اید. برای ساخت یک بازی تمام‌عیار در سبک استریت فایتر (Street Fighter)، بیایید بررسی کنیم که چه مواردی را آماده کرده‌اید و چه چیزهای دیگری نیاز دارید.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Column 1: Assets list */}
            <div className="bg-slate-900/60 p-4 rounded-xl border border-slate-800/50 flex flex-col gap-3">
              <h5 className="text-sm font-bold text-cyan-400 border-b border-cyan-500/20 pb-1">۱. چه چیزهای دیگری باید آماده کنید؟ (Assets)</h5>
              <ul className="text-xs text-slate-300 flex flex-col gap-2.5 list-disc list-inside">
                <li>
                  <strong className="text-white">طرح‌بندی انیمیشن‌ها (Spritesheet):</strong> برای اینکه کارکتر شما راه برود، بپرد، مشت بزند یا ضربه بخورد، باید هر فریم انیمیشن را به صورت یک تصویر با پس‌زمینه شفاف (PNG) با ابعاد مشخص داشته باشید.
                </li>
                <li>
                  <strong className="text-white">جلوه‌های صوتی (Sound Effects):</strong> صدای مشت زدن، لگد زدن، پرتاب فایربال (مثل هادوکن)، خوردن ضربه و دفاع کردن. ما یک سنتزکننده صدای ۸بیتی خودکار قرار داده‌ایم، اما می‌توانید صدای واقعی هم اضافه کنید.
                </li>
                <li>
                  <strong className="text-white">ابعاد فریم‌ها (Hitboxes):</strong> برای هر فریم حمله، باید محدوده و میزان خسارت (Damage) را مشخص کنید تا در بخش کدنویسی دقیقاً در نقطه برخورد ثبت شود.
                </li>
                <li>
                  <strong className="text-white">کارکتر حریف (Opponent):</strong> بازی بدون حریف معنایی ندارد! می‌توانید کارکتر دوم را نیز طراحی کنید یا از کارکترهای پیش‌فرض هوشمند ما استفاده کنید.
                </li>
              </ul>
            </div>

            {/* Column 2: Step plan */}
            <div className="bg-slate-900/60 p-4 rounded-xl border border-slate-800/50 flex flex-col gap-3">
              <h5 className="text-sm font-bold text-orange-400 border-b border-orange-500/20 pb-1">۲. نقشه راه پیشروی ما چطور خواهد بود؟</h5>
              <ol className="text-xs text-slate-300 flex flex-col gap-2.5 list-decimal list-inside">
                <li>
                  <strong className="text-white">فاز ۱ (هم‌اکنون):</strong> یک نسخه دمو کاملاً قابل بازی و هوشمند با فیزیک واقعی دو بعدی، حرکات ضربه‌ای، افکت‌های نوری، هوش مصنوعی حریف با درجات سختی مختلف و صدای اکشن retro پیاده‌سازی کردیم!
                </li>
                <li>
                  <strong className="text-white">فاز ۲ (بارگذاری دارایی‌های شما):</strong> شما می‌توانید تصویر بک‌گراند را همینجا بارگذاری کنید تا مستقیم روی رینگ بازی قرار بگیرد. سپس نام و حرکات کارکتر خود را شخصی‌سازی کنید.
                </li>
                <li>
                  <strong className="text-white">فاز ۳ (توسعه نهایی تصاویر):</strong> در صورت تمایل، کدهای بارگذاری تصاویر متحرک کارکتر شما (Sprite Sheet Canvas Rendering) را با هم می‌نویسیم تا کارکتر شخصی‌تان زنده شود و بجنگد!
                </li>
              </ol>
            </div>
          </div>

          <div className="bg-yellow-500/10 border border-yellow-500/20 p-4 rounded-xl flex items-start gap-3 flex-row-reverse">
            <AlertTriangle className="w-5 h-5 text-yellow-500 shrink-0 mt-0.5" />
            <div className="text-xs text-slate-300">
              <strong className="text-yellow-400 block mb-1">چگونه تصاویر و دارایی‌های خود را به من بدهید؟</strong>
              ۱. تصویر بک‌گراند خود را در تب <strong>«بارگذاری پس‌زمینه»</strong> در بالا رها کنید تا بلافاصله اعمال شود.<br />
              ۲. کدهای استایل، نام‌ها و کلیدهای کنترل کارکتر خود را در تب <strong>«شخصی‌سازی جنگجویان»</strong> تغییر داده و ذخیره کنید تا درون موتور بازی ثبت شوند!
            </div>
          </div>
        </div>
      )}

      {/* TAB CONTENT 2: CUSTOMIZE CHARACTERS */}
      {activeTab === 'customize' && (
        <form onSubmit={handleSaveCharacter} className="p-6 flex flex-col gap-5 text-right" dir="rtl">
          {/* Character Database Control Center Panel */}
          <div className="bg-slate-900/60 p-4 rounded-xl border border-slate-800 flex flex-col sm:flex-row justify-between items-center gap-4 w-full">
            <div className="flex flex-col text-right">
              <span className="text-sm font-bold text-yellow-400 flex items-center gap-1.5 justify-end">
                <span>بانک اطلاعاتی رزمندگان (Character Database)</span>
                <span className="w-2 h-2 rounded-full bg-yellow-400 animate-pulse" />
              </span>
              <span className="text-[10px] text-slate-400">کاراکترهای خود را ویرایش کنید، مبارز جدید بسازید یا دیتابیس محلی را ریست کنید.</span>
            </div>
            
            <div className="flex flex-wrap gap-2 justify-center sm:justify-end items-center">
              <button
                type="button"
                onClick={handleResetDatabase}
                className="flex items-center gap-1.5 bg-red-950 hover:bg-red-900 text-red-300 font-bold px-3 py-2 rounded-lg text-xs transition border border-red-900/50"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>بازنشانی کل دیتابیس</span>
              </button>

              <button
                type="button"
                onClick={handleDeleteCharacter}
                className="flex items-center gap-1.5 bg-slate-900 hover:bg-slate-850 text-slate-400 hover:text-red-400 font-bold px-3 py-2 rounded-lg text-xs transition border border-slate-800"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>حذف کاراکتر فعلی</span>
              </button>

              <button
                type="button"
                onClick={handleAddNewCharacter}
                className="flex items-center gap-1.5 bg-emerald-950/80 hover:bg-emerald-900 text-emerald-300 font-bold px-3.5 py-2 rounded-lg text-xs transition border border-emerald-800/40"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>ایجاد رزمجو جدید</span>
              </button>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-slate-800 pb-3">
            <h4 className="text-base font-bold text-cyan-400">تنظیم مشخصات و آمار رزمجوها</h4>
            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-400 font-mono">انتخاب کارکتر برای ویرایش:</span>
              <select
                value={editCharId}
                onChange={(e) => setEditCharId(e.target.value)}
                className="bg-slate-900 border border-slate-800 rounded-lg px-3 py-1.5 text-xs font-bold text-white outline-none focus:border-cyan-500 cursor-pointer"
              >
                {characters.map(c => (
                  <option key={c.id} value={c.id}>{c.avatar} {c.nameFa} ({c.name})</option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Input fields */}
            <div className="flex flex-col gap-4">
              <div className="grid grid-cols-2 gap-3">
                <div className="flex flex-col gap-1.5">
                  <label className="text-xs text-slate-400">نام فارسی کارکتر:</label>
                  <input
                    type="text"
                    value={newNameFa}
                    onChange={(e) => setNewNameFa(e.target.value)}
                    className="bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white focus:border-cyan-500 outline-none"
                    required
                  />
                </div>
                <div className="flex flex-col gap-1.5">
                  <label className="text-xs text-slate-400 font-mono">Name (English):</label>
                  <input
                    type="text"
                    value={newName}
                    onChange={(e) => setNewName(e.target.value)}
                    className="bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white focus:border-cyan-500 outline-none"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="flex flex-col gap-1.5">
                  <label className="text-xs text-slate-400">آیکون اموجی (Avatar Emoji):</label>
                  <input
                    type="text"
                    value={newAvatar}
                    onChange={(e) => setNewAvatar(e.target.value)}
                    maxLength={2}
                    className="bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-center text-lg text-white focus:border-cyan-500 outline-none"
                    required
                  />
                </div>
                <div className="flex flex-col gap-1.5">
                  <label className="text-xs text-slate-400">رنگ هاله و افکت نوری (HEX):</label>
                  <div className="flex gap-2">
                    <input
                      type="color"
                      value={newColor}
                      onChange={(e) => setNewColor(e.target.value)}
                      className="w-10 h-8 rounded border border-slate-800 bg-transparent cursor-pointer"
                    />
                    <input
                      type="text"
                      value={newColor}
                      onChange={(e) => setNewColor(e.target.value)}
                      className="flex-1 bg-slate-900 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-white font-mono uppercase"
                      required
                    />
                  </div>
                </div>
              </div>

              {/* Menu Portrait Upload */}
              <div className="flex flex-col gap-1.5 border-t border-slate-800/60 pt-3">
                <label className="text-xs text-slate-400 text-right block w-full">تصویر کلوزآپ برای منوی بازی (Menu Portrait Image):</label>
                <div className="flex flex-col sm:flex-row gap-3 items-center bg-slate-950/40 p-3 rounded-xl border border-slate-800 flex-row-reverse">
                  {/* Live preview */}
                  <div className="w-16 h-20 bg-slate-900 rounded-lg border border-slate-800 flex items-center justify-center overflow-hidden shrink-0 relative">
                    {newMenuPortrait ? (
                      <>
                        <img src={newMenuPortrait} alt="Preview" referrerPolicy="no-referrer" className="w-full h-full object-cover" />
                        <button 
                          type="button" 
                          onClick={() => setNewMenuPortrait(undefined)}
                          className="absolute top-0 right-0 bg-red-600 hover:bg-red-500 text-white p-0.5 rounded-bl text-[8px] font-bold"
                          title="حذف تصویر"
                        >
                          ✕
                        </button>
                      </>
                    ) : (
                      <span className="text-2xl">{newAvatar}</span>
                    )}
                  </div>

                  {/* Upload and Paste Area */}
                  <div className="flex-1 w-full flex flex-col gap-2 text-right">
                    <div className="flex gap-2 flex-row-reverse">
                      <input
                        type="text"
                        placeholder="آدرس اینترنتی تصویر را وارد کنید یا فایل آپلود کنید..."
                        value={newMenuPortrait || ''}
                        onChange={(e) => setNewMenuPortrait(e.target.value || undefined)}
                        className="flex-1 bg-slate-900 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-white placeholder-slate-600 outline-none focus:border-cyan-500 text-right"
                      />
                      <label className="cursor-pointer bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg px-3 py-1.5 text-xs font-bold shrink-0 transition flex items-center justify-center gap-1">
                        <span>آپلود فایل</span>
                        <input
                          type="file"
                          accept="image/*"
                          className="hidden"
                          onChange={(e) => {
                            const file = e.target.files?.[0];
                            if (file) {
                              const reader = new FileReader();
                              reader.onload = (ev) => {
                                setNewMenuPortrait(ev.target?.result as string);
                              };
                              reader.readAsDataURL(file);
                            }
                          }}
                        />
                      </label>
                    </div>
                    <span className="text-[9px] text-slate-500 leading-none">پشتیبانی از فایل‌های تصویری یا فرمت Base64. در صورت خالی بودن، اموجی بزرگ نمایش داده می‌شود.</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Stats sliders */}
            <div className="bg-slate-900/40 p-4 rounded-xl border border-slate-800/80 flex flex-col gap-4">
              <div className="flex flex-col gap-1.5">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-400">سرعت حرکت رزمجو:</span>
                  <span className="text-cyan-400 font-bold">{newSpeed}x</span>
                </div>
                <input
                  type="range"
                  min="2"
                  max="7"
                  step="0.5"
                  value={newSpeed}
                  onChange={(e) => setNewSpeed(Number(e.target.value))}
                  className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
                />
              </div>

              <div className="flex flex-col gap-1.5">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-400">میزان کل سلامتی (Health Pool):</span>
                  <span className="text-emerald-400 font-bold">{newHealth} HP</span>
                </div>
                <input
                  type="range"
                  min="80"
                  max="150"
                  step="5"
                  value={newHealth}
                  onChange={(e) => setNewHealth(Number(e.target.value))}
                  className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-emerald-400"
                />
              </div>

              <div className="text-[10px] text-slate-400 flex items-center gap-1.5 justify-end mt-1">
                <span>تغییر دادن آمار بالا مستقیماً روی سرعت حرکت و میزان سلامتی مبارز اثرگذار است.</span>
                <CheckCircle className="w-3.5 h-3.5 text-emerald-500" />
              </div>
            </div>
          </div>

          {/* Custom Sprites Upload Section */}
          <div className="border-t border-slate-800 pt-4 flex flex-col gap-6 text-right" dir="rtl">
            <div className="bg-cyan-950/20 border border-cyan-500/20 p-4 rounded-xl">
              <h5 className="text-sm font-bold text-cyan-400 flex items-center gap-2 justify-end">
                <span>بهینه‌سازی شده برای ۵ انیمیشن اختصاصی شما</span>
                <Sparkles className="w-4 h-4 text-cyan-400" />
              </h5>
              <p className="text-[11px] text-slate-300 mt-1 leading-relaxed">
                موتور بازی بر اساس ساختار ۵ انیمیشنی شما تنظیم شده است. کافیست فریم‌های خود را برای ۵ بخش اصلی زیر بارگذاری کنید. سایر انیمیشن‌ها (مانند حرکت، خوردن ضربه و باختن) به صورت خودکار و هوشمند توسط موتور شبیه‌سازی می‌شوند تا بازی شما با بالاترین کیفیت نمایش داده شود!
              </p>
            </div>

            {/* CORE 5 REQUIRED ANIMATIONS */}
            <div className="border-b border-slate-900 pb-4">
              <h6 className="text-xs font-bold text-yellow-400 mb-3 uppercase tracking-wider font-mono flex items-center gap-1.5 justify-end">
                <span>--- ۵ انیمیشن اصلی کاراکتر (مورد نیاز) ---</span>
                <span className="w-2 h-2 rounded-full bg-yellow-400" />
              </h6>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <SpriteStateBox
                  label="۱. حالت ایستاده (بیکار)"
                  labelEn="Stance (Idle)"
                  subLabel="انیمیشن چرخه بیکار مبارز (ترجیحاً چند فریم متوالی)"
                  value={spriteIdle}
                  onChange={setSpriteIdle}
                />
                <SpriteStateBox
                  label="۲. پرش در هوا"
                  labelEn="Jumping"
                  subLabel="هنگام پریدن در هوا (کلید W یا فلش بالا)"
                  value={spriteJump}
                  onChange={setSpriteJump}
                />
                <SpriteStateBox
                  label="۳. گارد دفاع"
                  labelEn="Blocking"
                  subLabel="کلید S (بازیکن ۱) / فلش پایین (بازیکن ۲)"
                  value={spriteBlock}
                  onChange={setSpriteBlock}
                />
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                <SpriteStateBox
                  label="۴. ضربه مشت"
                  labelEn="Punching"
                  subLabel="کلید F (بازیکن ۱) / I (بازیکن ۲)"
                  value={spritePunch}
                  onChange={setSpritePunch}
                />
                <SpriteStateBox
                  label="۵. ضربه لگد"
                  labelEn="Kicking"
                  subLabel="کلید G (بازیکن ۱) / O (بازیکن ۲)"
                  value={spriteKick}
                  onChange={setSpriteKick}
                />
              </div>
            </div>

            {/* OPTIONAL SIMULATED ANIMATIONS */}
            <div className="pb-2">
              <h6 className="text-xs font-bold text-slate-500 mb-3 uppercase tracking-wider font-mono flex items-center gap-1.5 justify-end">
                <span>--- حرکات فرعی (شبیه‌سازی خودکار / اختیاری) ---</span>
                <span className="w-2 h-2 rounded-full bg-slate-500" />
              </h6>
              <p className="text-[10px] text-slate-500 mb-3 leading-relaxed">
                اگر این بخش‌ها را خالی بگذارید، موتور بازی از انیمیشن ایستاده (Idle) شما استفاده کرده و به صورت هوشمند افکت‌های فیزیکی (مثل لرزش هنگام آسیب، چرخش ۹۰ درجه هنگام بیهوشی، و لرزش سینوسی هنگام راه رفتن) را شبیه‌سازی می‌کند.
              </p>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 opacity-75">
                <SpriteStateBox
                  label="راه رفتن"
                  labelEn="Walking"
                  subLabel="در صورت خالی بودن، ایستاده با افکت راه رفتن نمایش داده می‌شود"
                  value={spriteWalk}
                  onChange={setSpriteWalk}
                />
                <SpriteStateBox
                  label="ضربه ویژه"
                  labelEn="Special Attack"
                  subLabel="در صورت خالی بودن، ضربه مشت یا لگد استفاده می‌شود"
                  value={spriteSpecial}
                  onChange={setSpriteSpecial}
                />
                <SpriteStateBox
                  label="آسیب دیدن"
                  labelEn="Hurt (Hit)"
                  subLabel="در صورت خالی بودن، ایستاده با لرزش و زاویه کج شبیه‌سازی می‌شود"
                  value={spriteHit}
                  onChange={setSpriteHit}
                />
                <SpriteStateBox
                  label="شکست و KO"
                  labelEn="Knockout (KO)"
                  subLabel="در صورت خالی بودن، ایستاده با افکت افتادن ۹۰ درجه روی زمین شبیه‌سازی می‌شود"
                  value={spriteKo}
                  onChange={setSpriteKo}
                />
              </div>
            </div>
          </div>

          <div className="flex justify-end mt-4 border-t border-slate-800 pt-4">
            <button
              type="submit"
              className="bg-cyan-500 text-slate-950 font-black py-2.5 px-6 rounded-xl hover:bg-cyan-400 active:scale-95 transition text-xs shadow-lg shadow-cyan-500/10"
            >
              ذخیره تغییرات مبارز (Save Character)
            </button>
          </div>
        </form>
      )}

      {/* TAB CONTENT 3: DRAG AND DROP BACKGROUND LOADER */}
      {activeTab === 'background' && (
        <div className="p-6 flex flex-col gap-5 text-right" dir="rtl">
          <div>
            <h4 className="text-base font-bold text-orange-400 mb-1">بارگذاری بک‌گراند رینگ مبارزه (PNG/JPG)</h4>
            <p className="text-xs text-slate-400">
              تصویر اختصاصی خود را که برای پس‌زمینه مبارزه آماده کرده‌اید بارگذاری کنید تا مستقیم به عنوان زمین اصلی رزم قرار گیرد.
            </p>
          </div>

          {/* Drag & Drop Area */}
          <div
            onDragEnter={handleDrag}
            onDragOver={handleDrag}
            onDragLeave={handleDrag}
            onDrop={handleDrop}
            className={`border-2 border-dashed rounded-2xl p-8 flex flex-col items-center justify-center gap-3 transition ${
              dragActive 
                ? 'border-orange-400 bg-orange-950/10 text-orange-400' 
                : 'border-slate-800 hover:border-slate-700 bg-slate-900/20 text-slate-400'
            }`}
          >
            <Upload className="w-10 h-10 text-orange-500 animate-pulse" />
            <div className="text-center">
              <p className="text-sm font-bold text-white">تصویر پس‌زمینه خود را به اینجا بکشید و رها کنید</p>
              <p className="text-xs text-slate-500 mt-1">یا برای انتخاب فایل از حافظه، روی دکمه زیر کلیک کنید</p>
            </div>
            
            <label className="bg-slate-900 border border-slate-700 hover:bg-slate-800 text-white font-bold py-2 px-4 rounded-xl text-xs cursor-pointer active:scale-95 transition">
              انتخاب عکس پس‌زمینه
              <input
                type="file"
                className="hidden"
                accept="image/*"
                onChange={handleFileInput}
              />
            </label>
          </div>

          {/* Current Status Indicator */}
          {settings.useCustomBg && settings.bgUrl ? (
            <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 flex items-center justify-between">
              <button
                onClick={handleResetBg}
                className="text-xs bg-red-950 text-red-400 border border-red-900 px-3 py-1.5 rounded-lg hover:bg-red-900 hover:text-white transition"
              >
                حذف بک‌گراند سفارشی (Reset)
              </button>
              <div className="flex items-center gap-3">
                <span className="text-xs text-emerald-400 font-bold">بک‌گراند شما هم‌اکنون فعال است!</span>
                <img 
                  src={settings.bgUrl} 
                  alt="Custom Arena" 
                  className="w-16 h-10 object-cover rounded border border-slate-800"
                />
              </div>
            </div>
          ) : (
            <div className="bg-slate-900/40 p-4 rounded-xl border border-slate-800/50 text-center">
              <span className="text-xs text-slate-500">در حال حاضر از پس‌زمینه پیش‌فرض نئونی سایبرپانک استفاده می‌شود.</span>
            </div>
          )}
        </div>
      )}

      {/* TAB CONTENT 4: HITBOX DESIGNER & EDITOR PANEL */}
      {activeTab === 'hitbox' && (
        <div className="p-6 flex flex-col gap-6 text-right" dir="rtl">
          {/* Header */}
          <div className="flex justify-between items-center border-b border-slate-800 pb-4">
            <span className="text-xs text-slate-500 font-mono">PHYSICS & HITBOX LAB / آزمایشگاه فیزیک و برخورد</span>
            <h4 className="text-xl font-black text-emerald-400 flex items-center gap-2">
              <span>آزمایشگاه گرافیکی فیزیک و هیت‌باکس مبارز</span>
              <Target className="w-5 h-5 text-emerald-400" />
            </h4>
          </div>

          {/* Active Character Selector for Hitbox tuning */}
          <div className="bg-slate-900/40 p-4 rounded-xl border border-slate-800 flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="text-right">
              <span className="text-xs text-slate-400 block mb-1">انتخاب جنگجو برای کالیبراسیون برخورد:</span>
              <span className="text-[10px] text-slate-500">جرم، ابعاد فیزیکی و برد حملات هر مبارز را در بستر زمین بازی بسنجید و کالیبره کنید.</span>
            </div>
            <select
              value={editCharId}
              onChange={(e) => setEditCharId(e.target.value)}
              className="bg-slate-950 border border-slate-800 rounded-lg py-2 px-4 text-xs font-bold text-slate-300 focus:outline-none focus:border-emerald-500 w-full md:w-64 cursor-pointer font-mono"
            >
              {characters.map((char) => (
                <option key={char.id} value={char.id}>
                  {char.avatar} {char.nameFa} ({char.name})
                </option>
              ))}
            </select>
          </div>

          <form onSubmit={handleSaveHitboxes} className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            
            {/* COLUMN 1: INTERACTIVE PREVIEW PANEL */}
            <div className="flex flex-col gap-4">
              <div className="bg-slate-900 border border-slate-850 rounded-2xl p-4 flex flex-col gap-4 relative">
                
                {/* Lab Indicators */}
                <div className="flex justify-between items-center bg-slate-950/60 p-2 rounded-xl border border-slate-850">
                  <div className="flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                    <span className="text-[10px] text-emerald-400 font-bold font-mono">LIVE PREVIEW ON MAP / شبیه‌ساز لایو نقشه</span>
                  </div>
                  <span className="text-[9px] text-slate-500 font-mono">STUDIO VIEW</span>
                </div>

                {/* HTML5 Canvas live preview component */}
                <HitboxCanvasPreview
                  activeChar={activeChar}
                  customWidth={Number(newWidth)}
                  customHeight={Number(newHeight)}
                  customFloorOffset={Number(newFloorOffset)}
                  hurtboxWidthPercent={hurtboxWidthPercent}
                  hurtboxHeightPercent={hurtboxHeightPercent}
                  hurtboxOffsetX={hurtboxOffsetX}
                  hurtboxOffsetY={hurtboxOffsetY}
                  punchRange={punchRange}
                  punchHeight={punchHeight}
                  punchOffsetY={punchOffsetY}
                  kickRange={kickRange}
                  kickHeight={kickHeight}
                  kickOffsetY={kickOffsetY}
                  previewState={previewState}
                  previewDirection={previewDirection}
                  showGrid={showGrid}
                  settings={settings}
                />

                {/* Studio Controls (Flipping, Grids, etc.) */}
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setPreviewDirection(prev => prev === 1 ? -1 : 1)}
                    className="flex items-center justify-center gap-2 bg-slate-950 hover:bg-slate-850 border border-slate-800 text-xs text-slate-300 font-bold py-2 rounded-xl active:scale-95 transition"
                  >
                    <RefreshCw className="w-3.5 h-3.5 text-cyan-400" />
                    <span>چرخش جهت کاراکتر ({previewDirection === 1 ? 'راست' : 'چپ'})</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setShowGrid(prev => !prev)}
                    className={`flex items-center justify-center gap-2 border text-xs font-bold py-2 rounded-xl active:scale-95 transition ${
                      showGrid 
                        ? 'bg-cyan-950/30 border-cyan-500/30 text-cyan-400' 
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    <Grid className="w-3.5 h-3.5" />
                    <span>نمایش گرید و خطوط مرجع</span>
                  </button>
                </div>

                {/* Animation Pose Selectors */}
                <div className="flex flex-col gap-1.5">
                  <span className="text-[10px] text-slate-400">تغییر ژست و انیمیشن جنگجو:</span>
                  <div className="grid grid-cols-4 sm:grid-cols-7 gap-1 bg-slate-950 p-1 rounded-xl border border-slate-850">
                    {(['idle', 'walk', 'punch', 'kick', 'block', 'hit', 'ko'] as const).map((st) => (
                      <button
                        key={st}
                        type="button"
                        onClick={() => setPreviewState(st)}
                        className={`py-1.5 rounded-lg text-[9px] font-bold transition ${
                          previewState === st 
                            ? 'bg-emerald-500 text-slate-950 shadow' 
                            : 'text-slate-400 hover:text-white hover:bg-slate-900/50'
                        }`}
                      >
                        {st === 'idle' && 'ایستاده'}
                        {st === 'walk' && 'حرکت'}
                        {st === 'punch' && 'مشت'}
                        {st === 'kick' && 'لگد'}
                        {st === 'block' && 'دفاع'}
                        {st === 'hit' && 'آسیب'}
                        {st === 'ko' && 'KO'}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Legend / Color explanations */}
                <div className="flex items-center justify-between px-2 text-[10px] text-slate-400 font-bold border-t border-slate-800/40 pt-2.5">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded bg-emerald-500/20 border border-emerald-500" />
                    <span>HURTBOX (مستطیل آسیب‌پذیر)</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded bg-red-500/20 border border-red-500" />
                    <span>HITBOX (برد ضربه مشت/لگد)</span>
                  </div>
                </div>

              </div>

              <div className="bg-emerald-950/10 border border-emerald-500/10 p-4 rounded-xl text-[11px] text-slate-400 leading-relaxed text-right">
                <strong className="text-emerald-400 block mb-1">نکته توسعه فیزیک بازی:</strong>
                ابعاد کاراکتر مستقیماً بر سرعت حرکت و میزان جاذبه و اصطکاک اثرگذار است. با تنظیم گرید، مطمئن شوید نقاط ضربه (Hitboxes) با دست یا پای مشت‌زن کاملا همخوانی داشته باشند تا مبارزات عادلانه‌تر و رقابتی‌تر دنبال شوند.
              </div>
            </div>

            {/* COLUMN 2: SLIDERS & PARAMETER TUNERS */}
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 flex flex-col gap-5">
              
              {/* CHARACTER PHYSICAL SIZE TUNING */}
              <div className="flex flex-col gap-4">
                <h5 className="text-xs font-bold text-cyan-400 border-b border-slate-800 pb-2 flex items-center gap-1.5 justify-end">
                  <span>ابعاد فیزیکی کاراکتر در نقشه (Character Physical Dimensions)</span>
                  <span className="w-2 h-2 rounded-full bg-cyan-400" />
                </h5>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="flex flex-col gap-1 bg-slate-950/40 p-2.5 rounded-lg border border-slate-850">
                    <div className="flex justify-between text-xs font-semibold">
                      <span className="text-cyan-400 font-mono">{newWidth}px</span>
                      <span className="text-slate-300">عرض فیزیکی (Width):</span>
                    </div>
                    <input
                      type="range"
                      min="15"
                      max="600"
                      value={newWidth}
                      onChange={(e) => setNewWidth(Number(e.target.value))}
                      className="w-full accent-cyan-400 cursor-pointer h-1 bg-slate-950 rounded-lg appearance-none mt-1"
                    />
                  </div>

                  <div className="flex flex-col gap-1 bg-slate-950/40 p-2.5 rounded-lg border border-slate-850">
                    <div className="flex justify-between text-xs font-semibold">
                      <span className="text-cyan-400 font-mono">{newHeight}px</span>
                      <span className="text-slate-300">ارتفاع فیزیکی (Height):</span>
                    </div>
                    <input
                      type="range"
                      min="20"
                      max="800"
                      value={newHeight}
                      onChange={(e) => setNewHeight(Number(e.target.value))}
                      className="w-full accent-cyan-400 cursor-pointer h-1 bg-slate-950 rounded-lg appearance-none mt-1"
                    />
                  </div>

                  <div className="flex flex-col gap-1 bg-slate-950/40 p-2.5 rounded-lg border border-slate-850">
                    <div className="flex justify-between text-xs font-semibold">
                      <span className="text-cyan-400 font-mono">{newFloorOffset}px</span>
                      <span className="text-slate-300">تراز کف (Floor Offset):</span>
                    </div>
                    <input
                      type="range"
                      min="-400"
                      max="400"
                      value={newFloorOffset}
                      onChange={(e) => setNewFloorOffset(Number(e.target.value))}
                      className="w-full accent-cyan-400 cursor-pointer h-1 bg-slate-950 rounded-lg appearance-none mt-1"
                    />
                  </div>
                </div>
              </div>

              {/* HURTBOX TUNING SECTION */}
              <div className="flex flex-col gap-4 border-t border-slate-800/60 pt-4">
                <h5 className="text-xs font-bold text-emerald-400 border-b border-slate-800 pb-2 flex items-center gap-1.5 justify-end">
                  <span>تنظیم جبهه آسیب‌‌پذیر کارکتر (Hurtbox Settings)</span>
                  <span className="w-2 h-2 rounded-full bg-emerald-500" />
                </h5>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="flex flex-col gap-1">
                    <div className="flex justify-between text-xs font-semibold">
                      <span className="text-slate-500 font-mono">{hurtboxWidthPercent}%</span>
                      <span className="text-slate-300">درصد عرض جبهه (Width %):</span>
                    </div>
                    <input
                      type="range"
                      min="40"
                      max="140"
                      value={hurtboxWidthPercent}
                      onChange={(e) => setHurtboxWidthPercent(Number(e.target.value))}
                      className="w-full accent-emerald-500 cursor-pointer h-1 bg-slate-950 rounded-lg appearance-none"
                    />
                  </div>

                  <div className="flex flex-col gap-1">
                    <div className="flex justify-between text-xs font-semibold">
                      <span className="text-slate-500 font-mono">{hurtboxHeightPercent}%</span>
                      <span className="text-slate-300">درصد ارتفاع جبهه (Height %):</span>
                    </div>
                    <input
                      type="range"
                      min="40"
                      max="140"
                      value={hurtboxHeightPercent}
                      onChange={(e) => setHurtboxHeightPercent(Number(e.target.value))}
                      className="w-full accent-emerald-500 cursor-pointer h-1 bg-slate-950 rounded-lg appearance-none"
                    />
                  </div>

                  <div className="flex flex-col gap-1">
                    <div className="flex justify-between text-xs font-semibold">
                      <span className="text-slate-500 font-mono">{hurtboxOffsetX}px</span>
                      <span className="text-slate-300">جابجایی افقی (Offset X):</span>
                    </div>
                    <input
                      type="range"
                      min="-300"
                      max="300"
                      value={hurtboxOffsetX}
                      onChange={(e) => setHurtboxOffsetX(Number(e.target.value))}
                      className="w-full accent-emerald-500 cursor-pointer h-1 bg-slate-950 rounded-lg appearance-none"
                    />
                  </div>

                  <div className="flex flex-col gap-1">
                    <div className="flex justify-between text-xs font-semibold">
                      <span className="text-slate-500 font-mono">{hurtboxOffsetY}px</span>
                      <span className="text-slate-300">جابجایی عمودی (Offset Y):</span>
                    </div>
                    <input
                      type="range"
                      min="-300"
                      max="300"
                      value={hurtboxOffsetY}
                      onChange={(e) => setHurtboxOffsetY(Number(e.target.value))}
                      className="w-full accent-emerald-500 cursor-pointer h-1 bg-slate-950 rounded-lg appearance-none"
                    />
                  </div>
                </div>
              </div>

              {/* ATTACK HITBOX TUNING */}
              <div className="flex flex-col gap-4 border-t border-slate-800 pt-4">
                <h5 className="text-xs font-bold text-red-400 border-b border-slate-800 pb-2 flex items-center gap-1.5 justify-end">
                  <span>ابعاد ضربه مشت (Punch Hitbox & Range)</span>
                  <span className="w-2 h-2 rounded-full bg-red-500" />
                </h5>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="flex flex-col gap-1">
                    <div className="flex justify-between text-[11px] font-semibold">
                      <span className="text-slate-500 font-mono">{punchRange}px</span>
                      <span className="text-slate-300">برد حمله مشت:</span>
                    </div>
                    <input
                      type="range"
                      min="10"
                      max="500"
                      value={punchRange}
                      onChange={(e) => {
                        setPunchRange(Number(e.target.value));
                        setPreviewState('punch');
                      }}
                      className="w-full accent-red-500 cursor-pointer h-1 bg-slate-950 rounded-lg appearance-none"
                    />
                  </div>

                  <div className="flex flex-col gap-1">
                    <div className="flex justify-between text-[11px] font-semibold">
                      <span className="text-slate-500 font-mono">{punchHeight}px</span>
                      <span className="text-slate-300">ارتفاع ضربه:</span>
                    </div>
                    <input
                      type="range"
                      min="10"
                      max="500"
                      value={punchHeight}
                      onChange={(e) => {
                        setPunchHeight(Number(e.target.value));
                        setPreviewState('punch');
                      }}
                      className="w-full accent-red-500 cursor-pointer h-1 bg-slate-950 rounded-lg appearance-none"
                    />
                  </div>

                  <div className="flex flex-col gap-1">
                    <div className="flex justify-between text-[11px] font-semibold">
                      <span className="text-slate-500 font-mono">{punchOffsetY}px</span>
                      <span className="text-slate-300">ارتفاع تراز:</span>
                    </div>
                    <input
                      type="range"
                      min="-300"
                      max="400"
                      value={punchOffsetY}
                      onChange={(e) => {
                        setPunchOffsetY(Number(e.target.value));
                        setPreviewState('punch');
                      }}
                      className="w-full accent-red-500 cursor-pointer h-1 bg-slate-950 rounded-lg appearance-none"
                    />
                  </div>
                </div>
              </div>

              {/* KICK HITBOX TUNING */}
              <div className="flex flex-col gap-4 border-t border-slate-800 pt-4">
                <h5 className="text-xs font-bold text-yellow-500 border-b border-slate-800 pb-2 flex items-center gap-1.5 justify-end">
                  <span>ابعاد ضربه لگد (Kick Hitbox & Range)</span>
                  <span className="w-2 h-2 rounded-full bg-yellow-500" />
                </h5>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="flex flex-col gap-1">
                    <div className="flex justify-between text-[11px] font-semibold">
                      <span className="text-slate-500 font-mono">{kickRange}px</span>
                      <span className="text-slate-300">برد حمله لگد:</span>
                    </div>
                    <input
                      type="range"
                      min="10"
                      max="550"
                      value={kickRange}
                      onChange={(e) => {
                        setKickRange(Number(e.target.value));
                        setPreviewState('kick');
                      }}
                      className="w-full accent-yellow-500 cursor-pointer h-1 bg-slate-950 rounded-lg appearance-none"
                    />
                  </div>

                  <div className="flex flex-col gap-1">
                    <div className="flex justify-between text-[11px] font-semibold">
                      <span className="text-slate-500 font-mono">{kickHeight}px</span>
                      <span className="text-slate-300">ارتفاع ضربه:</span>
                    </div>
                    <input
                      type="range"
                      min="10"
                      max="500"
                      value={kickHeight}
                      onChange={(e) => {
                        setKickHeight(Number(e.target.value));
                        setPreviewState('kick');
                      }}
                      className="w-full accent-yellow-500 cursor-pointer h-1 bg-slate-950 rounded-lg appearance-none"
                    />
                  </div>

                  <div className="flex flex-col gap-1">
                    <div className="flex justify-between text-[11px] font-semibold">
                      <span className="text-slate-500 font-mono">{kickOffsetY}px</span>
                      <span className="text-slate-300">ارتفاع تراز:</span>
                    </div>
                    <input
                      type="range"
                      min="-300"
                      max="400"
                      value={kickOffsetY}
                      onChange={(e) => {
                        setKickOffsetY(Number(e.target.value));
                        setPreviewState('kick');
                      }}
                      className="w-full accent-yellow-500 cursor-pointer h-1 bg-slate-950 rounded-lg appearance-none"
                    />
                  </div>
                </div>
              </div>

              {/* SAVE BUTTON FOR THE FORMS */}
              <button
                type="submit"
                className="w-full mt-3 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-slate-950 font-black py-4 rounded-2xl shadow-xl shadow-emerald-500/10 hover:shadow-emerald-500/25 active:scale-98 transition text-xs uppercase tracking-wider flex items-center justify-center gap-2"
              >
                <CheckCircle className="w-4 h-4 text-slate-950" />
                <span>ذخیره نهایی ابعاد فیزیکی و هیت‌باکس‌ها (Commit & Save Physics)</span>
              </button>

            </div>

          </form>
        </div>
      )}

      {/* TAB CONTENT 5: CHARACTER DATABASE MANAGER */}
      {activeTab === 'database' && (
        <div className="p-6 flex flex-col gap-6 text-right" dir="rtl">
          <div>
            <h4 className="text-lg font-black text-violet-400 mb-1 flex items-center gap-2 justify-end">
              <span>مدیریت پایگاه داده رزمندگان (Character Database Engine)</span>
              <Database className="w-5 h-5 text-violet-400 animate-pulse" />
            </h4>
            <p className="text-xs text-slate-300 leading-relaxed">
              این برنامه مجهز به یک موتور ذخیره‌سازی محلی خودکار است. تغییرات شما بلافاصله در مرورگر ذخیره می‌شوند. شما می‌توانید پایگاه داده خود را به صورت فایل استاندارد JSON استخراج کنید یا فایل انیمیشن‌های خود را درون‌ریزی کنید.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Database Stats Card */}
            <div className="bg-slate-900/40 p-4 rounded-xl border border-slate-800/80 flex flex-col gap-3 justify-between">
              <span className="text-xs font-bold text-violet-400 flex items-center gap-1.5 justify-end">
                <span>وضعیت پایگاه داده (Stats)</span>
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              </span>
              <div className="flex flex-col gap-2 text-xs text-slate-300 font-mono">
                <div className="flex justify-between flex-row-reverse">
                  <span>نوع دیتابیس:</span>
                  <span className="text-white font-bold">LocalStorage (Durable)</span>
                </div>
                <div className="flex justify-between flex-row-reverse">
                  <span>تعداد رزمجوها:</span>
                  <span className="text-cyan-400 font-bold">{characters.length} کاراکتر</span>
                </div>
                <div className="flex justify-between flex-row-reverse">
                  <span>وضعیت موتور:</span>
                  <span className="text-emerald-400 font-bold">متصل (Online)</span>
                </div>
              </div>
              <button
                type="button"
                onClick={handleCopyToClipboard}
                className="w-full flex items-center justify-center gap-1.5 bg-slate-950 hover:bg-slate-900 text-slate-300 font-bold py-2 rounded-lg text-xs transition border border-slate-800"
              >
                <Copy className="w-3.5 h-3.5" />
                <span>کپی کل دیتابیس (JSON)</span>
              </button>
            </div>

            {/* Export Card */}
            <div className="bg-slate-900/40 p-4 rounded-xl border border-slate-800/80 flex flex-col gap-3 justify-between">
              <span className="text-xs font-bold text-violet-400 flex items-center gap-1.5 justify-end">
                <span>پشتیبان‌گیری کامل (Backup & Share)</span>
                <FileJson className="w-4 h-4 text-violet-400" />
              </span>
              <p className="text-[10px] text-slate-400 leading-relaxed">
                تمام مشخصات، سرعت، میزان خون، هیت‌باکس‌ها و انیمیشن‌های سفارشی تمام مبارزهای خود را در قالب یک فایل JSON دانلود کنید تا بتوانید بعداً آن را بازیابی کنید یا با دوستان خود به اشتراک بگذارید.
              </p>
              <button
                type="button"
                onClick={handleExportJson}
                className="w-full flex items-center justify-center gap-1.5 bg-violet-650 hover:bg-violet-600 text-white font-bold py-2 px-3 rounded-lg text-xs transition shadow-lg shadow-violet-500/10"
              >
                <Download className="w-3.5 h-3.5" />
                <span>دانلود فایل پشتیبان (Export)</span>
              </button>
            </div>

            {/* Import Card */}
            <div className="bg-slate-900/40 p-4 rounded-xl border border-slate-800/80 flex flex-col gap-3 justify-between">
              <span className="text-xs font-bold text-violet-400 flex items-center gap-1.5 justify-end">
                <span>بازیابی پایگاه داده (Restore File)</span>
                <Upload className="w-4 h-4 text-violet-400" />
              </span>
              <p className="text-[10px] text-slate-400 leading-relaxed">
                فایل JSON خروجی گرفته شده را بارگذاری کنید تا تمام کاراکترها و فریم‌های انیمیشن‌ها مستقیماً وارد بازی شده و جایگزین دیتابیس فعلی شوند.
              </p>
              <label className="w-full flex items-center justify-center gap-1.5 bg-slate-950 hover:bg-slate-900 text-violet-300 font-bold py-2 px-3 rounded-lg text-xs cursor-pointer active:scale-95 transition border border-violet-900/40 text-center">
                <Upload className="w-3.5 h-3.5" />
                <span>بارگذاری فایل دیتابیس (Import)</span>
                <input
                  type="file"
                  accept=".json"
                  className="hidden"
                  onChange={handleFileUploadDb}
                />
              </label>
            </div>
          </div>

          {/* Raw JSON Import Console */}
          <div className="bg-slate-900/40 p-4 rounded-xl border border-slate-800/85">
            <h5 className="text-xs font-bold text-slate-300 mb-2 flex items-center gap-1.5 justify-end">
              <span>درون‌ریزی مستقیم متن پایگاه داده (Raw JSON Clipboard Import)</span>
              <span className="w-2 h-2 rounded-full bg-violet-500" />
            </h5>
            <p className="text-[10px] text-slate-500 mb-3">
              اگر کدی را کپی کرده‌اید، می‌توانید مستقیماً آن را در جعبه زیر پیست کنید و دکمه اعمال را بزنید:
            </p>
            <textarea
              rows={4}
              value={dbImportText}
              onChange={(e) => setDbImportText(e.target.value)}
              placeholder='[ { "id": "custom_fighter", "name": "Cyber Fighter", ... } ]'
              className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-[10px] font-mono text-slate-300 outline-none focus:border-violet-500/80 leading-relaxed text-left min-h-[100px]"
              dir="ltr"
            />
            {dbError && (
              <div className="text-[10px] text-red-400 font-bold mt-2 text-right">
                ⚠️ {dbError}
              </div>
            )}
            <div className="flex justify-end mt-3">
              <button
                type="button"
                onClick={() => {
                  if (!dbImportText.trim()) {
                    setDbError('لطفاً ابتدا کد JSON را در کادر وارد کنید.');
                    return;
                  }
                  handleImportJson(dbImportText);
                }}
                className="bg-violet-950 hover:bg-violet-900 border border-violet-800 text-violet-300 font-bold py-1.5 px-4 rounded-lg text-xs transition"
              >
                جایگذاری و تحلیل پایگاه داده (Apply Raw JSON)
              </button>
            </div>
          </div>

          {/* Registered Characters Registry View */}
          <div className="bg-slate-900/40 p-4 rounded-xl border border-slate-800/85">
            <h5 className="text-xs font-bold text-slate-300 mb-3 flex items-center gap-1.5 justify-end">
              <span>لیست رزمندگان فعال در حافظه پایگاه داده</span>
              <span className="w-2 h-2 rounded-full bg-emerald-500" />
            </h5>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
              {characters.map(c => (
                <div key={c.id} className="bg-slate-950 p-3 rounded-lg border border-slate-800 flex items-center justify-between flex-row-reverse gap-2">
                  <div className="flex items-center gap-2 flex-row-reverse">
                    <span className="text-xl">{c.avatar}</span>
                    <div className="text-right">
                      <div className="text-xs font-bold text-white">{c.nameFa}</div>
                      <div className="text-[9px] text-slate-500 font-mono">{c.name}</div>
                    </div>
                  </div>
                  <div className="text-[9px] font-mono bg-slate-900 px-2 py-1 rounded text-slate-400">
                    ID: {c.id.substring(0, 10)}...
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AssetManager;
