import React, { useEffect, useRef } from 'react';
import { CharacterConfig, GameSettings } from '../types';

interface HitboxCanvasPreviewProps {
  activeChar: CharacterConfig;
  customWidth: number;
  customHeight: number;
  customFloorOffset: number;
  hurtboxWidthPercent: number;
  hurtboxHeightPercent: number;
  hurtboxOffsetX: number;
  hurtboxOffsetY: number;
  punchRange: number;
  punchHeight: number;
  punchOffsetY: number;
  kickRange: number;
  kickHeight: number;
  kickOffsetY: number;
  previewState: 'idle' | 'walk' | 'punch' | 'kick' | 'block' | 'hit' | 'ko';
  previewDirection: 1 | -1;
  showGrid: boolean;
  settings: GameSettings;
}

export const HitboxCanvasPreview: React.FC<HitboxCanvasPreviewProps> = ({
  activeChar,
  customWidth,
  customHeight,
  customFloorOffset,
  hurtboxWidthPercent,
  hurtboxHeightPercent,
  hurtboxOffsetX,
  hurtboxOffsetY,
  punchRange,
  punchHeight,
  punchOffsetY,
  kickRange,
  kickHeight,
  kickOffsetY,
  previewState,
  previewDirection,
  showGrid,
  settings,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const imageCache = useRef<Record<string, HTMLImageElement>>({});
  const animFrameId = useRef<number | null>(null);

  // Load and cache images
  const getCachedImage = (url: string): HTMLImageElement | null => {
    if (!url) return null;
    if (!imageCache.current[url]) {
      const img = new Image();
      img.referrerPolicy = 'no-referrer';
      img.src = url;
      imageCache.current[url] = img;
    }
    const cached = imageCache.current[url];
    return cached.complete && cached.naturalWidth > 0 ? cached : null;
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let tick = 0;

    const render = () => {
      tick++;
      const width = canvas.width;
      const height = canvas.height;

      // 1. Clear & Draw Background (Arena or Custom BG)
      ctx.save();
      if (settings.useCustomBg && settings.bgUrl) {
        const bgImg = getCachedImage(settings.bgUrl);
        if (bgImg) {
          ctx.drawImage(bgImg, 0, 0, width, height);
        } else {
          // Fallback while loading
          ctx.fillStyle = '#0f172a';
          ctx.fillRect(0, 0, width, height);
          ctx.fillStyle = '#10b981';
          ctx.font = '10px monospace';
          ctx.fillText('LOADING BACKGROUND...', 20, 30);
        }
      } else {
        // Draw Retro Sky
        const skyGrad = ctx.createLinearGradient(0, 0, 0, height - 60);
        skyGrad.addColorStop(0, '#0a051d');
        skyGrad.addColorStop(0.5, '#20083c');
        skyGrad.addColorStop(1, '#3d1255');
        ctx.fillStyle = skyGrad;
        ctx.fillRect(0, 0, width, height);

        // Skyline silhouettes
        ctx.fillStyle = '#1c0a2e';
        ctx.fillRect(20, 50, 70, height - 110);
        ctx.fillRect(110, 35, 90, height - 95);
        ctx.fillRect(220, 75, 60, height - 135);
        ctx.fillRect(310, 45, 95, height - 105);
        ctx.fillRect(420, 65, 50, height - 125);

        // Windows
        ctx.fillStyle = 'rgba(255, 235, 59, 0.12)';
        ctx.fillRect(120, 60, 10, 15);
        ctx.fillRect(140, 60, 10, 15);
        ctx.fillRect(120, 90, 10, 15);
        ctx.fillRect(320, 70, 10, 15);
        ctx.fillRect(340, 70, 10, 15);

        // Ground Platform (Floor recedes at Y = 220)
        ctx.fillStyle = '#12021c';
        ctx.fillRect(0, 220, width, height - 220);

        // Perspective grid lines
        ctx.strokeStyle = '#6c209c';
        ctx.lineWidth = 1;
        for (let x = -100; x <= width + 100; x += 50) {
          ctx.beginPath();
          ctx.moveTo(width / 2, 220);
          ctx.lineTo(x, height);
          ctx.stroke();
        }

        // Horizontal lines
        let hLineY = 220;
        let spacing = 2;
        while (hLineY < height) {
          ctx.beginPath();
          ctx.moveTo(0, hLineY);
          ctx.lineTo(width, hLineY);
          ctx.stroke();
          spacing += 1.5;
          hLineY += spacing;
        }
      }
      ctx.restore();

      // 2. Draw Grid overlay if requested
      if (showGrid) {
        ctx.save();
        ctx.strokeStyle = 'rgba(6, 182, 212, 0.12)';
        ctx.lineWidth = 0.5;
        // Verticals
        for (let x = 0; x < width; x += 25) {
          ctx.beginPath();
          ctx.moveTo(x, 0);
          ctx.lineTo(x, height);
          ctx.stroke();
        }
        // Horizontals
        for (let y = 0; y < height; y += 25) {
          ctx.beginPath();
          ctx.moveTo(0, y);
          ctx.lineTo(width, y);
          ctx.stroke();
        }

        // Horizontal Ruler at the bottom ground
        ctx.fillStyle = 'rgba(6, 182, 212, 0.25)';
        ctx.fillRect(0, 220, width, 1.5);

        // Coordinate labels
        ctx.fillStyle = 'rgba(6, 182, 212, 0.6)';
        ctx.font = '7px monospace';
        ctx.fillText('Ground Level (Y: 220px)', 8, 215);
        ctx.fillText(`Scale: W:${customWidth}px H:${customHeight}px`, 8, 15);
        ctx.restore();
      }

      // 3. Draw Character Sprite or Fallback Vector
      ctx.save();
      const charX = width / 2;
      const charY = 220 - (customFloorOffset || 0); // Standing ground position with custom floor offset

      ctx.translate(charX, charY);
      ctx.scale(previewDirection, 1);

      // Determine the sprite URL for active state
      let spriteUrl: string | undefined;
      let stateKey = previewState;
      let customUrlOrUrls = activeChar.customSprites?.[stateKey];

      // Fallback state transitions
      if (!customUrlOrUrls && activeChar.customSprites) {
        if (stateKey === 'walk' && activeChar.customSprites['idle']) {
          customUrlOrUrls = activeChar.customSprites['idle'];
          stateKey = 'idle';
        } else if ((stateKey === 'hit' || stateKey === 'ko') && activeChar.customSprites['idle']) {
          customUrlOrUrls = activeChar.customSprites['idle'];
          stateKey = 'idle';
        } else if (stateKey === 'block' && activeChar.customSprites['idle']) {
          customUrlOrUrls = activeChar.customSprites['idle'];
          stateKey = 'idle';
        }
      }

      // Get frame
      if (customUrlOrUrls) {
        if (Array.isArray(customUrlOrUrls)) {
          if (customUrlOrUrls.length > 0) {
            // Animating states
            let frameIdx = 0;
            if (stateKey === 'punch' || stateKey === 'kick') {
              const slowTick = Math.floor(tick / 8);
              frameIdx = slowTick % customUrlOrUrls.length;
            } else if (stateKey === 'ko') {
              frameIdx = customUrlOrUrls.length - 1;
            } else {
              const slowTick = Math.floor(tick / 10);
              frameIdx = slowTick % customUrlOrUrls.length;
            }
            spriteUrl = customUrlOrUrls[frameIdx];
          }
        } else {
          spriteUrl = customUrlOrUrls;
        }
      }

      let drawSuccess = false;
      if (spriteUrl) {
        const spriteImg = getCachedImage(spriteUrl);
        if (spriteImg) {
          ctx.save();
          
          // Apply states specific rotations/translations
          if (previewState === 'hit') {
            ctx.rotate(-0.25);
            ctx.translate(Math.sin(tick * 0.5) * 3, 0);
          } else if (previewState === 'ko') {
            ctx.rotate(-Math.PI / 2);
            ctx.translate(-customHeight / 3, customHeight / 3);
          } else if (previewState === 'walk') {
            ctx.translate(0, Math.sin(tick * 0.2) * 3);
          }

          // Sprite sizing matching GameCanvas drawing
          const drawW = customWidth * 2.5;
          const drawH = customHeight + 25 * (customHeight / 115);

          ctx.drawImage(
            spriteImg,
            -drawW / 2,
            -customHeight - 25 * (customHeight / 115) / 2,
            drawW,
            drawH
          );
          ctx.restore();
          drawSuccess = true;
        }
      }

      // Fallback Vector representation if image not loaded or not defined
      if (!drawSuccess) {
        ctx.save();
        const color = activeChar.avatarColor || '#ff4500';

        // Apply visual rotation/offset for states
        if (previewState === 'hit') {
          ctx.rotate(-0.08);
          ctx.translate(-5, 0);
        } else if (previewState === 'ko') {
          ctx.rotate(-Math.PI / 2.2);
        } else if (previewState === 'walk') {
          ctx.translate(0, Math.sin(tick * 0.2) * 3);
        }

        // Draw basic silhouette matching character size!
        ctx.fillStyle = '#22143c';
        ctx.strokeStyle = color;
        ctx.lineWidth = 2;
        ctx.beginPath();
        const scaleX = customWidth / 60;
        const scaleY = customHeight / 115;

        // Draw scaled torso block
        ctx.fillRect(-16 * scaleX, -70 * scaleY, 32 * scaleX, 45 * scaleY);
        ctx.strokeRect(-16 * scaleX, -70 * scaleY, 32 * scaleX, 45 * scaleY);

        // Glowing Core Symbol
        ctx.fillStyle = color;
        ctx.beginPath();
        ctx.arc(0, -50 * scaleY, 5 * scaleX, 0, Math.PI * 2);
        ctx.fill();

        // Draw Head / Helmet
        ctx.fillStyle = '#fce4ec';
        ctx.beginPath();
        ctx.arc(0, -85 * scaleY, 13 * scaleY, 0, Math.PI * 2);
        ctx.fill();

        // Visor mask
        ctx.fillStyle = '#11011e';
        ctx.fillRect(-10 * scaleX, -89 * scaleY, 18 * scaleX, 6 * scaleY);
        ctx.fillStyle = color;
        ctx.fillRect(-8 * scaleX, -88 * scaleY, 14 * scaleX, 3 * scaleY);

        // Legs
        ctx.lineWidth = 6 * scaleX;
        ctx.strokeStyle = '#1a112c';
        ctx.beginPath();
        ctx.moveTo(-8 * scaleX, -25 * scaleY);
        ctx.lineTo(-12 * scaleX, 0);
        ctx.stroke();

        ctx.beginPath();
        ctx.moveTo(8 * scaleX, -25 * scaleY);
        ctx.lineTo(12 * scaleX, 0);
        ctx.stroke();

        // Arms
        ctx.strokeStyle = '#2d184e';
        ctx.lineWidth = 5 * scaleX;
        let handX = 20 * scaleX;
        let handY = -50 * scaleY;

        if (previewState === 'punch') {
          handX = 42 * scaleX;
          handY = -55 * scaleY;
        } else if (previewState === 'kick') {
          handX = 15 * scaleX;
          handY = -45 * scaleY;
        } else if (previewState === 'block') {
          handX = 14 * scaleX;
          handY = -65 * scaleY;
        }

        ctx.beginPath();
        ctx.moveTo(-10 * scaleX, -60 * scaleY);
        ctx.lineTo(-18 * scaleX, -45 * scaleY);
        ctx.stroke();

        ctx.beginPath();
        ctx.moveTo(10 * scaleX, -60 * scaleY);
        ctx.lineTo(handX, handY);
        ctx.stroke();

        ctx.fillStyle = color;
        ctx.beginPath();
        ctx.arc(handX, handY, 5 * scaleX, 0, Math.PI * 2);
        ctx.fill();

        ctx.restore();
      }

      ctx.restore();

      // 4. Draw Hurtbox (Green Glow)
      ctx.save();
      let hW = customWidth;
      let hH = customHeight;
      let hX = charX - customWidth / 2;
      let hY = charY - customHeight;

      if (hurtboxWidthPercent !== undefined) {
        hW = (customWidth * hurtboxWidthPercent) / 100;
      }
      if (hurtboxHeightPercent !== undefined) {
        hH = (customHeight * hurtboxHeightPercent) / 100;
      }

      hX += (customWidth - hW) / 2 + (previewDirection === 1 ? hurtboxOffsetX : -hurtboxOffsetX);
      hY += hurtboxOffsetY;

      ctx.shadowColor = '#10b981';
      ctx.shadowBlur = 4;
      ctx.fillStyle = 'rgba(16, 185, 129, 0.25)';
      ctx.strokeStyle = '#10b981';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.roundRect(hX, hY, hW, hH, 4);
      ctx.fill();
      ctx.stroke();

      ctx.shadowBlur = 0;
      ctx.fillStyle = '#10b981';
      ctx.font = 'bold 8px Inter, sans-serif';
      ctx.fillText('HURTBOX / محدوده آسیب', hX + 5, hY + 12);
      ctx.restore();

      // 5. Draw Attack Hitbox if state is punch or kick
      if (previewState === 'punch' || previewState === 'kick') {
        ctx.save();
        const mRange = previewState === 'punch' ? punchRange : kickRange;
        const mHeight = previewState === 'punch' ? punchHeight : kickHeight;
        const mOffsetY = previewState === 'punch' ? punchOffsetY : kickOffsetY;

        const aW = mRange;
        const aH = mHeight;
        let aX = charX + (customWidth / 2) * previewDirection;

        if (previewDirection === -1) {
          aX -= aW;
        }
        const aY = charY - customHeight + mOffsetY;

        ctx.shadowColor = '#ef4444';
        ctx.shadowBlur = 5;
        ctx.fillStyle = 'rgba(239, 68, 68, 0.35)';
        ctx.strokeStyle = '#ef4444';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.roundRect(aX, aY, aW, aH, 4);
        ctx.fill();
        ctx.stroke();

        ctx.shadowBlur = 0;
        ctx.fillStyle = '#ef4444';
        ctx.font = 'bold 8px Inter, sans-serif';
        ctx.fillText(
          previewState === 'punch' ? 'PUNCH / ضربه مشت' : 'KICK / ضربه لگد',
          aX + 5,
          aY + 12
        );
        ctx.restore();
      }

      animFrameId.current = requestAnimationFrame(render);
    };

    render();

    return () => {
      if (animFrameId.current) {
        cancelAnimationFrame(animFrameId.current);
      }
    };
  }, [
    activeChar,
    customWidth,
    customHeight,
    hurtboxWidthPercent,
    hurtboxHeightPercent,
    hurtboxOffsetX,
    hurtboxOffsetY,
    punchRange,
    punchHeight,
    punchOffsetY,
    kickRange,
    kickHeight,
    kickOffsetY,
    previewState,
    previewDirection,
    showGrid,
    settings,
  ]);

  return (
    <div className="relative w-full rounded-2xl overflow-hidden border border-slate-800 bg-slate-950 flex flex-col items-center">
      <canvas
        ref={canvasRef}
        width={500}
        height={280}
        className="w-full h-auto aspect-[500/280] block object-contain"
      />
    </div>
  );
};
