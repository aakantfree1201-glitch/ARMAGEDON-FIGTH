/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { CharacterConfig, GameSettings } from '../types';
import { Trophy, Users, Cpu, Flame, Volume2, VolumeX } from 'lucide-react';
import audioSynth from '../audio';

const FighterPortrait: React.FC<{ character: CharacterConfig; isP1: boolean; isVsAi: boolean }> = ({ character, isP1, isVsAi }) => {
  const color = character.avatarColor || '#06b6d4';
  const glowShadow = isP1 
    ? 'shadow-[0_0_25px_rgba(34,211,238,0.5)] border-cyan-400' 
    : 'shadow-[0_0_25px_rgba(251,146,60,0.5)] border-orange-500';
  
  return (
    <div className={`w-full relative h-[190px] sm:h-[240px] md:h-[290px] bg-slate-950 rounded-xl overflow-hidden border-[3px] shadow-[0_10px_25px_rgba(0,0,0,0.8),_inset_0_2px_8px_rgba(255,255,255,0.05)] group transition-all duration-500 ${glowShadow}`}>
      {/* Dynamic Cyber Scanning grid overlay */}
      <div className="absolute inset-0 bg-[radial-gradient(rgba(0,0,0,0.15)_2px,transparent_2px)] bg-[size:10px_10px] opacity-45 pointer-events-none" />
      
      {/* Scanning laser line */}
      <div className={`absolute left-0 right-0 h-[2px] opacity-60 animate-[scan_3s_linear_infinite] pointer-events-none ${isP1 ? 'bg-cyan-400 shadow-[0_0_8px_rgba(34,211,238,0.8)]' : 'bg-orange-500 shadow-[0_0_8px_rgba(251,146,60,0.8)]'}`} />

      {character.menuPortrait ? (
        <img 
          src={character.menuPortrait} 
          alt={character.nameFa} 
          referrerPolicy="no-referrer"
          className="absolute inset-0 w-full h-full object-cover object-center transition-all duration-700 ease-out group-hover:scale-110 group-hover:rotate-1" 
        />
      ) : (
        <div 
          className="w-full h-full flex items-center justify-center text-7xl transition-all duration-500 group-hover:scale-125"
          style={{ 
            background: `radial-gradient(circle, ${color}33 0%, transparent 70%)`,
            filter: `drop-shadow(0 0 15px ${color}66)`
          }}
        >
          {character.avatar || '🥊'}
        </div>
      )}

      {/* Cyber gradient overlay */}
      <div className="absolute inset-x-0 bottom-0 h-2/3 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent pointer-events-none" />
      
      {/* Name and class badges */}
      <div className="absolute bottom-3 left-3 right-3 bg-slate-950/90 border border-slate-800/80 p-3 rounded-xl flex justify-between items-center backdrop-blur-md shadow-lg transform group-hover:translate-y-[-2px] transition-all duration-300">
        <div>
          <h4 className="text-sm font-black text-white tracking-wide">{character.nameFa}</h4>
          <span className="text-[10px] text-slate-400 block leading-tight mt-0.5 font-mono">{character.name}</span>
        </div>
        <span 
          className="text-[10px] font-mono px-2 py-0.5 rounded font-black tracking-widest text-white shadow"
          style={{ 
            backgroundColor: isP1 ? '#06b6d4' : '#f97316',
            boxShadow: isP1 ? '0 0 10px rgba(34,211,238,0.4)' : '0 0 10px rgba(249,115,22,0.4)'
          }}
        >
          {isP1 ? 'PLAYER 1' : isVsAi ? 'CPU' : 'PLAYER 2'}
        </span>
      </div>
    </div>
  );
};

interface CharacterSelectProps {
  characters: CharacterConfig[];
  onStartGame: (p1: CharacterConfig, p2: CharacterConfig, isVsAi: boolean, settings: GameSettings) => void;
  settings: GameSettings;
  onUpdateSettings: (settings: GameSettings) => void;
}

export const CharacterSelect: React.FC<CharacterSelectProps> = ({
  characters,
  onStartGame,
  settings,
  onUpdateSettings,
}) => {
  const [selectedP1Index, setSelectedP1Index] = useState(0);
  const [selectedP2Index, setSelectedP2Index] = useState(1);
  const [hasSetDefaults, setHasSetDefaults] = useState(false);
  const [isVsAi, setIsVsAi] = useState(true);
  const [aiDifficulty, setAiDifficulty] = useState<GameSettings['aiDifficulty']>('medium');
  const [soundEnabled, setSoundEnabled] = useState(true);

  // Filter out the two hardcoded default characters (Cyber Fighter and Blaze Fighter) from selection menu
  const displayList = characters.filter(c => c.id !== 'custom_fighter' && c.id !== 'blaze_fighter');
  const finalCharacters = displayList.length > 0 ? displayList : characters;

  // Safe fallback indices to prevent crashes when characters are deleted or loaded from database
  const p1Index = selectedP1Index >= finalCharacters.length ? 0 : selectedP1Index;
  const p2Index = selectedP2Index >= finalCharacters.length ? (finalCharacters.length > 1 ? 1 : 0) : selectedP2Index;

  // Automatically select Ramon for Player 1 and Maryam Amirjalali for Player 2 as the retro default matchup
  useEffect(() => {
    if (finalCharacters.length > 0 && !hasSetDefaults) {
      const ramonIdx = finalCharacters.findIndex(c => 
        c.nameFa?.includes('رامون') || 
        c.name?.toLowerCase().includes('ramon') || 
        c.name?.toLowerCase().includes('ramoun')
      );
      const maryamIdx = finalCharacters.findIndex(c => 
        c.nameFa?.includes('مریم') || 
        c.nameFa?.includes('امیرجلالی') || 
        c.name?.toLowerCase().includes('maryam') || 
        c.name?.toLowerCase().includes('amirjalali')
      );

      let p1Selected = false;
      let p2Selected = false;

      if (ramonIdx !== -1) {
        setSelectedP1Index(ramonIdx);
        p1Selected = true;
      }
      if (maryamIdx !== -1) {
        setSelectedP2Index(maryamIdx);
        p2Selected = true;
      }

      if (p1Selected || p2Selected || finalCharacters.length > 2) {
        setHasSetDefaults(true);
      }
    }
  }, [finalCharacters, hasSetDefaults]);

  const handleSelectP1 = (idx: number) => {
    setSelectedP1Index(idx);
    audioSynth.playAnnouncer('select');
  };

  const handleSelectP2 = (idx: number) => {
    setSelectedP2Index(idx);
    audioSynth.playAnnouncer('select');
  };

  const handleToggleVsAi = (vsAi: boolean) => {
    setIsVsAi(vsAi);
    audioSynth.playAnnouncer('select');
  };

  const handleToggleSound = () => {
    const state = audioSynth.toggleMute();
    setSoundEnabled(!state);
  };

  const handleStart = () => {
    const p1 = finalCharacters[p1Index] || finalCharacters[0];
    const p2 = finalCharacters[p2Index] || finalCharacters[0];

    onStartGame(p1, p2, isVsAi, {
      ...settings,
      aiDifficulty,
    });
  };

  const p1Char = finalCharacters[p1Index] || finalCharacters[0];
  const p2Char = finalCharacters[p2Index] || finalCharacters[0];

  // Grid logic: Align characters in a beautiful Mortal Kombat layout with a center logo
  const cols = 3;
  const totalSlots = 9; 
  const logoIndex = 4; // Center slot for premium Mortal Kombat emblem

  const getGridItem = (index: number) => {
    if (index === logoIndex) {
      return (
        <div 
          key="emblem"
          className="w-[75px] h-[95px] sm:w-[105px] sm:h-[130px] md:w-[130px] md:h-[160px] flex items-center justify-center"
        >
          <div 
            className="w-14 h-14 sm:w-18 sm:h-18 md:w-22 md:h-22 rounded-full bg-gradient-to-br from-yellow-500 via-orange-600 to-red-600 border-[3px] border-black shadow-[0_0_15px_rgba(249,115,22,0.6),inset_0_2px_4px_rgba(255,255,255,0.3)] flex items-center justify-center relative cursor-pointer hover:scale-110 hover:brightness-110 active:scale-95 transition-all duration-300 group"
            title="MORTAL KOMBAT RETRO CHALLENGE"
            onClick={() => audioSynth.playAnnouncer('fight')}
          >
            <span className="text-xl sm:text-2xl md:text-3xl filter drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)] select-none">🐉</span>
            {/* Pulsing ring */}
            <div className="absolute inset-0 rounded-full border-2 border-yellow-400 animate-ping opacity-25 pointer-events-none" />
          </div>
        </div>
      );
    }

    // Map grid positions to finalCharacters
    let charIndex = index;
    if (index > logoIndex) {
      charIndex = index - 1; // shift back because of center logo
    }

    if (charIndex >= finalCharacters.length) {
      const row = Math.floor(index / cols);
      const col = index % cols;
      return (
        <div 
          key={`empty-${row}-${col}`} 
          className="w-[75px] h-[95px] sm:w-[105px] sm:h-[130px] md:w-[130px] md:h-[160px] invisible"
        />
      );
    }

    const char = finalCharacters[charIndex];
    const isP1Selected = p1Index === charIndex;
    const isP2Selected = p2Index === charIndex;

    return (
      <div
        key={char.id}
        onClick={() => handleSelectP1(charIndex)}
        className={`relative w-[75px] h-[95px] sm:w-[105px] sm:h-[130px] md:w-[130px] md:h-[160px] border-4 bg-slate-950 overflow-hidden cursor-pointer group transition-all duration-300 rounded-lg shadow-md ${
          isP1Selected && isP2Selected
            ? 'border-yellow-400 scale-105 shadow-[0_0_20px_rgba(234,179,8,0.9)] z-10'
            : isP1Selected
              ? 'border-cyan-400 scale-105 shadow-[0_0_20px_rgba(34,211,238,0.8)] z-10'
              : isP2Selected
                ? 'border-orange-500 scale-105 shadow-[0_0_20px_rgba(249,115,22,0.8)] z-10'
                : 'border-slate-800 hover:border-slate-600 hover:scale-102 hover:shadow-lg'
        }`}
      >
        {/* Grid Avatar Portrait */}
        {char.menuPortrait ? (
          <img 
            src={char.menuPortrait} 
            alt={char.nameFa} 
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover object-top transition-transform duration-500 group-hover:scale-110" 
          />
        ) : (
          <div 
            className="w-full h-full flex items-center justify-center text-3xl sm:text-4xl md:text-5xl bg-slate-900"
            style={{ 
              background: `radial-gradient(circle, ${char.avatarColor || '#1e293b'}44 0%, transparent 80%)`
            }}
          >
            {char.avatar || '🥊'}
          </div>
        )}

        {/* Selection Indicators (Floating text overlays) */}
        {isP1Selected && (
          <div className="absolute top-1 left-1 bg-cyan-400 text-slate-950 font-black text-[9px] sm:text-[10px] px-1.5 py-0.5 rounded border border-black shadow">
            1P
          </div>
        )}
        {isP2Selected && (
          <div className="absolute top-1 right-1 bg-orange-500 text-slate-950 font-black text-[9px] sm:text-[10px] px-1.5 py-0.5 rounded border border-black shadow">
            {isVsAi ? 'CPU' : '2P'}
          </div>
        )}

        {/* Dynamic Scanline bar inside grid cards on hover */}
        <div className="absolute inset-x-0 h-1/2 bg-gradient-to-b from-white/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none" />

        {/* Name Bar overlay */}
        <div className="absolute bottom-0 inset-x-0 bg-slate-950/85 border-t border-slate-900 py-1 px-1.5 text-center backdrop-blur-xs">
          <div className="text-[10px] sm:text-xs font-black text-white truncate drop-shadow">
            {char.nameFa}
          </div>
          <div className="text-[8px] text-slate-400 truncate tracking-tighter uppercase font-mono">
            {char.name}
          </div>
        </div>

        {/* Dual Quick Selector Corner Tabs */}
        <div className="absolute inset-x-0 top-0 h-1/3 opacity-0 group-hover:opacity-100 transition-opacity flex justify-between p-1 bg-slate-950/40 pointer-events-none">
          <button
            onClick={(e) => {
              e.stopPropagation();
              handleSelectP1(charIndex);
            }}
            className="pointer-events-auto bg-cyan-500 text-slate-950 hover:bg-cyan-400 text-[8px] font-black w-5 h-5 rounded-full flex items-center justify-center shadow border border-black transform hover:scale-110 transition active:scale-95"
            title="Select as Player 1"
          >
            1P
          </button>
          <button
            onClick={(e) => {
              e.stopPropagation();
              handleSelectP2(charIndex);
            }}
            className="pointer-events-auto bg-orange-500 text-slate-950 hover:bg-orange-400 text-[8px] font-black w-5 h-5 rounded-full flex items-center justify-center shadow border border-black transform hover:scale-110 transition active:scale-95"
            title="Select as Player 2"
          >
            2P
          </button>
        </div>
      </div>
    );
  };

  return (
    <div id="character-selection-screen" className="w-full flex flex-col gap-6 p-4 bg-slate-950 text-slate-100 font-sans rounded-2xl relative overflow-hidden select-none">
      
      {/* HEADER SECTION */}
      <div className="flex justify-between items-center bg-slate-900/60 p-4 rounded-xl border border-slate-800">
        <div className="flex items-center gap-2">
          <Trophy className="w-5 h-5 text-yellow-400 animate-pulse" />
          <h3 className="text-sm font-bold text-slate-300 font-mono tracking-wider">
            مبارزه بازی‌های ویدیویی قدیمی (Retro Challenge)
          </h3>
        </div>
        <button 
          onClick={handleToggleSound}
          className="bg-slate-900 border border-slate-700 hover:bg-slate-800 transition p-2.5 rounded-lg text-slate-300 active:scale-95 cursor-pointer"
        >
          {soundEnabled ? <Volume2 className="w-4 h-4 text-cyan-400" /> : <VolumeX className="w-4 h-4 text-slate-500" />}
        </button>
      </div>

      <div className="text-center">
        <h2 className="text-yellow-400 font-black text-2xl sm:text-3xl tracking-widest select-none animate-[pulse_2s_infinite]">
          انتخاب مبارز / CHOOSE YOUR FIGHTER
        </h2>
        <div className="h-0.5 w-32 bg-yellow-400 mx-auto mt-2" />
      </div>

      {/* THREE-COLUMN LAYOUT: PREVIEWS + GRID */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 items-center mt-2">
        
        {/* PLAYER 1 PREVIEW BOX */}
        <div className="bg-slate-900/40 p-4 rounded-xl border border-slate-800 flex flex-col gap-4">
          <div className="flex justify-between items-center border-b border-cyan-500/20 pb-2">
            <span className="text-cyan-400 text-xs font-bold">بازیکن اول (P1)</span>
            <span className="text-[9px] bg-cyan-950 text-cyan-400 px-1.5 py-0.5 rounded font-mono">WASD KEYS</span>
          </div>

          <FighterPortrait character={p1Char} isP1={true} isVsAi={isVsAi} />

          {/* Stats */}
          <div className="flex flex-col gap-2 text-xs">
            <div className="flex justify-between text-slate-400">
              <span>سرعت / SPEED:</span>
              <span className="text-cyan-400 font-bold">{p1Char.speed}/5</span>
            </div>
            <div className="w-full bg-slate-950 h-1.5 rounded-full overflow-hidden">
              <div className="h-full bg-cyan-400" style={{ width: `${(p1Char.speed / 5) * 100}%` }} />
            </div>

            <div className="flex justify-between text-slate-400">
              <span>سلامتی / HEALTH:</span>
              <span className="text-emerald-400 font-bold">{p1Char.maxHealth}HP</span>
            </div>
            <div className="w-full bg-slate-950 h-1.5 rounded-full overflow-hidden">
              <div className="h-full bg-emerald-400" style={{ width: `${(p1Char.maxHealth / 120) * 100}%` }} />
            </div>
          </div>
        </div>

        {/* CHARACTER GRID (Takes 2 Columns on large screens) */}
        <div className="lg:col-span-2 bg-slate-900/20 p-5 rounded-2xl border border-slate-800 flex flex-col gap-4 items-center justify-center">
          <div className="grid grid-cols-3 gap-4">
            {Array.from({ length: totalSlots }).map((_, idx) => getGridItem(idx))}
          </div>
        </div>

        {/* PLAYER 2 PREVIEW BOX */}
        <div className="bg-slate-900/40 p-4 rounded-xl border border-slate-800 flex flex-col gap-4">
          <div className="flex justify-between items-center border-b border-orange-500/20 pb-2">
            <span className="text-orange-400 text-xs font-bold">
              {isVsAi ? 'کامپیوتر (CPU)' : 'بازیکن دوم (P2)'}
            </span>
            <span className="text-[9px] bg-orange-950 text-orange-400 px-1.5 py-0.5 rounded font-mono">
              {isVsAi ? 'AUTO AI' : 'ARROW KEYS'}
            </span>
          </div>

          <FighterPortrait character={p2Char} isP1={false} isVsAi={isVsAi} />

          {/* Stats */}
          <div className="flex flex-col gap-2 text-xs">
            <div className="flex justify-between text-slate-400">
              <span>سرعت / SPEED:</span>
              <span className="text-orange-400 font-bold">{p2Char.speed}/5</span>
            </div>
            <div className="w-full bg-slate-950 h-1.5 rounded-full overflow-hidden">
              <div className="h-full bg-orange-400" style={{ width: `${(p2Char.speed / 5) * 100}%` }} />
            </div>

            <div className="flex justify-between text-slate-400">
              <span>سلامتی / HEALTH:</span>
              <span className="text-emerald-400 font-bold">{p2Char.maxHealth}HP</span>
            </div>
            <div className="w-full bg-slate-950 h-1.5 rounded-full overflow-hidden">
              <div className="h-full bg-emerald-400" style={{ width: `${(p2Char.maxHealth / 120) * 100}%` }} />
            </div>
          </div>
        </div>

      </div>

      {/* SETTINGS AND ACTION CENTER */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-slate-900/30 p-4 rounded-xl border border-slate-800 mt-2">
        
        {/* Match Settings Info */}
        <div className="flex flex-col gap-3">
          <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider pb-1 border-b border-slate-800">
            تنظیمات مبارزه (Battle Settings)
          </h4>

          {/* Opponent Type Toggle */}
          <div className="flex flex-col gap-1.5">
            <span className="text-xs text-slate-400">حالت مبارزه:</span>
            <div className="grid grid-cols-2 gap-2 bg-slate-950 p-1 rounded-lg border border-slate-800">
              <button
                onClick={() => handleToggleVsAi(true)}
                className={`py-1.5 rounded-md font-bold text-xs flex items-center justify-center gap-1.5 transition cursor-pointer ${
                  isVsAi 
                    ? 'bg-yellow-400 text-slate-950' 
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <Cpu className="w-3.5 h-3.5" />
                مبارزه با کامپیوتر
              </button>
              <button
                onClick={() => handleToggleVsAi(false)}
                className={`py-1.5 rounded-md font-bold text-xs flex items-center justify-center gap-1.5 transition cursor-pointer ${
                  !isVsAi 
                    ? 'bg-cyan-400 text-slate-950' 
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <Users className="w-3.5 h-3.5" />
                دو نفره محلی
              </button>
            </div>
          </div>

          {/* AI Difficulty */}
          {isVsAi && (
            <div className="flex flex-col gap-1.5">
              <span className="text-xs text-slate-400">درجه سختی هوش مصنوعی:</span>
              <div className="grid grid-cols-5 gap-1">
                {(['practice', 'easy', 'medium', 'hard', 'impossible'] as const).map((diff) => (
                  <button
                    key={diff}
                    onClick={() => setAiDifficulty(diff)}
                    className={`py-1 rounded text-[9px] font-bold border transition cursor-pointer ${
                      aiDifficulty === diff 
                        ? 'bg-yellow-950/40 border-yellow-400 text-yellow-400 shadow-[0_0_8px_rgba(234,179,8,0.2)]' 
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    {diff === 'practice' && 'تمرینی'}
                    {diff === 'easy' && 'ساده'}
                    {diff === 'medium' && 'متوسط'}
                    {diff === 'hard' && 'سخت'}
                    {diff === 'impossible' && 'وحشی'}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Moves & Hitbox Toggle & Start Button */}
        <div className="flex flex-col gap-3 justify-between">
          <div className="flex flex-col gap-2">
            <span className="text-xs text-slate-400 font-bold border-b border-slate-800 pb-1 flex items-center gap-1">
              <Flame className="w-3.5 h-3.5 text-orange-400" />
              ضربات رزمی فعال {p1Char.nameFa}:
            </span>
            <div className="flex flex-wrap gap-1.5 max-h-16 overflow-y-auto text-[10px] text-slate-300">
              {p1Char.moves.map((move) => (
                <div key={move.id} className="bg-slate-950 px-2 py-0.5 rounded border border-slate-800">
                  <span className="font-bold">{move.name}</span>{' '}
                  <span className="text-slate-500">({move.key})</span>
                </div>
              ))}
            </div>

            {/* Hitbox switch */}
            <label className="flex items-center justify-between cursor-pointer text-[10px] mt-1 text-right" dir="rtl">
              <span className="text-slate-300 font-bold font-mono">SHOW HITBOXES / نمایش محدوده ضربات (کلید T)</span>
              <input
                type="checkbox"
                checked={!!settings.showHitboxes}
                onChange={(e) => onUpdateSettings({ ...settings, showHitboxes: e.target.checked })}
                className="w-4 h-4 rounded bg-slate-800 border-slate-700 text-yellow-500 cursor-pointer accent-yellow-400"
              />
            </label>
          </div>

          <button
            onClick={handleStart}
            className="w-full bg-gradient-to-r from-yellow-400 via-orange-500 to-red-500 text-slate-950 font-black py-2.5 rounded-lg hover:brightness-110 active:scale-98 transition shadow-lg text-center uppercase tracking-widest text-xs cursor-pointer border-b-2 border-red-800"
          >
            START BATTLE / شروع مبارزه
          </button>
        </div>

      </div>

    </div>
  );
};

export default CharacterSelect;
