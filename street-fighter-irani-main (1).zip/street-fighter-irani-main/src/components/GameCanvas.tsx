/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState } from 'react';
import { CharacterConfig, FighterState, Projectile, Particle, GameSettings } from '../types';
import audioSynth from '../audio';

const isMaryam = (char?: CharacterConfig): boolean => {
  if (!char) return false;
  return !!(
    char.name?.includes('مریم') ||
    char.nameFa?.includes('مریم') ||
    char.name?.toLowerCase().includes('maryam') ||
    char.nameFa?.toLowerCase().includes('maryam') ||
    char.name?.toLowerCase().includes('amirjalali') ||
    char.nameFa?.toLowerCase().includes('amirjalali')
  );
};

interface GameCanvasProps {
  player1Char: CharacterConfig;
  player2Char: CharacterConfig;
  isVsAi: boolean;
  settings: GameSettings;
  onGameEnd: (winner: string, perfect: boolean) => void;
  isPaused: boolean;
  onTogglePause: () => void;
}

export const GameCanvas: React.FC<GameCanvasProps> = ({
  player1Char,
  player2Char,
  isVsAi,
  settings,
  onGameEnd,
  isPaused,
  onTogglePause,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const imageCache = useRef<Record<string, HTMLImageElement>>({});

  // Core Game Loop State
  const [p1Health, setP1Health] = useState(100);
  const [p2Health, setP2Health] = useState(100);
  const [p1Energy, setP1Energy] = useState(0);
  const [p2Energy, setP2Energy] = useState(0);
  const [p1Combo, setP1Combo] = useState(0);
  const [p2Combo, setP2Combo] = useState(0);
  const [gameTimer, setGameTimer] = useState(settings.roundDuration);
  const [roundOver, setRoundOver] = useState(false);
  const [announcerText, setAnnouncerText] = useState<'ROUND 1' | 'FIGHT!' | 'K.O.' | 'DRAW' | 'PLAYER 1 WINS' | 'PLAYER 2 WINS' | 'AI WINS' | null>('ROUND 1');

  // Input states tracking
  const keysPressed = useRef<Set<string>>(new Set());

  // Refs for animation physics to avoid react trigger delays in loop
  const p1Ref = useRef<FighterState>({
    id: 'p1',
    name: player1Char.name,
    x: 150,
    y: 340,
    width: player1Char.customWidth || 60,
    height: player1Char.customHeight || 115,
    velocityX: 0,
    velocityY: 0,
    isJumping: false,
    isCrouching: false,
    isBlocking: false,
    direction: 1,
    health: player1Char.maxHealth,
    maxHealth: player1Char.maxHealth,
    energy: 0,
    currentState: 'idle',
    currentFrame: 0,
    stateTimer: 0,
    comboCount: 0,
    comboTimer: 0,
  });

  const p2Ref = useRef<FighterState>({
    id: 'p2',
    name: player2Char.name,
    x: 650,
    y: 340,
    width: player2Char.customWidth || 60,
    height: player2Char.customHeight || 115,
    velocityX: 0,
    velocityY: 0,
    isJumping: false,
    isCrouching: false,
    isBlocking: false,
    direction: -1,
    health: player2Char.maxHealth,
    maxHealth: player2Char.maxHealth,
    energy: 0,
    currentState: 'idle',
    currentFrame: 0,
    stateTimer: 0,
    comboCount: 0,
    comboTimer: 0,
  });

  // Projectiles & Particle lists
  const projectilesRef = useRef<Projectile[]>([]);
  const particlesRef = useRef<Particle[]>([]);
  const cameraShakeRef = useRef({ x: 0, y: 0, duration: 0 });

  // Canvas size state
  const [canvasWidth, setCanvasWidth] = useState(800);
  const [canvasHeight, setCanvasHeight] = useState(450);

  // Handle Resize using ResizeObserver
  useEffect(() => {
    if (!containerRef.current) return;
    const observer = new ResizeObserver((entries) => {
      for (const entry of entries) {
        // Maintain fixed aspect ratio 16:9 for retro arcade scale
        const w = entry.contentRect.width;
        const h = w * (450 / 800);
        setCanvasWidth(w);
        setCanvasHeight(h);
      }
    });
    observer.observe(containerRef.current);
    return () => observer.disconnect();
  }, []);

  // Sync state to refs if characters change
  useEffect(() => {
    p1Ref.current.name = player1Char.name;
    p1Ref.current.health = player1Char.maxHealth;
    p1Ref.current.maxHealth = player1Char.maxHealth;
    p1Ref.current.width = player1Char.customWidth || 60;
    p1Ref.current.height = player1Char.customHeight || 115;
    p1Ref.current.y = 340 - (player1Char.customFloorOffset || 0);
    
    p2Ref.current.name = player2Char.name;
    p2Ref.current.health = player2Char.maxHealth;
    p2Ref.current.maxHealth = player2Char.maxHealth;
    p2Ref.current.width = player2Char.customWidth || 60;
    p2Ref.current.height = player2Char.customHeight || 115;
    p2Ref.current.y = 340 - (player2Char.customFloorOffset || 0);

    setP1Health(player1Char.maxHealth);
    setP2Health(player2Char.maxHealth);
    setGameTimer(settings.roundDuration);
    setRoundOver(false);
    setAnnouncerText('ROUND 1');
    audioSynth.playAnnouncer('round1');

    setTimeout(() => {
      setAnnouncerText('FIGHT!');
      audioSynth.playAnnouncer('fight');
      setTimeout(() => {
        setAnnouncerText(null);
      }, 1000);
    }, 1500);

  }, [player1Char, player2Char]);

  // Audio start trigger on mount
  useEffect(() => {
    audioSynth.playAnnouncer('start');
  }, []);

  // Preload custom images
  useEffect(() => {
    const preload = (char: CharacterConfig) => {
      if (!char.customSprites) return;
      Object.values(char.customSprites).forEach((val) => {
        if (!val) return;
        if (Array.isArray(val)) {
          val.forEach((url) => {
            if (url && !imageCache.current[url]) {
              const img = new Image();
              img.referrerPolicy = 'no-referrer';
              img.src = url;
              imageCache.current[url] = img;
            }
          });
        } else if (typeof val === 'string') {
          if (!imageCache.current[val]) {
            const img = new Image();
            img.referrerPolicy = 'no-referrer';
            img.src = val;
            imageCache.current[val] = img;
          }
        }
      });
    };
    preload(player1Char);
    preload(player2Char);
  }, [player1Char, player2Char]);

// Persian to English keyboard map for standard QWERTY layout
const FA_EN_KEY_MAP: Record<string, string> = {
  'ش': 'A',
  'ی': 'D',
  'ص': 'W',
  'س': 'S',
  'ب': 'F',
  'ل': 'G',
  'ا': 'H',
  'ه': 'I',
  'خ': 'O',
  'ح': 'P',
};

// Listen to keyboard inputs
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      let key = e.key.toUpperCase();
      const mapped = FA_EN_KEY_MAP[key] || FA_EN_KEY_MAP[e.key];
      if (mapped) {
        key = mapped;
      }
      keysPressed.current.add(key);

      // Prevent window scrolling on Arrow/Space keys
      if (['ARROWUP', 'ARROWDOWN', 'ARROWLEFT', 'ARROWRIGHT', ' '].includes(e.key)) {
        e.preventDefault();
      }

      if (e.key === 'Escape') {
        onTogglePause();
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      let key = e.key.toUpperCase();
      const mapped = FA_EN_KEY_MAP[key] || FA_EN_KEY_MAP[e.key];
      if (mapped) {
        key = mapped;
      }
      keysPressed.current.delete(key);
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [onTogglePause]);

  // Timer Countdown Effect
  useEffect(() => {
    if (isPaused || roundOver || announcerText === 'ROUND 1') return;
    
    const interval = setInterval(() => {
      setGameTimer((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          handleTimeOut();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isPaused, roundOver, announcerText]);

  // Trigger special fireball move
  const launchFireball = (ownerId: string, fighter: FighterState, charConfig: CharacterConfig) => {
    const isP1 = ownerId === 'p1';
    const launchX = fighter.x + (isP1 ? fighter.width : 0) + (fighter.direction * 10);
    const launchY = fighter.y + 35;
    
    projectilesRef.current.push({
      id: Math.random().toString(),
      ownerId,
      x: launchX,
      y: launchY,
      width: 32,
      height: 20,
      speedX: fighter.direction * 8,
      damage: charConfig.moves.find(m => m.type === 'projectile')?.damage || 20,
      color: isP1 ? '#33ccff' : '#ff9900',
      animationFrame: 0,
    });

    audioSynth.playFireball();

    // Spawn charge particles
    for (let i = 0; i < 15; i++) {
      particlesRef.current.push({
        x: launchX,
        y: launchY + 10,
        vx: (Math.random() - 0.5) * 5 + fighter.direction * 3,
        vy: (Math.random() - 0.5) * 5,
        color: isP1 ? '#33ccff' : '#ff6600',
        size: Math.random() * 4 + 2,
        life: 1,
        decay: Math.random() * 0.05 + 0.02,
        type: 'fire',
      });
    }
  };

  // Create sparks on damage/block
  const spawnHitSparks = (x: number, y: number, color: string, type: 'spark' | 'energy' | 'dust') => {
    const count = type === 'dust' ? 8 : 16;
    for (let i = 0; i < count; i++) {
      particlesRef.current.push({
        x,
        y,
        vx: (Math.random() - 0.5) * (type === 'dust' ? 2 : 10),
        vy: (Math.random() - 0.5) * (type === 'dust' ? 2 : 10) - (type === 'dust' ? 1 : 0),
        color,
        size: Math.random() * (type === 'dust' ? 5 : 4) + 1,
        life: 1,
        decay: Math.random() * 0.08 + 0.03,
        type: type === 'dust' ? 'dust' : 'spark',
      });
    }
  };

  // Handle timeout condition
  const handleTimeOut = () => {
    setRoundOver(true);
    const p1 = p1Ref.current;
    const p2 = p2Ref.current;

    if (p1.health > p2.health) {
      setAnnouncerText('PLAYER 1 WINS');
      onGameEnd('Player 1', false);
    } else if (p2.health > p1.health) {
      setAnnouncerText(isVsAi ? 'AI WINS' : 'PLAYER 2 WINS');
      onGameEnd(isVsAi ? 'AI' : 'Player 2', false);
    } else {
      setAnnouncerText('DRAW');
      onGameEnd('Draw', false);
    }
  };

  // Main game loop (runs 60 times a second inside requestAnimationFrame)
  useEffect(() => {
    let animationId: number;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const gameLoop = () => {
      if (!isPaused && !roundOver) {
        updatePhysics();
        handleCollisions();
        updateAI();
      }
      renderGame(ctx);
      animationId = requestAnimationFrame(gameLoop);
    };

    // --- PHYSICS UPDATE ENGINE ---
    const updatePhysics = () => {
      const p1 = p1Ref.current;
      const p2 = p2Ref.current;

      // 1. Friction & Gravity Constants
      const friction = 0.85;
      const gravity = 0.8;
      const groundY = 340; // baseline floor line

      // 2. State Timer Tick
      if (p1.stateTimer > 0) {
        p1.stateTimer--;
        p1.currentFrame = Math.floor(p1.stateTimer / 3) % 4; // animate
        if (p1.stateTimer === 0 && p1.currentState !== 'ko') {
          p1.currentState = 'idle';
        }
      }
      if (p2.stateTimer > 0) {
        p2.stateTimer--;
        p2.currentFrame = Math.floor(p2.stateTimer / 3) % 4;
        if (p2.stateTimer === 0 && p2.currentState !== 'ko') {
          p2.currentState = 'idle';
        }
      }

      // Track consecutive block frames to freeze block animation on last frame
      if (p1.currentState === 'block') {
        p1.blockFrames = (p1.blockFrames || 0) + 1;
      } else {
        p1.blockFrames = 0;
      }
      if (p2.currentState === 'block') {
        p2.blockFrames = (p2.blockFrames || 0) + 1;
      } else {
        p2.blockFrames = 0;
      }

      // Combo timers tick
      if (p1.comboTimer > 0) {
        p1.comboTimer--;
        if (p1.comboTimer === 0) setP1Combo(0);
      }
      if (p2.comboTimer > 0) {
        p2.comboTimer--;
        if (p2.comboTimer === 0) setP2Combo(0);
      }

      // 3. Process Player 1 Inputs (W, A, S, D, F, G, H)
      if (p1.currentState !== 'hit' && p1.currentState !== 'ko' && p1.currentState !== 'special' && p1.stateTimer === 0) {
        let isMoving = false;

        // Crouch / Block (S Key)
        if (keysPressed.current.has('S')) {
          p1.isCrouching = true;
          p1.currentState = 'block';
          p1.velocityX = 0;
        } else {
          p1.isCrouching = false;
          if (p1.currentState === 'block') p1.currentState = 'idle';

          // Horizontal Move (A / D)
          if (keysPressed.current.has('A')) {
            p1.velocityX = -player1Char.speed;
            p1.currentState = 'walk';
            isMoving = true;
          } else if (keysPressed.current.has('D')) {
            p1.velocityX = player1Char.speed;
            p1.currentState = 'walk';
            isMoving = true;
          } else {
            p1.velocityX *= friction;
          }

          // Jump (W Key)
          if (keysPressed.current.has('W') && !p1.isJumping) {
            p1.velocityY = -15;
            p1.isJumping = true;
            p1.currentState = 'jump';
            audioSynth.playPunch(); // Light whoosh
            spawnHitSparks(p1.x + p1.width / 2, p1.y + p1.height, '#cccccc', 'dust');
          }
        }

        // Punch Action (F)
        if (keysPressed.current.has('F') && p1.stateTimer === 0) {
          p1.currentState = 'punch';
          p1.stateTimer = 25; // 15 active + 10 freeze frames
          p1.velocityX = p1.direction * 3; // Lunge forward
          audioSynth.playPunch();
          checkMeleeHit('p1', p1, p2, player1Char.moves[0]); // Jab Punch
        }

        // Kick Action (G)
        else if (keysPressed.current.has('G') && p1.stateTimer === 0) {
          p1.currentState = 'kick';
          p1.stateTimer = 34; // 22 active + 12 freeze frames
          p1.velocityX = p1.direction * 4;
          audioSynth.playKick();
          checkMeleeHit('p1', p1, p2, player1Char.moves[1]); // Blaze Kick
        }

        // Special Fireball Hadouken (H)
        else if (keysPressed.current.has('H') && p1.stateTimer === 0 && p1.energy >= 30) {
          p1.currentState = 'special';
          p1.stateTimer = 25;
          p1.velocityX = -p1.direction * 2; // slight recoil
          p1.energy -= 30;
          setP1Energy(p1.energy);
          launchFireball('p1', p1, player1Char);
        }

        if (!isMoving && p1.currentState === 'walk') {
          p1.currentState = 'idle';
        }
      }

      // 4. Process Player 2 Inputs (Arrow keys, I, O, P) - ONLY if not VS AI
      if (!isVsAi && p2.currentState !== 'hit' && p2.currentState !== 'ko' && p2.currentState !== 'special' && p2.stateTimer === 0) {
        let isMoving = false;

        // Crouch / Block (Down Arrow)
        if (keysPressed.current.has('ARROWDOWN')) {
          p2.isCrouching = true;
          p2.currentState = 'block';
          p2.velocityX = 0;
        } else {
          p2.isCrouching = false;
          if (p2.currentState === 'block') p2.currentState = 'idle';

          // Horizontal Move (Left / Right Arrows)
          if (keysPressed.current.has('ARROWLEFT')) {
            p2.velocityX = -player2Char.speed;
            p2.currentState = 'walk';
            isMoving = true;
          } else if (keysPressed.current.has('ARROWRIGHT')) {
            p2.velocityX = player2Char.speed;
            p2.currentState = 'walk';
            isMoving = true;
          } else {
            p2.velocityX *= friction;
          }

          // Jump (Up Arrow)
          if (keysPressed.current.has('ARROWUP') && !p2.isJumping) {
            p2.velocityY = -15;
            p2.isJumping = true;
            p2.currentState = 'jump';
            audioSynth.playPunch();
            spawnHitSparks(p2.x + p2.width / 2, p2.y + p2.height, '#cccccc', 'dust');
          }
        }

        // Punch (I)
        if (keysPressed.current.has('I') && p2.stateTimer === 0) {
          p2.currentState = 'punch';
          p2.stateTimer = 25; // 15 active + 10 freeze frames
          p2.velocityX = p2.direction * 3;
          audioSynth.playPunch();
          checkMeleeHit('p2', p2, p1, player2Char.moves[0]);
        }

        // Kick (O)
        else if (keysPressed.current.has('O') && p2.stateTimer === 0) {
          p2.currentState = 'kick';
          p2.stateTimer = 34; // 22 active + 12 freeze frames
          p2.velocityX = p2.direction * 4;
          audioSynth.playKick();
          checkMeleeHit('p2', p2, p1, player2Char.moves[1]);
        }

        // Special Move (P)
        else if (keysPressed.current.has('P') && p2.stateTimer === 0 && p2.energy >= 30) {
          p2.currentState = 'special';
          p2.stateTimer = 25;
          p2.velocityX = -p2.direction * 2;
          p2.energy -= 30;
          setP2Energy(p2.energy);
          launchFireball('p2', p2, player2Char);
        }

        if (!isMoving && p2.currentState === 'walk') {
          p2.currentState = 'idle';
        }
      }

      // Apply physics displacement P1
      p1.velocityY += gravity;
      p1.x += p1.velocityX;
      p1.y += p1.velocityY;

      // Apply physics displacement P2
      p2.velocityY += gravity;
      p2.x += p2.velocityX;
      p2.y += p2.velocityY;

      // Bound check P1 ground
      const p1GroundY = groundY - (player1Char.customFloorOffset || 0);
      if (p1.y >= p1GroundY) {
        p1.y = p1GroundY;
        p1.velocityY = 0;
        if (p1.isJumping) {
          p1.isJumping = false;
          if (p1.currentState === 'jump') {
            if (isMaryam(player1Char)) {
              p1.currentState = 'jump';
              p1.stateTimer = 22; // Slightly longer landing freeze (22 frames = ~0.36 seconds)
              p1.velocityX = 0;
              p1.velocityY = 0;
            } else {
              p1.currentState = 'idle';
            }
          }
          spawnHitSparks(p1.x + p1.width / 2, p1GroundY + p1.height, '#cccccc', 'dust');
        }
      }

      // Bound check P2 ground
      const p2GroundY = groundY - (player2Char.customFloorOffset || 0);
      if (p2.y >= p2GroundY) {
        p2.y = p2GroundY;
        p2.velocityY = 0;
        if (p2.isJumping) {
          p2.isJumping = false;
          if (p2.currentState === 'jump') {
            if (isMaryam(player2Char)) {
              p2.currentState = 'jump';
              p2.stateTimer = 22; // Slightly longer landing freeze (22 frames = ~0.36 seconds)
              p2.velocityX = 0;
              p2.velocityY = 0;
            } else {
              p2.currentState = 'idle';
            }
          }
          spawnHitSparks(p2.x + p2.width / 2, p2GroundY + p2.height, '#cccccc', 'dust');
        }
      }

      // Keep inside screen boundaries
      const screenMargin = 10;
      p1.x = Math.max(screenMargin, Math.min(800 - p1.width - screenMargin, p1.x));
      p2.x = Math.max(screenMargin, Math.min(800 - p2.width - screenMargin, p2.x));

      // Automatic Facing Direction Calculation
      if (p1.currentState !== 'ko' && p2.currentState !== 'ko') {
        if (p1.x < p2.x) {
          p1.direction = 1;
          p2.direction = -1;
        } else {
          p1.direction = -1;
          p2.direction = 1;
        }
      }

      // Check camera shake recovery
      if (cameraShakeRef.current.duration > 0) {
        cameraShakeRef.current.duration--;
        cameraShakeRef.current.x = (Math.random() - 0.5) * 8;
        cameraShakeRef.current.y = (Math.random() - 0.5) * 8;
      } else {
        cameraShakeRef.current = { x: 0, y: 0, duration: 0 };
      }
    };

    // --- MELEE COLLISION CHECKS ---
    const checkMeleeHit = (attackerId: string, attacker: FighterState, victim: FighterState, move: any) => {
      const attackerChar = attackerId === 'p1' ? player1Char : player2Char;
      const victimChar = attackerId === 'p1' ? player2Char : player1Char;

      const hitConfig = attackerChar.hitboxConfig;
      const victimConfig = victimChar.hitboxConfig;

      // 1. Calculate Victim Hurtbox (Green box area)
      let vW = victim.width;
      let vH = victim.height;
      let vX = victim.x;
      let vY = victim.y;

      if (victimConfig) {
        if (victimConfig.hurtboxWidthPercent !== undefined) {
          vW = (victim.width * victimConfig.hurtboxWidthPercent) / 100;
        }
        if (victimConfig.hurtboxHeightPercent !== undefined) {
          vH = (victim.height * victimConfig.hurtboxHeightPercent) / 100;
        }
        if (victimConfig.hurtboxOffsetX !== undefined) {
          // Adjust offset based on facing direction so it flips properly
          vX += victim.direction === 1 
            ? victimConfig.hurtboxOffsetX 
            : (victim.width - vW - victimConfig.hurtboxOffsetX);
        }
        if (victimConfig.hurtboxOffsetY !== undefined) {
          vY += victimConfig.hurtboxOffsetY;
        }
      }

      const victimBox = {
        x: vX,
        y: vY,
        width: vW,
        height: vH,
      };

      // 2. Calculate Attacker Melee Hitbox (Red box area)
      let mRange = move.range;
      let mHeight = 60;
      let mOffsetY = 15;

      if (hitConfig) {
        if (move.id === 'punch') {
          if (hitConfig.punchRange !== undefined) mRange = hitConfig.punchRange;
          if (hitConfig.punchHeight !== undefined) mHeight = hitConfig.punchHeight;
          if (hitConfig.punchOffsetY !== undefined) mOffsetY = hitConfig.punchOffsetY;
        } else if (move.id === 'kick') {
          if (hitConfig.kickRange !== undefined) mRange = hitConfig.kickRange;
          if (hitConfig.kickHeight !== undefined) mHeight = hitConfig.kickHeight;
          if (hitConfig.kickOffsetY !== undefined) mOffsetY = hitConfig.kickOffsetY;
        }
      }

      const attackRangeLeft = attacker.direction === 1 
        ? attacker.x + attacker.width 
        : attacker.x - mRange;

      const attackBox = {
        x: attackRangeLeft,
        y: attacker.y + mOffsetY,
        width: mRange,
        height: mHeight,
      };

      // Check overlapping AABB
      if (
        attackBox.x < victimBox.x + victimBox.width &&
        attackBox.x + attackBox.width > victimBox.x &&
        attackBox.y < victimBox.y + victimBox.height &&
        attackBox.y + attackBox.height > victimBox.y
      ) {
        applyDamage(attackerId, attacker, victim, move.damage);
      }
    };

    // --- APPLY DAMAGE & COMBO ACCUMULATOR ---
    const applyDamage = (attackerId: string, attacker: FighterState, victim: FighterState, baseDamage: number) => {
      if (victim.currentState === 'ko') return;

      const isVictimBlocking = victim.currentState === 'block' && 
        ((attacker.x < victim.x && victim.direction === -1) || 
         (attacker.x > victim.x && victim.direction === 1));

      let damage = baseDamage;
      let sparkColor = '#ff3333'; // Default heavy blood red spark
      let isBlocked = false;

      if (isVictimBlocking) {
        damage = Math.floor(baseDamage * 0.15); // 85% block damage mitigation (chip)
        isBlocked = true;
        sparkColor = '#ffd700'; // Gold block sparkles
        audioSynth.playBlock();
        victim.velocityX = attacker.direction * 1.5; // slight push back
      } else {
        audioSynth.playHit();
        victim.currentState = 'hit';
        victim.stateTimer = 18; // stun duration
        victim.velocityX = attacker.direction * 7; // knock back velocity
        cameraShakeRef.current = { x: 0, y: 0, duration: 12 }; // Screen shake
        
        // Add energy to attacker for landing hits
        attacker.energy = Math.min(100, attacker.energy + 12);
        if (attackerId === 'p1') setP1Energy(attacker.energy);
        else setP2Energy(attacker.energy);

        // Track combo chain
        attacker.comboCount++;
        attacker.comboTimer = 90; // 1.5 second combo reset
        if (attackerId === 'p1') {
          setP1Combo(attacker.comboCount);
        } else {
          setP2Combo(attacker.comboCount);
        }
      }

      victim.health = Math.max(0, victim.health - damage);
      if (victim.id === 'p1') setP1Health(victim.health);
      else setP2Health(victim.health);

      // Trigger sparks
      const sparkX = victim.x + victim.width / 2;
      const sparkY = victim.y + 40;
      spawnHitSparks(sparkX, sparkY, sparkColor, 'spark');

      // Check K.O. Victory
      if (victim.health <= 0) {
        victim.currentState = 'ko';
        victim.stateTimer = 999;
        victim.velocityY = -6; // float KO fall physics
        victim.velocityX = -victim.direction * 3;
        setRoundOver(true);
        setAnnouncerText('K.O.');
        audioSynth.playAnnouncer('ko');

        setTimeout(() => {
          const p1 = p1Ref.current;
          const p2 = p2Ref.current;
          const perfect = attacker.health === attacker.maxHealth;

          if (perfect) {
            setAnnouncerText('PLAYER 1 WINS' /* Perfect trigger later */);
            audioSynth.playAnnouncer('perfect');
          }

          if (p1.health > 0) {
            setAnnouncerText('PLAYER 1 WINS');
            onGameEnd('Player 1', perfect);
          } else {
            setAnnouncerText(isVsAi ? 'AI WINS' : 'PLAYER 2 WINS');
            onGameEnd(isVsAi ? 'AI' : 'Player 2', perfect);
          }
        }, 2200);
      }
    };

    // --- COLLISION RESOLUTION FOR PROJECTILES ---
    const handleCollisions = () => {
      const p1 = p1Ref.current;
      const p2 = p2Ref.current;
      let projectiles = projectilesRef.current;

      // Loop & filter inactive projectles
      projectilesRef.current = projectiles.filter((proj) => {
        // Move projectile
        proj.x += proj.speedX;
        proj.animationFrame++;

        // Bound screen check
        if (proj.x < -100 || proj.x > 900) return false;

        const victim = proj.ownerId === 'p1' ? p2 : p1;
        const targetBox = {
          x: victim.x,
          y: victim.y,
          width: victim.width,
          height: victim.height,
        };

        // Projectile overlap target
        if (
          proj.x < targetBox.x + targetBox.width &&
          proj.x + proj.width > targetBox.x &&
          proj.y < targetBox.y + targetBox.height &&
          proj.y + proj.height > targetBox.y
        ) {
          applyDamage(proj.ownerId, proj.ownerId === 'p1' ? p1 : p2, victim, proj.damage);
          // Explode particles on hit
          spawnHitSparks(proj.x + proj.width / 2, proj.y + proj.height / 2, proj.color, 'spark');
          return false; // remove projectile
        }

        return true;
      });

      // Update active ambient particles
      let particles = particlesRef.current;
      particlesRef.current = particles.filter((p) => {
        p.x += p.vx;
        p.y += p.vy;
        p.life -= p.decay;
        return p.life > 0;
      });
    };

    // --- INTELLIGENT AI GAMEPLAY ENGINE ---
    const updateAI = () => {
      if (!isVsAi) return;

      const p1 = p1Ref.current;
      const ai = p2Ref.current;

      if (ai.currentState === 'hit' || ai.currentState === 'ko' || ai.currentState === 'special') return;

      const diff = settings.aiDifficulty;
      if (diff === 'practice') {
        // Practice mode: AI just stands still, regenerates health occasionally
        if (ai.health < ai.maxHealth && Math.random() < 0.01) {
          ai.health = Math.min(ai.maxHealth, ai.health + 5);
          setP2Health(ai.health);
        }
        return;
      }

      const distance = Math.abs(ai.x - p1.x);
      const rand = Math.random();

      // AI attributes based on difficulty level
      const reactionRate = diff === 'easy' ? 0.01 : diff === 'medium' ? 0.03 : diff === 'hard' ? 0.05 : 0.08;
      const attackRate = diff === 'easy' ? 0.015 : diff === 'medium' ? 0.035 : diff === 'hard' ? 0.06 : 0.09;
      const blockRate = diff === 'easy' ? 0.1 : diff === 'medium' ? 0.4 : diff === 'hard' ? 0.75 : 0.95;

      // 1. Anti-Projectile Intelligence (Jump or Block)
      const incomingProjectiles = projectilesRef.current.filter(p => p.ownerId === 'p1');
      if (incomingProjectiles.length > 0 && rand < blockRate) {
        const proj = incomingProjectiles[0];
        const projDistance = Math.abs(ai.x - proj.x);
        
        if (projDistance < 200) {
          if (rand < 0.4 && !ai.isJumping) {
            // Jump over fireball!
            ai.velocityY = -14;
            ai.isJumping = true;
            ai.currentState = 'jump';
            audioSynth.playPunch();
          } else {
            // Stand block
            ai.currentState = 'block';
            ai.velocityX = 0;
            return;
          }
        }
      }

      // 2. React to P1 Attacks
      if (p1.currentState === 'punch' || p1.currentState === 'kick') {
        if (distance < 120 && rand < blockRate) {
          ai.currentState = 'block';
          ai.velocityX = 0;
          return;
        }
      }

      // 3. Movement Strategy & Distance maintenance
      if (rand < reactionRate) {
        if (distance > 130) {
          // Advance towards Player 1
          ai.velocityX = ai.direction * player2Char.speed * 0.85;
          ai.currentState = 'walk';
        } else if (distance < 60) {
          // Retreat / Create buffer range
          ai.velocityX = -ai.direction * player2Char.speed * 0.7;
          ai.currentState = 'walk';
        } else {
          ai.velocityX *= 0.5;
          ai.currentState = 'idle';
        }
      }

      // 4. Attack Actions
      if (rand < attackRate && ai.stateTimer === 0) {
        if (distance <= 75) {
          // Melee punch or kick combo
          if (rand < 0.6) {
            ai.currentState = 'punch';
            ai.stateTimer = 25; // 15 active + 10 freeze frames
            ai.velocityX = ai.direction * 3;
            audioSynth.playPunch();
            checkMeleeHit('p2', ai, p1, player2Char.moves[0]);
          } else {
            ai.currentState = 'kick';
            ai.stateTimer = 34; // 22 active + 12 freeze frames
            ai.velocityX = ai.direction * 4.5;
            audioSynth.playKick();
            checkMeleeHit('p2', ai, p1, player2Char.moves[1]);
          }
        } else if (distance > 250 && ai.energy >= 30 && rand < 0.3) {
          // Ranged Special Fireball Attack
          ai.currentState = 'special';
          ai.stateTimer = 25;
          ai.velocityX = -ai.direction * 2;
          ai.energy -= 30;
          setP2Energy(ai.energy);
          launchFireball('p2', ai, player2Char);
        }
      }
    };

    // --- GORGEOUS PARALLAX RENDER ENGINE ---
    const renderGame = (c: CanvasRenderingContext2D) => {
      // Clear with background layer or color
      c.save();
      
      // Apply Camera Shake Effect
      const shake = cameraShakeRef.current;
      c.translate(shake.x, shake.y);

      // Render Background (Parallax stylized Arcade arena)
      if (settings.useCustomBg && settings.bgUrl) {
        // Draw user uploaded image
        const img = new Image();
        img.src = settings.bgUrl;
        c.drawImage(img, 0, 0, 800, 450);
      } else {
        // Render stylized retro neon city grid arena
        // Sky gradient
        const skyGrad = c.createLinearGradient(0, 0, 0, 300);
        skyGrad.addColorStop(0, '#0a051d');
        skyGrad.addColorStop(0.5, '#20083c');
        skyGrad.addColorStop(1, '#3d1255');
        c.fillStyle = skyGrad;
        c.fillRect(0, 0, 800, 450);

        // Draw parallax neon glowing skyscrapers
        c.fillStyle = '#1c0a2e';
        c.fillRect(30, 100, 120, 250);
        c.fillRect(190, 80, 150, 270);
        c.fillRect(380, 140, 110, 210);
        c.fillRect(520, 90, 160, 260);
        c.fillRect(710, 120, 70, 230);

        c.fillStyle = '#120422';
        c.fillRect(0, 180, 90, 170);
        c.fillRect(110, 160, 110, 190);
        c.fillRect(300, 200, 130, 150);
        c.fillRect(460, 170, 100, 180);
        c.fillRect(630, 160, 120, 190);

        // Draw cute little neon yellow/blue grid windows in buildings
        c.fillStyle = 'rgba(255, 235, 59, 0.15)';
        for (let xOffset = 40; xOffset < 780; xOffset += 120) {
          for (let yOffset = 180; yOffset < 320; yOffset += 40) {
            if (Math.random() > 0.3) {
              c.fillRect(xOffset + 10, yOffset, 8, 12);
              c.fillRect(xOffset + 25, yOffset, 8, 12);
            }
          }
        }

        // Cybergrid Horizon Floor
        c.fillStyle = '#12021c';
        c.fillRect(0, 340, 800, 110);

        // Grid lines receding perspective
        c.strokeStyle = '#6c209c';
        c.lineWidth = 1.5;
        for (let x = -200; x <= 1000; x += 100) {
          c.beginPath();
          c.moveTo(400, 340);
          c.lineTo(x, 450);
          c.stroke();
        }

        // Horizontal grid depth lines
        let hLineY = 340;
        let spacing = 4;
        while (hLineY < 450) {
          c.beginPath();
          c.moveTo(0, hLineY);
          c.lineTo(800, hLineY);
          c.strokeStyle = `rgba(139, 38, 211, ${Math.min(1, (hLineY - 340) / 40)})`;
          c.stroke();
          spacing += 2;
          hLineY += spacing;
        }

        // Glowing Arena Floor boundary light
        const neonFloorGrad = c.createLinearGradient(0, 340, 0, 350);
        neonFloorGrad.addColorStop(0, '#00ffff');
        neonFloorGrad.addColorStop(1, 'rgba(0, 255, 255, 0)');
        c.fillStyle = neonFloorGrad;
        c.fillRect(0, 340, 800, 12);
      }

      // --- RENDERING PLAYERS PROCEDURALLY ---
      const drawFighter = (f: FighterState, charConfig: CharacterConfig) => {
        const isP1 = f.id === 'p1';
        c.save();
        
        // Flip fighter based on facing direction
        c.translate(f.x + f.width / 2, f.y + f.height / 2);
        c.scale(f.direction, 1);

        const color = charConfig.avatarColor;
        const width = f.width;
        const height = f.height;

        // Draw a floating indicator above their heads
        c.save();
        c.scale(f.direction, 1); // Cancel the flip so text doesn't render backwards
        c.font = 'bold 12px monospace';
        c.fillStyle = isP1 ? '#22d3ee' : '#f97316';
        c.textAlign = 'center';
        c.fillText(isP1 ? 'P1' : (isVsAi ? 'COM' : 'P2'), 0, -height / 2 - 40);
        
        // Small pointer triangle
        c.beginPath();
        c.moveTo(-4, -height / 2 - 34);
        c.lineTo(4, -height / 2 - 34);
        c.lineTo(0, -height / 2 - 29);
        c.closePath();
        c.fillStyle = isP1 ? '#22d3ee' : '#f97316';
        c.fill();
        c.restore();

        // Draw shadow on ground
        c.beginPath();
        c.ellipse(0, height / 2 - 2, 28, 8, 0, 0, Math.PI * 2);
        c.fillStyle = 'rgba(0, 0, 0, 0.45)';
        c.fill();

        // 0. CHECK FOR CUSTOM SPRITE FOR THE CURRENT STATE
        const stateKey = f.currentState as keyof NonNullable<typeof charConfig.customSprites>;
        let customUrlOrUrls = charConfig.customSprites?.[stateKey];
        let resolvedKey: string = stateKey;

        // Custom 5-Animation Intelligent Mapping:
        // The user's character has: idle, walk (none, falls to idle), jump, punch, kick, block.
        // We map any missing state to one of these 5 key animations.
        if (!customUrlOrUrls && charConfig.customSprites) {
          if (stateKey === 'special') {
            // Special attack falls back to punch or kick
            if (charConfig.customSprites['punch']) {
              customUrlOrUrls = charConfig.customSprites['punch'];
              resolvedKey = 'punch';
            } else if (charConfig.customSprites['kick']) {
              customUrlOrUrls = charConfig.customSprites['kick'];
              resolvedKey = 'kick';
            }
          } else if (stateKey === 'walk') {
            // Walk falls back to idle
            if (charConfig.customSprites['idle']) {
              customUrlOrUrls = charConfig.customSprites['idle'];
              resolvedKey = 'idle';
            }
          } else if (stateKey === 'hit' || stateKey === 'ko') {
            // Hurt/KO falls back to idle
            if (charConfig.customSprites['idle']) {
              customUrlOrUrls = charConfig.customSprites['idle'];
              resolvedKey = 'idle';
            }
          } else if (stateKey === 'jump') {
            // Jump falls back to idle if they don't have it
            if (charConfig.customSprites['idle']) {
              customUrlOrUrls = charConfig.customSprites['idle'];
              resolvedKey = 'idle';
            }
          }

          // Global fallback in case idle or other chosen is not there
          if (!customUrlOrUrls) {
            const fallbackOrder: (keyof NonNullable<typeof charConfig.customSprites>)[] = [
              'idle', 'block', 'kick', 'punch', 'jump'
            ];
            for (const key of fallbackOrder) {
              if (charConfig.customSprites[key]) {
                customUrlOrUrls = charConfig.customSprites[key];
                resolvedKey = key;
                break;
              }
            }
          }
        }

        if (customUrlOrUrls) {
          let customUrl: string | undefined;

          if (Array.isArray(customUrlOrUrls)) {
            if (customUrlOrUrls.length > 0) {
              const isActualMatch = resolvedKey === stateKey;
              const isWalkToIdleFallback = stateKey === 'walk' && resolvedKey === 'idle';
              const isSpecialToAttackFallback = stateKey === 'special' && (resolvedKey === 'punch' || resolvedKey === 'kick');

              if (!isActualMatch && !isWalkToIdleFallback && !isSpecialToAttackFallback) {
                customUrl = customUrlOrUrls[0];
              } else if (resolvedKey === 'punch' || resolvedKey === 'kick') {
                // Determine active and freeze durations for one-shot attack states
                let activeDuration = 15;
                let freezeDuration = 10;
                if (resolvedKey === 'kick') {
                  activeDuration = 22;
                  freezeDuration = 12;
                }

                const currentTimer = f.stateTimer > 0 ? f.stateTimer : 0;
                const timerVal = Math.max(0, currentTimer - freezeDuration);
                const elapsed = Math.max(0, activeDuration - timerVal);

                const frameIndex = Math.min(
                  customUrlOrUrls.length - 1,
                  Math.max(0, Math.floor((elapsed / activeDuration) * customUrlOrUrls.length))
                );
                customUrl = customUrlOrUrls[frameIndex];
              } else {
                // For looping states (idle, walk, block, ko, hit)
                let frameIndex = 0;
                if (resolvedKey === 'block') {
                  const framesCount = f.blockFrames || 0;
                  const animTick = Math.floor(framesCount / 4);
                  frameIndex = Math.min(customUrlOrUrls.length - 1, animTick);
                } else if (stateKey === 'ko') {
                  frameIndex = customUrlOrUrls.length - 1;
                } else if (stateKey === 'jump' && isMaryam(charConfig)) {
                  if (!f.isJumping && f.stateTimer > 0) {
                    // Frozen on the last frame of the jump during landing recovery!
                    frameIndex = customUrlOrUrls.length - 1;
                  } else {
                    const animTick = Math.floor(Date.now() / 90);
                    frameIndex = animTick % customUrlOrUrls.length;
                  }
                } else {
                  const animTick = Math.floor(Date.now() / 90);
                  frameIndex = animTick % customUrlOrUrls.length;
                }
                customUrl = customUrlOrUrls[frameIndex];
              }
            }
          } else {
            customUrl = customUrlOrUrls;
          }

          if (customUrl) {
            if (!imageCache.current[customUrl]) {
              const img = new Image();
              img.referrerPolicy = 'no-referrer';
              img.src = customUrl;
              imageCache.current[customUrl] = img;
            }
            const img = imageCache.current[customUrl];
            if (img.complete && img.naturalWidth > 0) {
              c.save(); // Save before applying state-specific transforms



              if (f.currentState === 'hit') {
                // Hurt tilt: tilt slightly backward (the direction is already flipped by c.scale(f.direction, 1)!)
                c.rotate(-0.25); // Tilt back ~14 degrees
                // Add a bit of hit wobble/vibration
                const wobble = Math.sin(Date.now() * 0.15) * 4;
                c.translate(wobble, 0);
              } else if (f.currentState === 'ko') {
                // Knockout fall: rotate 90 degrees backwards (lying flat)
                c.rotate(-Math.PI / 2);
                // Shift down/forward relative to the ground so they look lying flat on the floor
                c.translate(-height / 3, height / 3);
              } else if (f.currentState === 'walk') {
                // Walk bobbing effect
                const walkBob = Math.sin(Date.now() * 0.015) * 4;
                c.translate(0, walkBob);
              }

              const drawW = width * 2.5;
              const drawH = height + 25 * (height / 115);
              c.drawImage(img, -drawW / 2, -height / 2 - 25 * (height / 115), drawW, drawH);
              c.restore(); // Restore state-specific transforms
              c.restore(); // Restore drawFighter's main save
              return;
            }
          }
        }

        // 1. STATE-DEPENDENT GEOMETRY SHAPING
        let headY = -40;
        let bodyY = -15;
        let legLOffset = -12;
        let legROffset = 12;
        let armLeftOffset = -18;
        let armRightOffset = 18;
        let handX = 22;
        let handY = -15;

        // Custom animation bobbing values based on system frame ticks
        const bob = Math.sin(Date.now() * 0.01) * 3;

        switch (f.currentState) {
          case 'idle':
            headY += bob;
            bodyY += bob * 0.5;
            handY += bob * 0.8;
            break;
          case 'walk':
            const stride = Math.sin(Date.now() * 0.015) * 14;
            legLOffset += stride;
            legROffset -= stride;
            headY += Math.abs(stride) * 0.15;
            break;
          case 'jump':
            headY -= 4;
            legLOffset = -6;
            legROffset = 6;
            break;
          case 'punch':
            handX = 42; // Extend arm way out!
            handY = -22;
            break;
          case 'kick':
            legROffset = 52; // Extend leg way out!
            legLOffset = -8;
            break;
          case 'special':
            handX = 32;
            handY = -18;
            // Draw energy aura
            c.beginPath();
            c.arc(15, -15, 25, 0, Math.PI * 2);
            c.fillStyle = 'rgba(0, 191, 255, 0.25)';
            c.fill();
            c.strokeStyle = '#00f0ff';
            c.lineWidth = 1.5;
            c.stroke();
            break;
          case 'hit':
            c.translate(-10, 0); // push visual back
            c.rotate(-0.08);     // tilt head back
            break;
          case 'block':
            handX = 14;
            handY = -28;
            // Draw glowing shields
            c.beginPath();
            c.arc(22, -18, 30, -Math.PI / 2, Math.PI / 2);
            c.strokeStyle = 'rgba(0, 255, 255, 0.6)';
            c.lineWidth = 3;
            c.stroke();
            break;
          case 'ko':
            c.rotate(-Math.PI / 2.2); // flat rotate on back
            break;
        }

        // DRAW BODY SEGMENTS (Pixel-Art / High Contrast Cyber Vector look)
        // A. LEGS
        c.lineWidth = 8;
        c.lineCap = 'round';
        c.strokeStyle = '#1a112c'; // pants/shadow color
        
        // Left Leg
        c.beginPath();
        c.moveTo(-8, 5);
        c.lineTo(legLOffset, 42);
        c.stroke();

        // Right Leg
        c.beginPath();
        c.moveTo(8, 5);
        c.lineTo(legROffset, 42);
        c.stroke();

        // B. TORSO / ROBOTIC SUIT
        c.fillStyle = '#22143c'; // Dark undertone
        c.beginPath();
        c.roundRect(-16, -28, 32, 36, 6);
        c.fill();

        // Core Glowing Chest emblem (cyber look)
        c.fillStyle = color;
        c.beginPath();
        c.arc(0, -14, 6, 0, Math.PI * 2);
        c.fill();

        // Armor Plate outline
        c.strokeStyle = color;
        c.lineWidth = 2;
        c.strokeRect(-16, -28, 32, 36);

        // C. HEAD / CYBER HELMET / BANDANA
        c.fillStyle = '#fce4ec'; // skin block
        c.beginPath();
        c.arc(0, headY, 15, 0, Math.PI * 2);
        c.fill();

        // Visor/Mask (glowing band based on character theme)
        c.fillStyle = '#11011e';
        c.fillRect(-11, headY - 5, 20, 7);
        c.fillStyle = color;
        c.fillRect(-8, headY - 4, 15, 3); // glowing visor light

        // Hair or Bandana streaming out back
        c.beginPath();
        c.moveTo(-12, headY - 2);
        c.lineTo(-28, headY + (Math.sin(Date.now() * 0.01) * 4));
        c.strokeStyle = color;
        c.lineWidth = 4;
        c.stroke();

        // D. ARMS
        c.strokeStyle = '#2d184e';
        c.lineWidth = 7;

        // Back Arm
        c.beginPath();
        c.moveTo(-12, -22);
        c.lineTo(armLeftOffset, -10);
        c.stroke();

        // Main Punching/Blocking Arm
        c.beginPath();
        c.moveTo(12, -22);
        c.lineTo(handX, handY);
        c.strokeStyle = '#3d206c';
        c.stroke();

        // Glowing cyber-fist glove
        c.fillStyle = color;
        c.beginPath();
        c.arc(handX, handY, 6, 0, Math.PI * 2);
        c.fill();

        c.restore();
      };

      // Draw Player 1
      drawFighter(p1Ref.current, player1Char);
      
      // Draw Player 2
      drawFighter(p2Ref.current, player2Char);

      // --- VISUALIZING HITBOXES ---
      if (settings.showHitboxes) {
        const drawHitboxDebug = (f: FighterState, char: CharacterConfig) => {
          if (f.currentState === 'ko') return;

          const hitConfig = char.hitboxConfig;

          // 1. Calculate Hurtbox
          let vW = f.width;
          let vH = f.height;
          let vX = f.x;
          let vY = f.y;

          if (hitConfig) {
            if (hitConfig.hurtboxWidthPercent !== undefined) {
              vW = (f.width * hitConfig.hurtboxWidthPercent) / 100;
            }
            if (hitConfig.hurtboxHeightPercent !== undefined) {
              vH = (f.height * hitConfig.hurtboxHeightPercent) / 100;
            }
            if (hitConfig.hurtboxOffsetX !== undefined) {
              vX += f.direction === 1 
                ? hitConfig.hurtboxOffsetX 
                : (f.width - vW - hitConfig.hurtboxOffsetX);
            }
            if (hitConfig.hurtboxOffsetY !== undefined) {
              vY += hitConfig.hurtboxOffsetY;
            }
          }

          // Draw Hurtbox (Semi-transparent Green)
          c.save();
          c.fillStyle = 'rgba(34, 197, 94, 0.25)'; // green-500/25
          c.strokeStyle = '#22c55e'; // green-500
          c.lineWidth = 2;
          c.fillRect(vX, vY, vW, vH);
          c.strokeRect(vX, vY, vW, vH);
          
          // Draw a small label "Hurtbox"
          c.font = '8px monospace';
          c.fillStyle = '#22c55e';
          c.fillText('HURTBOX / آسیب‌پذیر', vX + 4, vY + 12);
          c.restore();

          // 2. Draw active Attack Hitbox (Red) if they are in punch/kick/special and are currently active (before freeze frame recovery)
          let isActiveAttack = f.stateTimer > 0;
          if (f.currentState === 'punch' && f.stateTimer <= 10) isActiveAttack = false;
          if (f.currentState === 'kick' && f.stateTimer <= 12) isActiveAttack = false;

          if ((f.currentState === 'punch' || f.currentState === 'kick' || f.currentState === 'special') && isActiveAttack) {
            let mRange = 60;
            let mHeight = 60;
            let mOffsetY = 15;

            // Find current move info
            const currentMoveId = f.currentState === 'special' ? 'special' : f.currentState;
            const move = char.moves.find(m => m.id === currentMoveId) || { range: 60 };
            mRange = move.range;

            if (hitConfig) {
              if (f.currentState === 'punch') {
                if (hitConfig.punchRange !== undefined) mRange = hitConfig.punchRange;
                if (hitConfig.punchHeight !== undefined) mHeight = hitConfig.punchHeight;
                if (hitConfig.punchOffsetY !== undefined) mOffsetY = hitConfig.punchOffsetY;
              } else if (f.currentState === 'kick') {
                if (hitConfig.kickRange !== undefined) mRange = hitConfig.kickRange;
                if (hitConfig.kickHeight !== undefined) mHeight = hitConfig.kickHeight;
                if (hitConfig.kickOffsetY !== undefined) mOffsetY = hitConfig.kickOffsetY;
              }
            }

            const attackRangeLeft = f.direction === 1 
              ? f.x + f.width 
              : f.x - mRange;

            const aX = attackRangeLeft;
            const aY = f.y + mOffsetY;

            c.save();
            c.fillStyle = 'rgba(239, 68, 68, 0.35)'; // red-500/35
            c.strokeStyle = '#ef4444'; // red-500
            c.lineWidth = 2;
            c.fillRect(aX, aY, mRange, mHeight);
            c.strokeRect(aX, aY, mRange, mHeight);
            
            // Draw a small label "Hitbox"
            c.font = 'bold 8px monospace';
            c.fillStyle = '#ef4444';
            c.fillText('HITBOX / ضربه‌زن', aX + 4, aY + 12);
            c.restore();
          }
        };

        drawHitboxDebug(p1Ref.current, player1Char);
        drawHitboxDebug(p2Ref.current, player2Char);
      }

      // --- RENDERING FIREBALL PROJECTILES ---
      projectilesRef.current.forEach((proj) => {
        c.save();
        // Fireball aura glow
        const grad = c.createRadialGradient(
          proj.x + proj.width / 2, proj.y + proj.height / 2, 2,
          proj.x + proj.width / 2, proj.y + proj.height / 2, proj.width / 1.2
        );
        grad.addColorStop(0, '#ffffff');
        grad.addColorStop(0.3, proj.color);
        grad.addColorStop(1, 'rgba(0, 0, 0, 0)');
        
        c.fillStyle = grad;
        c.beginPath();
        c.arc(proj.x + proj.width / 2, proj.y + proj.height / 2, proj.width / 1.2, 0, Math.PI * 2);
        c.fill();

        // Fireball internal core
        c.fillStyle = '#ffffff';
        c.beginPath();
        c.ellipse(
          proj.x + proj.width / 2, proj.y + proj.height / 2, 
          10 + Math.sin(proj.animationFrame * 0.3) * 2, 7, 
          0, 0, Math.PI * 2
        );
        c.fill();

        // Floating energy sparks trailing behind
        c.fillStyle = proj.color;
        for (let i = 0; i < 4; i++) {
          const trailX = proj.x - (proj.speedX * i * 1.5) + (Math.random() - 0.5) * 10;
          const trailY = proj.y + proj.height / 2 + (Math.random() - 0.5) * 10;
          c.fillRect(trailX, trailY, 3, 3);
        }

        c.restore();
      });

      // --- RENDERING DECAYING PARTICLES ---
      particlesRef.current.forEach((p) => {
        c.save();
        c.globalAlpha = p.life;
        c.fillStyle = p.color;

        if (p.type === 'dust') {
          c.beginPath();
          c.arc(p.x, p.y, p.size * (1 - p.life * 0.5), 0, Math.PI * 2);
          c.fill();
        } else {
          // Spark or fire block
          c.fillRect(p.x - p.size / 2, p.y - p.size / 2, p.size, p.size);
        }
        c.restore();
      });

      c.restore();
    };

    // Run game engine
    gameLoop();

    return () => {
      cancelAnimationFrame(animationId);
    };
  }, [player1Char, player2Char, isVsAi, settings, isPaused, roundOver, announcerText]);

  // Touch / click virtual button component
  const VirtualButton: React.FC<{
    gameKey: string;
    label: string;
    icon: string;
    colorClass: string;
    subLabel?: string;
  }> = ({ gameKey, label, icon, colorClass, subLabel }) => {
    const [isPressed, setIsPressed] = useState(false);

    const handleStart = (e: React.MouseEvent | React.TouchEvent) => {
      e.preventDefault();
      setIsPressed(true);
      keysPressed.current.add(gameKey.toUpperCase());
    };

    const handleEnd = (e: React.MouseEvent | React.TouchEvent) => {
      e.preventDefault();
      setIsPressed(false);
      keysPressed.current.delete(gameKey.toUpperCase());
    };

    return (
      <button
        onMouseDown={handleStart}
        onMouseUp={handleEnd}
        onMouseLeave={handleEnd}
        onTouchStart={handleStart}
        onTouchEnd={handleEnd}
        className={`select-none relative flex flex-col items-center justify-center py-2 px-1.5 rounded-xl border font-bold transition-all duration-75 active:scale-95 ${
          isPressed 
            ? `${colorClass} text-white border-white shadow-[0_0_15px_rgba(255,255,255,0.45)]` 
            : 'bg-slate-900/90 hover:bg-slate-800/90 text-slate-100 border-slate-800'
        }`}
        style={{ touchAction: 'none' }}
      >
        <span className="text-base leading-none">{icon}</span>
        <span className="text-[10px] mt-0.5 leading-none font-medium">{label}</span>
        {subLabel && <span className="text-[8px] text-slate-500 font-mono mt-0.5 leading-none">{subLabel}</span>}
      </button>
    );
  };

  // Translate AI Difficulties helper
  const translateDiff = (d: string) => {
    switch (d) {
      case 'easy': return 'ساده (Easy)';
      case 'medium': return 'متوسط (Medium)';
      case 'hard': return 'سخت (Hard)';
      case 'impossible': return 'غیرممکن (Impossible)';
      case 'practice': return 'تمرینی (Practice)';
      default: return d;
    }
  };

  return (
    <div id="arcade-cabinet-frame" className="relative flex flex-col items-center w-full select-none">
      {/* 1. TOP MARQUEE PANEL */}
      <div className="w-full bg-slate-900 border-4 border-slate-700 rounded-t-xl p-3 flex justify-between items-center shadow-lg px-6">
        <div className="flex items-center gap-3">
          <span className="text-2xl animate-pulse">🔴</span>
          <span className="font-mono text-xs text-yellow-400 tracking-widest hidden sm:inline">RETRO FIGHTER SYSTEM v2.4</span>
        </div>
        <div className="text-center">
          <span className="text-xl font-mono text-cyan-400 font-bold uppercase tracking-widest bg-slate-950 px-4 py-1 rounded border border-cyan-800 shadow-[0_0_10px_rgba(0,255,255,0.2)]">
            {isVsAi ? 'VS COMPUTERS' : 'LOCAL 2-PLAYER'}
          </span>
        </div>
        <div className="text-right">
          <span className="font-mono text-xs text-slate-400">
            {isVsAi ? `DIFFICULTY: ${translateDiff(settings.aiDifficulty)}` : 'READY TO FIGHT'}
          </span>
        </div>
      </div>

      {/* 2. CORE GAMEPLAY CONTAINER */}
      <div ref={containerRef} className="relative w-full border-x-4 border-b-4 border-slate-700 bg-black overflow-hidden shadow-2xl">
        
        {/* TOP LEVEL COMBAT HUD (Floating elements) */}
        <div className="absolute top-0 left-0 w-full p-4 flex flex-col gap-2 z-10 pointer-events-none">
          <div className="flex justify-between items-start gap-4">
            
            {/* Player 1 HUD Box */}
            <div className="flex-1 flex flex-col gap-1 items-start">
              <div className="flex items-center gap-2">
                {player1Char.menuPortrait ? (
                  <div className="w-8 h-8 rounded-full border-2 border-cyan-400 overflow-hidden shrink-0 relative bg-slate-900 shadow-[0_0_8px_rgba(34,211,238,0.5)]">
                    <img src={player1Char.menuPortrait} alt={player1Char.nameFa} referrerPolicy="no-referrer" className="w-full h-full object-cover" />
                  </div>
                ) : (
                  <span className="text-2xl">{player1Char.avatar}</span>
                )}
                <span className="font-bold text-white text-sm sm:text-base drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)]">
                  {player1Char.nameFa} <span className="text-xs text-slate-400">({player1Char.name})</span>
                </span>
              </div>
              {/* Outer Health bar frame */}
              <div className="w-full h-5 bg-slate-950 rounded-full border-2 border-slate-800 overflow-hidden shadow-[inset_0_2px_4px_rgba(0,0,0,0.8)]">
                <div 
                  className="h-full bg-gradient-to-r from-red-600 to-yellow-400 transition-all duration-100 ease-out flex items-center justify-end pr-2 text-[10px] font-mono text-white font-bold"
                  style={{ width: `${Math.max(0, (p1Health / player1Char.maxHealth) * 100)}%` }}
                >
                  {p1Health > 15 && `${p1Health}HP`}
                </div>
              </div>
              {/* Energy bar for Super/Fireball */}
              <div className="w-2/3 h-2 bg-slate-950 rounded border border-slate-800 overflow-hidden">
                <div 
                  className="h-full bg-cyan-400 transition-all duration-200"
                  style={{ width: `${p1Energy}%` }}
                />
              </div>
              <div className="text-[10px] font-mono text-cyan-400">
                SPECIAL ENERGY: {p1Energy}/100 {p1Energy >= 30 ? '🔥 [H] READY' : ''}
              </div>
            </div>

            {/* ROUND TIMER */}
            <div className="flex flex-col items-center px-4 py-2 bg-slate-950 border-2 border-slate-800 rounded-lg shadow-md shrink-0">
              <span className="text-xs font-mono text-slate-400 uppercase tracking-wider">TIME</span>
              <span className="text-3xl font-mono font-bold text-yellow-400 tracking-wider">
                {String(gameTimer).padStart(2, '0')}
              </span>
            </div>

            {/* Player 2 HUD Box */}
            <div className="flex-1 flex flex-col gap-1 items-end">
              <div className="flex items-center gap-2">
                <span className="font-bold text-white text-sm sm:text-base drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)]">
                  {player2Char.nameFa} <span className="text-xs text-slate-400">({player2Char.name})</span>
                </span>
                {player2Char.menuPortrait ? (
                  <div className="w-8 h-8 rounded-full border-2 border-orange-400 overflow-hidden shrink-0 relative bg-slate-900 shadow-[0_0_8px_rgba(251,146,60,0.5)]">
                    <img src={player2Char.menuPortrait} alt={player2Char.nameFa} referrerPolicy="no-referrer" className="w-full h-full object-cover" />
                  </div>
                ) : (
                  <span className="text-2xl">{player2Char.avatar}</span>
                )}
              </div>
              {/* Outer Health bar frame */}
              <div className="w-full h-5 bg-slate-950 rounded-full border-2 border-slate-800 overflow-hidden shadow-[inset_0_2px_4px_rgba(0,0,0,0.8)]">
                <div 
                  className="h-full bg-gradient-to-l from-red-600 to-yellow-400 transition-all duration-100 ease-out flex items-center justify-start pl-2 text-[10px] font-mono text-white font-bold"
                  style={{ width: `${Math.max(0, (p2Health / player2Char.maxHealth) * 100)}%` }}
                >
                  {p2Health > 15 && `${p2Health}HP`}
                </div>
              </div>
              {/* Energy bar P2 */}
              <div className="w-2/3 h-2 bg-slate-950 rounded border border-slate-800 overflow-hidden">
                <div 
                  className="h-full bg-orange-400 transition-all duration-200"
                  style={{ width: `${p2Energy}%` }}
                />
              </div>
              <div className="text-[10px] font-mono text-orange-400">
                SPECIAL ENERGY: {p2Energy}/100 {!isVsAi && p2Energy >= 30 ? '🔥 [P] READY' : ''}
              </div>
            </div>

          </div>

          {/* Combo Counters overlay */}
          <div className="flex justify-between mt-2">
            <div>
              {p1Combo > 1 && (
                <div className="bg-yellow-400 text-slate-950 px-3 py-1 font-black text-sm italic rounded shadow-md transform -rotate-3 animate-bounce">
                  💥 {p1Combo} ضربه متوالی!
                </div>
              )}
            </div>
            <div>
              {p2Combo > 1 && (
                <div className="bg-yellow-400 text-slate-950 px-3 py-1 font-black text-sm italic rounded shadow-md transform rotate-3 animate-bounce">
                  💥 {p2Combo} ضربه متوالی!
                </div>
              )}
            </div>
          </div>
        </div>

        {/* SCREEN ANNOUNCER OVERLAYS (Fight, Round 1, KO) */}
        {announcerText && (
          <div className="absolute inset-0 flex items-center justify-center z-20 bg-black/35 backdrop-blur-xs pointer-events-none">
            <div className="text-center transform scale-110 transition-all">
              <h2 className="text-5xl sm:text-7xl font-black text-yellow-400 tracking-wider drop-shadow-[0_6px_10px_rgba(0,0,0,0.9)] uppercase animate-pulse">
                {announcerText}
              </h2>
              {announcerText === 'ROUND 1' && (
                <p className="text-cyan-400 font-bold text-sm tracking-widest mt-2 drop-shadow-md">آماده نبرد باشید!</p>
              )}
              {announcerText === 'FIGHT!' && (
                <p className="text-red-500 font-black text-lg tracking-widest mt-2 drop-shadow-md">بزن بریم!</p>
              )}
            </div>
          </div>
        )}

        {/* THE MAIN CANVAS ELEMENT */}
        <canvas
          ref={canvasRef}
          width={800}
          height={450}
          className="w-full bg-slate-950 block transition-all"
          style={{ width: `${canvasWidth}px`, height: `${canvasHeight}px` }}
        />

        {/* CRT RETRO OVERLAYS (Scanlines, screen curved gloss, phosphor bloom) */}
        <div className="absolute inset-0 pointer-events-none bg-gradient-to-b from-transparent via-[rgba(18,16,16,0.08)] to-transparent bg-[length:100%_4px] mix-blend-overlay opacity-65" />
        <div className="absolute inset-0 pointer-events-none shadow-[inset_0_0_60px_rgba(0,255,255,0.12)]" />

        {/* PAUSE MENU OVERLAY */}
        {isPaused && (
          <div className="absolute inset-0 bg-slate-950/80 flex flex-col items-center justify-center z-30 p-6">
            <div className="bg-slate-900 border-4 border-yellow-500 p-8 rounded-xl max-w-sm text-center shadow-2xl">
              <h3 className="text-3xl font-bold text-yellow-400 mb-2">بازی متوقف شد</h3>
              <p className="text-slate-300 font-mono text-sm mb-6">PRESS ESC TO RESUME OR CLICK BELOW</p>
              <button 
                onClick={onTogglePause}
                className="w-full bg-gradient-to-r from-yellow-400 to-amber-500 text-slate-950 font-bold py-3 rounded-lg hover:from-yellow-300 hover:to-amber-400 transition active:scale-95 shadow-lg shadow-yellow-500/20"
              >
                ادامه بازی (Resume)
              </button>
            </div>
          </div>
        )}
      </div>

      {/* 3. RETRO CONTROLS BAR UNDERNEATH CABINET */}
      <div className="w-full bg-slate-950 border-x-4 border-b-4 border-slate-700 rounded-b-xl p-4 grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Player 1 Rules & Keys */}
        <div className="bg-slate-900/60 p-3 rounded-lg border border-cyan-900/50 flex flex-col gap-3">
          <div className="flex justify-between items-center border-b border-cyan-900/40 pb-1">
            <span className="text-cyan-400 font-bold text-xs">کلیدها و کنترل لمسی بازیکن ۱ (پیکارگر سمت چپ)</span>
            <span className="text-[10px] bg-cyan-950 text-cyan-400 px-2 py-0.5 rounded uppercase font-mono">P1 CONTROLLER</span>
          </div>
          
          {/* Static reference keys */}
          <div className="grid grid-cols-2 gap-1.5 text-[11px] font-mono text-slate-400 border-b border-slate-800/60 pb-3">
            <div className="flex justify-between bg-slate-950/40 px-2 py-0.5 rounded"><span>حرکت به چپ/راست</span><span className="text-cyan-400 font-bold">[A] [D]</span></div>
            <div className="flex justify-between bg-slate-950/40 px-2 py-0.5 rounded"><span>پرش / گارد دفاع</span><span className="text-cyan-400 font-bold">[W] / [S]</span></div>
            <div className="flex justify-between bg-slate-950/40 px-2 py-0.5 rounded"><span>ضربه مشت (Jab)</span><span className="text-red-400 font-bold">[F]</span></div>
            <div className="flex justify-between bg-slate-950/40 px-2 py-0.5 rounded"><span>ضربه لگد (Kick)</span><span className="text-yellow-400 font-bold">[G]</span></div>
            <div className="flex justify-between bg-slate-950/40 px-2 py-0.5 rounded col-span-2 text-purple-400 justify-center gap-2">
              <span>ضربه جادویی (Fireball)</span><span className="text-yellow-400 font-bold">[H] - ۳۰ انرژی</span>
            </div>
          </div>

          {/* Interactive Virtual Controller Area Player 1 */}
          <div className="bg-slate-950/80 p-2.5 rounded-xl border border-cyan-950/50 flex flex-col gap-2">
            <span className="text-[10px] text-cyan-400 font-bold text-center font-mono tracking-wider block border-b border-cyan-950/30 pb-1.5">🕹️ دسته بازی لمسی / کلیکی بازیکن ۱</span>
            <div className="grid grid-cols-2 gap-3 items-center">
              {/* Movement D-PAD */}
              <div className="grid grid-cols-3 gap-1 mx-auto w-full max-w-[130px]">
                <div />
                <VirtualButton gameKey="W" label="پرش" icon="🔼" colorClass="bg-cyan-600 border-cyan-400" />
                <div />
                
                <VirtualButton gameKey="A" label="چپ" icon="◀" colorClass="bg-cyan-600 border-cyan-400" />
                <VirtualButton gameKey="S" label="دفاع" icon="▼" colorClass="bg-cyan-600 border-cyan-400" />
                <VirtualButton gameKey="D" label="راست" icon="▶" colorClass="bg-cyan-600 border-cyan-400" />
              </div>

              {/* Combat Buttons */}
              <div className="flex flex-col gap-1.5 justify-center w-full max-w-[130px] mx-auto">
                <VirtualButton gameKey="F" label="👊 مشت (F)" icon="👊" colorClass="bg-red-600 border-red-400 shadow-[0_0_10px_rgba(239,68,68,0.35)]" />
                <VirtualButton gameKey="G" label="🦵 لگد (G)" icon="🦵" colorClass="bg-yellow-600 border-yellow-400 shadow-[0_0_10px_rgba(234,179,8,0.35)]" />
                <VirtualButton gameKey="H" label="🔥 ویژه (H)" icon="🔥" colorClass="bg-purple-600 border-purple-400 shadow-[0_0_12px_rgba(168,85,247,0.4)]" />
              </div>
            </div>
          </div>
        </div>

        {/* Player 2 or AI Keys */}
        <div className="bg-slate-900/60 p-3 rounded-lg border border-orange-950/50 flex flex-col gap-3">
          <div className="flex justify-between items-center border-b border-orange-900/40 pb-1">
            <span className="text-orange-400 font-bold text-xs">
              {isVsAi ? 'حریف هوش مصنوعی (AI Opponent)' : 'کلیدها و کنترل لمسی بازیکن ۲ (پیکارگر سمت راست)'}
            </span>
            <span className="text-[10px] bg-orange-950 text-orange-400 px-2 py-0.5 rounded uppercase font-mono">
              {isVsAi ? 'AI STATUS' : 'P2 CONTROLLER'}
            </span>
          </div>

          {isVsAi ? (
            <div className="flex flex-col h-full justify-center items-center text-center p-4 bg-slate-950/40 rounded-xl border border-slate-800">
              <span className="text-yellow-400 font-mono text-sm uppercase animate-pulse font-bold font-mono">● هوش مصنوعی فعال است ●</span>
              <p className="text-slate-400 text-[11px] mt-2 leading-relaxed text-right" dir="rtl">
                کامپیوتر متناسب با درجه سختی انتخاب شده حرکت می‌کند، دفاع می‌کند و فنون ویژه و فایربال می‌زند! می‌توانید در مقابل او تمرین کنید.
              </p>
            </div>
          ) : (
            <>
              {/* Static reference keys */}
              <div className="grid grid-cols-2 gap-1.5 text-[11px] font-mono text-slate-400 border-b border-slate-800/60 pb-3">
                <div className="flex justify-between bg-slate-950/40 px-2 py-0.5 rounded"><span>حرکت به چپ/راست</span><span className="text-orange-400 font-bold">[←] [→]</span></div>
                <div className="flex justify-between bg-slate-950/40 px-2 py-0.5 rounded"><span>پرش / گارد دفاع</span><span className="text-orange-400 font-bold">[↑] / [↓]</span></div>
                <div className="flex justify-between bg-slate-950/40 px-2 py-0.5 rounded"><span>ضربه مشت (Jab)</span><span className="text-red-400 font-bold">[I]</span></div>
                <div className="flex justify-between bg-slate-950/40 px-2 py-0.5 rounded"><span>ضربه لگد (Kick)</span><span className="text-yellow-400 font-bold">[O]</span></div>
                <div className="flex justify-between bg-slate-950/40 px-2 py-0.5 rounded col-span-2 text-purple-400 justify-center gap-2">
                  <span>ضربه جادویی (Special)</span><span className="text-yellow-400 font-bold">[P] - ۳۰ انرژی</span>
                </div>
              </div>

              {/* Interactive Virtual Controller Area Player 2 */}
              <div className="bg-slate-950/80 p-2.5 rounded-xl border border-orange-950/50 flex flex-col gap-2">
                <span className="text-[10px] text-orange-400 font-bold text-center font-mono tracking-wider block border-b border-orange-950/30 pb-1.5">🕹️ دسته بازی لمسی / کلیکی بازیکن ۲</span>
                <div className="grid grid-cols-2 gap-3 items-center">
                  {/* Movement D-PAD */}
                  <div className="grid grid-cols-3 gap-1 mx-auto w-full max-w-[130px]">
                    <div />
                    <VirtualButton gameKey="ArrowUp" label="پرش" icon="🔼" colorClass="bg-orange-600 border-orange-400" />
                    <div />
                    
                    <VirtualButton gameKey="ArrowLeft" label="چپ" icon="◀" colorClass="bg-orange-600 border-orange-400" />
                    <VirtualButton gameKey="ArrowDown" label="دفاع" icon="▼" colorClass="bg-orange-600 border-orange-400" />
                    <VirtualButton gameKey="ArrowRight" label="راست" icon="▶" colorClass="bg-orange-600 border-orange-400" />
                  </div>

                  {/* Combat Buttons */}
                  <div className="flex flex-col gap-1.5 justify-center w-full max-w-[130px] mx-auto">
                    <VirtualButton gameKey="I" label="👊 مشت (I)" icon="👊" colorClass="bg-red-600 border-red-400 shadow-[0_0_10px_rgba(239,68,68,0.35)]" />
                    <VirtualButton gameKey="O" label="🦵 لگد (O)" icon="🦵" colorClass="bg-yellow-600 border-yellow-400 shadow-[0_0_10px_rgba(234,179,8,0.35)]" />
                    <VirtualButton gameKey="P" label="🔥 ویژه (P)" icon="🔥" colorClass="bg-purple-600 border-purple-400 shadow-[0_0_12px_rgba(168,85,247,0.4)]" />
                  </div>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default GameCanvas;
