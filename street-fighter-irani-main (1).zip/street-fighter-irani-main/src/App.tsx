/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { CharacterConfig, GameSettings } from './types';
import { defaultCharacters } from './characters';
import GameCanvas from './components/GameCanvas';
import CharacterSelect from './components/CharacterSelect';
import AssetManager from './components/AssetManager';
import { Gamepad2, Sparkles, RefreshCw, Undo2, Award, Zap, ChevronRight, Swords, HelpCircle } from 'lucide-react';
import audioSynth from './audio';
import { retroDB } from './db';

export default function App() {
  const [characters, setCharacters] = useState<CharacterConfig[]>(defaultCharacters);
  // Global settings
  const [settings, setSettings] = useState<GameSettings>({
    roundDuration: 99,
    roundsToWin: 2,
    soundVolume: 0.4,
    bgUrl: '',
    useCustomBg: false,
    aiDifficulty: 'medium',
  });
  const [isLoading, setIsLoading] = useState(true);

  // Load from database on mount
  useEffect(() => {
    async function loadData() {
      try {
        const saved = await retroDB.getCharacters();
        let finalChars = saved;
        if (!finalChars || !Array.isArray(finalChars) || finalChars.length === 0) {
          // Fallback to localStorage for old users
          const oldSaved = localStorage.getItem('retro_fighter_characters');
          if (oldSaved) {
            try {
              const parsed = JSON.parse(oldSaved);
              if (Array.isArray(parsed) && parsed.length > 0) {
                finalChars = parsed;
              }
            } catch (e) {
              console.error('Error parsing legacy localStorage characters:', e);
            }
          }
        }

        // If still no custom characters (or only contains the 2 old hardcoded defaults),
        // seed two beautiful, highly customizable templates so the menu is never empty!
        if (!finalChars || finalChars.length === 0 || (finalChars.length <= 2 && finalChars.every(c => c.id === 'custom_fighter' || c.id === 'blaze_fighter'))) {
          const baseList = finalChars && finalChars.length > 0 ? finalChars : defaultCharacters;
          const custom1: CharacterConfig = {
            id: 'custom_1',
            name: 'Elite Fighter',
            nameFa: 'رزم‌آور الیت',
            avatar: '🥋',
            avatarColor: '#10b981',
            speed: 4,
            maxHealth: 100,
            customWidth: 60,
            customHeight: 115,
            customFloorOffset: 0,
            hitboxConfig: {
              hurtboxWidthPercent: 100,
              hurtboxHeightPercent: 100,
              hurtboxOffsetX: 0,
              hurtboxOffsetY: 0,
              punchRange: 65,
              punchHeight: 50,
              punchOffsetY: 15,
              kickRange: 75,
              kickHeight: 50,
              kickOffsetY: 35,
            },
            sprites: {
              idle: [{ x: 0, y: 0, width: 55, height: 115, color: '#10b981' }],
              walk: [{ x: 0, y: 0, width: 55, height: 115, color: '#059669' }],
              jump: [{ x: 0, y: 0, width: 55, height: 105, color: '#047857' }],
              punch: [{ x: 0, y: 0, width: 75, height: 115, color: '#10b981' }],
              kick: [{ x: 0, y: 0, width: 85, height: 115, color: '#10b981' }],
              special: [{ x: 0, y: 0, width: 80, height: 115, color: '#059669' }],
              hit: [{ x: 0, y: 0, width: 55, height: 115, color: '#ef4444' }],
              block: [{ x: 0, y: 0, width: 50, height: 115, color: '#eab308' }],
              ko: [{ x: 0, y: 0, width: 115, height: 45, color: '#7f1d1d' }],
            },
            moves: [
              { id: 'punch', name: 'Punch Strike', type: 'punch', damage: 8, range: 65, cooldown: 12, duration: 12, key: 'F', isSpecial: false, color: '#10b981' },
              { id: 'kick', name: 'Kick Smash', type: 'kick', damage: 14, range: 75, cooldown: 20, duration: 16, key: 'G', isSpecial: false, color: '#eab308' },
            ],
          };

          const custom2: CharacterConfig = {
            id: 'custom_2',
            name: 'Shadow Ninja',
            nameFa: 'نینجای سایه',
            avatar: '🥷',
            avatarColor: '#a855f7',
            speed: 4.5,
            maxHealth: 90,
            customWidth: 60,
            customHeight: 115,
            customFloorOffset: 0,
            hitboxConfig: {
              hurtboxWidthPercent: 100,
              hurtboxHeightPercent: 100,
              hurtboxOffsetX: 0,
              hurtboxOffsetY: 0,
              punchRange: 60,
              punchHeight: 50,
              punchOffsetY: 15,
              kickRange: 80,
              kickHeight: 50,
              kickOffsetY: 35,
            },
            sprites: {
              idle: [{ x: 0, y: 0, width: 55, height: 115, color: '#a855f7' }],
              walk: [{ x: 0, y: 0, width: 55, height: 115, color: '#7e22ce' }],
              jump: [{ x: 0, y: 0, width: 55, height: 105, color: '#6b21a8' }],
              punch: [{ x: 0, y: 0, width: 75, height: 115, color: '#a855f7' }],
              kick: [{ x: 0, y: 0, width: 85, height: 115, color: '#a855f7' }],
              special: [{ x: 0, y: 0, width: 80, height: 115, color: '#7e22ce' }],
              hit: [{ x: 0, y: 0, width: 55, height: 115, color: '#ef4444' }],
              block: [{ x: 0, y: 0, width: 50, height: 115, color: '#eab308' }],
              ko: [{ x: 0, y: 0, width: 115, height: 45, color: '#7f1d1d' }],
            },
            moves: [
              { id: 'punch', name: 'Shadow Punch', type: 'punch', damage: 9, range: 60, cooldown: 10, duration: 10, key: 'F', isSpecial: false, color: '#a855f7' },
              { id: 'kick', name: 'Shadow Kick', type: 'kick', damage: 13, range: 80, cooldown: 18, duration: 14, key: 'G', isSpecial: false, color: '#ef4444' },
            ],
          };

          const combined = [...baseList];
          if (!combined.some(c => c.id === 'custom_1')) combined.push(custom1);
          if (!combined.some(c => c.id === 'custom_2')) combined.push(custom2);
          
          finalChars = combined;
          await retroDB.setCharacters(combined);
        }

        setCharacters(finalChars);

        // Load settings (including custom background)
        const savedSettings = await retroDB.getSettings();
        if (savedSettings) {
          setSettings(savedSettings);
        }
      } catch (e) {
        console.error('Failed to load data from IndexedDB:', e);
      } finally {
        setIsLoading(false);
      }
    }
    loadData();
  }, []);

  // Save to database when characters change
  useEffect(() => {
    if (isLoading) return; // Prevent overwriting with default on startup
    
    async function saveCharacters() {
      try {
        await retroDB.setCharacters(characters);
        // Try writing to localStorage too, but fail silently if quota exceeded
        try {
          localStorage.setItem('retro_fighter_characters', JSON.stringify(characters));
        } catch (_) {}
      } catch (e) {
        console.error('Failed to save characters to IndexedDB:', e);
      }
    }
    saveCharacters();
  }, [characters, isLoading]);

  // Save to database when settings change
  useEffect(() => {
    if (isLoading) return; // Prevent overwriting with default on startup
    
    async function saveSettings() {
      try {
        await retroDB.setSettings(settings);
      } catch (e) {
        console.error('Failed to save settings to IndexedDB:', e);
      }
    }
    saveSettings();
  }, [settings, isLoading]);

  const [gameStage, setGameStage] = useState<'select' | 'battle' | 'results'>('select');
  const [isVsAi, setIsVsAi] = useState(true);
  const [isPaused, setIsPaused] = useState(false);

  // Active Battle players
  const [p1Char, setP1Char] = useState<CharacterConfig>(defaultCharacters[0]);
  const [p2Char, setP2Char] = useState<CharacterConfig>(defaultCharacters[0]);

  // Battle statistics
  const [winner, setWinner] = useState<string>('');
  const [isPerfect, setIsPerfect] = useState(false);

  // Start Battle handler
  const handleStartGame = (
    selectedP1: CharacterConfig,
    selectedP2: CharacterConfig,
    vsAi: boolean,
    updatedSettings: GameSettings
  ) => {
    setP1Char(selectedP1);
    setP2Char(selectedP2);
    setIsVsAi(vsAi);
    setSettings(updatedSettings);
    setGameStage('battle');
    setIsPaused(false);
  };

  // Handle battle completed
  const handleGameEnd = (winnerName: string, perfect: boolean) => {
    setWinner(winnerName);
    setIsPerfect(perfect);
    setGameStage('results');
  };

  // Rematch action
  const handleRematch = () => {
    setGameStage('battle');
    setIsPaused(false);
    audioSynth.playAnnouncer('fight');
  };

  // Back to character select screen
  const handleBackToSelect = () => {
    setGameStage('select');
    audioSynth.playAnnouncer('select');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col items-center justify-start p-4 sm:p-6 select-none relative overflow-x-hidden font-sans">
      
      {/* GLOWING AMBIENT BACKGROUNDS */}
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-cyan-500/10 rounded-full filter blur-[120px] pointer-events-none" />
      <div className="absolute bottom-10 right-1/4 w-96 h-96 bg-purple-500/10 rounded-full filter blur-[120px] pointer-events-none" />

      {/* ARCADE HEADER */}
      <header className="w-full max-w-5xl flex flex-col sm:flex-row items-center justify-between gap-4 mb-6 z-10 border-b border-slate-900 pb-4">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-xl shadow-lg shadow-orange-500/20">
            <Swords className="w-6 h-6 text-slate-950" />
          </div>
          <div className="text-right sm:text-left">
            <h1 className="text-2xl sm:text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 via-orange-500 to-cyan-400 uppercase tracking-wider font-mono">
              2D RETRO FIGHTER
            </h1>
            <p className="text-xs text-slate-400 mt-0.5 font-mono">STREET FIGHTER CLONE & CUSTOMIZER</p>
          </div>
        </div>

        {/* Quick info panel */}
        <div className="flex items-center gap-4 text-xs font-mono bg-slate-900/60 px-4 py-2 rounded-xl border border-slate-800">
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span className="text-slate-400">موتور بازی آماده است (Active)</span>
          </div>
          <span className="text-slate-700">|</span>
          <span className="text-yellow-400">v2.4 LTS</span>
        </div>
      </header>

      <main className="w-full max-w-5xl flex flex-col gap-6 z-10 flex-1">
        
        {/* TAB 1: CHARACTER SELECTION AND PREPARATIONS */}
        {gameStage === 'select' && (
          <div className="flex flex-col gap-6 animate-fade-in">
            {/* Fighter selection card */}
            <CharacterSelect
              characters={characters}
              onStartGame={handleStartGame}
              settings={settings}
              onUpdateSettings={setSettings}
            />

            {/* Asset customization card (The user's specific answers panel) */}
            <AssetManager
              characters={characters}
              onUpdateCharacters={setCharacters}
              settings={settings}
              onUpdateSettings={setSettings}
            />
          </div>
        )}

        {/* TAB 2: FIGHT ENVIRONMENT */}
        {gameStage === 'battle' && (
          <div className="flex flex-col gap-4 animate-scale-up">
            {/* Control panel above battle */}
            <div className="flex justify-between items-center bg-slate-900/60 p-3 rounded-xl border border-slate-800 px-5">
              <button
                onClick={handleBackToSelect}
                className="flex items-center gap-2 text-xs font-bold text-slate-400 hover:text-white transition bg-slate-950 border border-slate-800 px-3 py-1.5 rounded-lg active:scale-95"
              >
                <Undo2 className="w-3.5 h-3.5" />
                <span>بازگشت به منو (Quit Match)</span>
              </button>

              <div className="flex items-center gap-3">
                <button
                  onClick={() => setSettings({ ...settings, showHitboxes: !settings.showHitboxes })}
                  className={`border px-3 py-1.5 rounded-lg text-xs font-bold transition active:scale-95 flex items-center gap-1.5 ${
                    settings.showHitboxes 
                      ? 'bg-emerald-950/40 border-emerald-500 text-emerald-400' 
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  <span className={`w-2 h-2 rounded-full ${settings.showHitboxes ? 'bg-emerald-400 animate-pulse' : 'bg-slate-600'}`} />
                  <span>نمایش هیت‌باکس‌ها ({settings.showHitboxes ? 'روشن' : 'خاموش'})</span>
                </button>

                <button
                  onClick={() => setIsPaused(!isPaused)}
                  className="bg-slate-950 border border-slate-800 text-yellow-400 font-bold px-4 py-1.5 rounded-lg text-xs hover:bg-slate-800 transition active:scale-95"
                >
                  {isPaused ? 'ادامه نبرد' : 'توقف موقت (Pause)'}
                </button>
              </div>
            </div>

            {/* Core HTML5 Physics Canvas */}
            <GameCanvas
              player1Char={p1Char}
              player2Char={p2Char}
              isVsAi={isVsAi}
              settings={settings}
              onGameEnd={handleGameEnd}
              isPaused={isPaused}
              onTogglePause={() => setIsPaused(!isPaused)}
            />
          </div>
        )}

        {/* TAB 3: GAME OVER / MATCH RESULTS */}
        {gameStage === 'results' && (
          <div className="max-w-md w-full mx-auto bg-slate-900/90 border-4 border-yellow-500 rounded-3xl p-8 flex flex-col items-center text-center shadow-2xl relative overflow-hidden animate-bounce-in mt-10">
            <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-yellow-400 via-orange-500 to-red-600" />
            
            {/* Victory Badge */}
            <div className="p-4 bg-yellow-500/10 border border-yellow-500/20 rounded-full mb-4 text-yellow-400 shadow-inner">
              <Award className="w-12 h-12" />
            </div>

            <span className="text-xs font-mono text-yellow-400 tracking-widest uppercase">MATCH OVER / پایان مبارزه</span>
            <h2 className="text-4xl font-black text-white mt-1 uppercase tracking-wide">
              {winner} {winner === 'AI' ? 'برد!' : 'برنده شد!'}
            </h2>

            {isPerfect && (
              <div className="mt-2 bg-emerald-950/40 border border-emerald-500/20 px-4 py-1 rounded-full text-emerald-400 font-bold text-xs animate-pulse">
                🏆 پیروزی بی‌نقص (PERFECT KO)!
              </div>
            )}

            {/* Quick stats list */}
            <div className="w-full bg-slate-950/60 rounded-2xl p-4 mt-6 border border-slate-800/80 flex flex-col gap-2.5 text-xs text-right" dir="rtl">
              <div className="flex justify-between items-center text-slate-400">
                <span>قهرمان رینگ مبارزه:</span>
                <span className="text-white font-bold">{winner === 'Player 1' ? p1Char.nameFa : p2Char.nameFa}</span>
              </div>
              <div className="flex justify-between items-center text-slate-400">
                <span>زمان باقی‌مانده نبرد:</span>
                <span className="text-yellow-400 font-mono font-bold">بخش ثانیه‌شمار فعال</span>
              </div>
              <div className="flex justify-between items-center text-slate-400">
                <span>حالت حریف روبه‌رو:</span>
                <span className="text-white">{isVsAi ? 'هوش مصنوعی (AI)' : 'دو نفره محلی'}</span>
              </div>
            </div>

            {/* Menu Buttons */}
            <div className="flex flex-col gap-3 w-full mt-8">
              <button
                onClick={handleRematch}
                className="w-full bg-gradient-to-r from-yellow-400 to-amber-500 text-slate-950 font-black py-3.5 rounded-xl hover:brightness-110 active:scale-95 transition text-sm flex items-center justify-center gap-2"
              >
                <RefreshCw className="w-4 h-4" />
                <span>مبارزه مجدد (Rematch Battle)</span>
              </button>
              <button
                onClick={handleBackToSelect}
                className="w-full bg-slate-800 hover:bg-slate-700 text-white font-bold py-3 rounded-xl transition text-sm active:scale-95 border border-slate-700"
              >
                انتخاب کارکتر جدید (Main Menu)
              </button>
            </div>
          </div>
        )}

      </main>

      {/* FOOTER */}
      <footer className="w-full max-w-5xl text-center text-slate-600 text-[11px] font-mono mt-12 border-t border-slate-900/40 pt-4 flex flex-col sm:flex-row items-center justify-between gap-3">
        <p dir="rtl">طراحی شده برای علاقمندان سبک مبارزه‌ای نوستالژیک | دکمه ESC بازی را متوقف می‌کند</p>
        <p>© 2026 Retro 2D Combat Engine. All Rights Reserved.</p>
      </footer>
    </div>
  );
}
