/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

class RetroAudioSynth {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private volume: number = 0.4;
  private isMuted: boolean = false;

  private init() {
    if (this.ctx) return;
    try {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      this.ctx = new AudioContextClass();
      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.setValueAtTime(this.volume, this.ctx.currentTime);
      this.masterGain.connect(this.ctx.destination);
    } catch (e) {
      console.warn("Web Audio API not supported", e);
    }
  }

  setVolume(vol: number) {
    this.volume = Math.max(0, Math.min(1, vol));
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setValueAtTime(this.isMuted ? 0 : this.volume, this.ctx.currentTime);
    }
  }

  toggleMute() {
    this.isMuted = !this.isMuted;
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setValueAtTime(this.isMuted ? 0 : this.volume, this.ctx.currentTime);
    }
    return this.isMuted;
  }

  getMuteState() {
    return this.isMuted;
  }

  playPunch() {
    this.init();
    if (!this.ctx || !this.masterGain || this.isMuted) return;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(150, this.ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(10, this.ctx.currentTime + 0.15);

    gain.gain.setValueAtTime(0.8, this.ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.01, this.ctx.currentTime + 0.15);

    osc.connect(gain);
    gain.connect(this.masterGain);

    osc.start();
    osc.stop(this.ctx.currentTime + 0.15);
  }

  playKick() {
    this.init();
    if (!this.ctx || !this.masterGain || this.isMuted) return;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    
    osc.type = 'sine';
    osc.frequency.setValueAtTime(100, this.ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(5, this.ctx.currentTime + 0.22);

    gain.gain.setValueAtTime(1.0, this.ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.01, this.ctx.currentTime + 0.22);

    osc.connect(gain);
    gain.connect(this.masterGain);

    osc.start();
    osc.stop(this.ctx.currentTime + 0.22);

    // Add some white noise burst for kick texture
    this.playNoise(0.06, 0.5, 400);
  }

  playHit() {
    this.init();
    if (!this.ctx || !this.masterGain || this.isMuted) return;

    this.playNoise(0.12, 0.8, 1200);
    
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(220, this.ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(60, this.ctx.currentTime + 0.1);
    gain.gain.setValueAtTime(0.4, this.ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.01, this.ctx.currentTime + 0.1);
    
    osc.connect(gain);
    gain.connect(this.masterGain);
    osc.start();
    osc.stop(this.ctx.currentTime + 0.1);
  }

  playBlock() {
    this.init();
    if (!this.ctx || !this.masterGain || this.isMuted) return;

    const osc = this.ctx.createOscillator();
    const osc2 = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'triangle';
    osc.frequency.setValueAtTime(600, this.ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(300, this.ctx.currentTime + 0.08);

    osc2.type = 'sine';
    osc2.frequency.setValueAtTime(850, this.ctx.currentTime);
    osc2.frequency.exponentialRampToValueAtTime(450, this.ctx.currentTime + 0.08);

    gain.gain.setValueAtTime(0.5, this.ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.01, this.ctx.currentTime + 0.08);

    osc.connect(gain);
    osc2.connect(gain);
    gain.connect(this.masterGain);

    osc.start();
    osc2.start();
    osc.stop(this.ctx.currentTime + 0.08);
    osc2.stop(this.ctx.currentTime + 0.08);
  }

  playFireball() {
    this.init();
    if (!this.ctx || !this.masterGain || this.isMuted) return;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(120, this.ctx.currentTime);
    osc.frequency.linearRampToValueAtTime(400, this.ctx.currentTime + 0.25);
    osc.frequency.exponentialRampToValueAtTime(80, this.ctx.currentTime + 0.45);

    gain.gain.setValueAtTime(0.6, this.ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.01, this.ctx.currentTime + 0.45);

    osc.connect(gain);
    gain.connect(this.masterGain);

    osc.start();
    osc.stop(this.ctx.currentTime + 0.45);

    // Resonant noise wave
    this.playNoise(0.4, 0.4, 800, true);
  }

  playAnnouncer(type: 'round1' | 'fight' | 'ko' | 'perfect' | 'select' | 'start') {
    this.init();
    if (!this.ctx || !this.masterGain || this.isMuted) return;

    const now = this.ctx.currentTime;
    const gain = this.ctx.createGain();
    gain.connect(this.masterGain);

    const playTone = (freq: number, duration: number, delay: number = 0, oscType: OscillatorType = 'triangle') => {
      if (!this.ctx || !this.masterGain) return;
      const osc = this.ctx.createOscillator();
      const localGain = this.ctx.createGain();
      
      osc.type = oscType;
      osc.frequency.setValueAtTime(freq, now + delay);
      
      localGain.gain.setValueAtTime(0.4, now + delay);
      localGain.gain.exponentialRampToValueAtTime(0.001, now + delay + duration);
      
      osc.connect(localGain);
      localGain.connect(gain);
      osc.start(now + delay);
      osc.stop(now + delay + duration);
    };

    switch (type) {
      case 'start':
        playTone(330, 0.1, 0, 'sine');
        playTone(392, 0.1, 0.1, 'sine');
        playTone(659, 0.3, 0.2, 'sine');
        break;
      case 'select':
        playTone(440, 0.08, 0, 'square');
        playTone(554, 0.15, 0.08, 'square');
        break;
      case 'round1':
        // Deep announcement pitch sweep
        playTone(180, 0.15, 0, 'sawtooth');
        playTone(150, 0.3, 0.15, 'sawtooth');
        break;
      case 'fight':
        // High energy metallic clash
        playTone(440, 0.1, 0, 'square');
        playTone(330, 0.1, 0.05, 'square');
        playTone(660, 0.4, 0.1, 'sawtooth');
        this.playNoise(0.3, 0.6, 2000);
        break;
      case 'ko':
        // Epic double drop tone
        playTone(300, 0.2, 0, 'sawtooth');
        playTone(200, 0.5, 0.2, 'sawtooth');
        playTone(100, 0.8, 0.6, 'sawtooth');
        break;
      case 'perfect':
        playTone(523, 0.1, 0, 'sine');
        playTone(659, 0.1, 0.1, 'sine');
        playTone(784, 0.15, 0.2, 'sine');
        playTone(1046, 0.4, 0.35, 'sine');
        break;
    }
  }

  private playNoise(duration: number, volume: number, filterFreq: number, sweep: boolean = false) {
    if (!this.ctx || !this.masterGain) return;

    const bufferSize = this.ctx.sampleRate * duration;
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);

    for (let i = 0; i < bufferSize; i++) {
      data[i] = Math.random() * 2 - 1;
    }

    const noise = this.ctx.createBufferSource();
    noise.buffer = buffer;

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(filterFreq, this.ctx.currentTime);
    if (sweep) {
      filter.frequency.exponentialRampToValueAtTime(100, this.ctx.currentTime + duration);
    }

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(volume, this.ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.01, this.ctx.currentTime + duration);

    noise.connect(filter);
    filter.connect(gain);
    gain.connect(this.masterGain);

    noise.start();
    noise.stop(this.ctx.currentTime + duration);
  }
}

export const audioSynth = new RetroAudioSynth();
export default audioSynth;
