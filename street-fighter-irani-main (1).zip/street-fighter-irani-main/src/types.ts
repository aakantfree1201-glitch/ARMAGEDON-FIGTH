/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Move {
  id: string;
  name: string;
  type: 'punch' | 'kick' | 'special' | 'projectile';
  damage: number;
  range: number;
  cooldown: number; // in frames
  duration: number; // animation duration in frames
  key: string;      // key trigger
  isSpecial: boolean;
  color: string;
}

export interface SpriteFrame {
  x: number;
  y: number;
  width: number;
  height: number;
  url?: string; // If using image spritesheet
  color?: string; // Fallback color block if no sprite loaded
}

export interface HitboxConfig {
  hurtboxWidthPercent: number; // e.g. 100 for 100%
  hurtboxHeightPercent: number; // e.g. 100 for 100%
  hurtboxOffsetX: number;
  hurtboxOffsetY: number;
  punchRange: number;
  punchHeight: number;
  punchOffsetY: number;
  kickRange: number;
  kickHeight: number;
  kickOffsetY: number;
}

export interface CharacterConfig {
  id: string;
  name: string;
  nameFa: string;
  avatar: string;
  avatarColor: string;
  speed: number;
  maxHealth: number;
  customWidth?: number;
  customHeight?: number;
  customFloorOffset?: number;
  hitboxConfig?: HitboxConfig;
  menuPortrait?: string;
  customSprites?: {
    idle?: string | string[];
    walk?: string | string[];
    jump?: string | string[];
    punch?: string | string[];
    kick?: string | string[];
    special?: string | string[];
    hit?: string | string[];
    block?: string | string[];
    ko?: string | string[];
  };
  sprites: {
    idle: SpriteFrame[];
    walk: SpriteFrame[];
    jump: SpriteFrame[];
    punch: SpriteFrame[];
    kick: SpriteFrame[];
    special: SpriteFrame[];
    hit: SpriteFrame[];
    ko: SpriteFrame[];
    block: SpriteFrame[];
  };
  moves: Move[];
}

export interface Projectile {
  id: string;
  ownerId: string;
  x: number;
  y: number;
  width: number;
  height: number;
  speedX: number;
  damage: number;
  color: string;
  animationFrame: number;
}

export interface FighterState {
  id: string;
  name: string;
  x: number;
  y: number;
  width: number;
  height: number;
  velocityX: number;
  velocityY: number;
  isJumping: boolean;
  isCrouching: boolean;
  isBlocking: boolean;
  direction: 1 | -1; // 1 = facing right, -1 = facing left
  health: number;
  maxHealth: number;
  energy: number; // for special moves
  currentState: 'idle' | 'walk' | 'jump' | 'punch' | 'kick' | 'special' | 'hit' | 'block' | 'ko';
  currentFrame: number;
  stateTimer: number; // duration of current state action
  comboCount: number;
  comboTimer: number;
  blockFrames?: number;
  jumpTicks?: number;
}

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  color: string;
  size: number;
  life: number; // 0 to 1
  decay: number;
  type: 'spark' | 'dust' | 'fire' | 'energy' | 'star';
}

export interface GameSettings {
  roundDuration: number; // in seconds
  roundsToWin: number;
  soundVolume: number;
  bgUrl: string;
  useCustomBg: boolean;
  aiDifficulty: 'easy' | 'medium' | 'hard' | 'impossible' | 'practice';
  showHitboxes?: boolean;
}
