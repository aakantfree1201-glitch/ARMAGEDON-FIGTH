/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { CharacterConfig, Move } from './types';

// Default moves list for Cyber Fighter
const cyberMoves: Move[] = [
  { id: 'punch', name: 'Punch Strike', type: 'punch', damage: 8, range: 65, cooldown: 12, duration: 12, key: 'F', isSpecial: false, color: '#06b6d4' },
  { id: 'kick', name: 'Kick Smash', type: 'kick', damage: 14, range: 75, cooldown: 20, duration: 16, key: 'G', isSpecial: false, color: '#eab308' },
];

// Default moves list for Blaze Fighter
const blazeMoves: Move[] = [
  { id: 'punch', name: 'Blaze Punch', type: 'punch', damage: 10, range: 60, cooldown: 10, duration: 10, key: 'F', isSpecial: false, color: '#ea580c' },
  { id: 'kick', name: 'Fire Kick', type: 'kick', damage: 15, range: 80, cooldown: 22, duration: 18, key: 'G', isSpecial: false, color: '#ef4444' },
];

// Helper to generate default empty/fallback sprites for Canvas drawing
const createFallbackSprite = (width = 50, height = 110, color = '#ff3366') => [
  { x: 0, y: 0, width, height, color }
];

// Beautiful self-contained SVG Fighter sprite generator
const getFighterSvg = (type: 'cyber' | 'blaze', state: string, frame: number): string => {
  const glowId = `glow-${type}-${state}-${frame}`;
  const armorGradId = `armor-${type}-${state}-${frame}`;
  
  // Dynamic color palette based on character type
  const isCyber = type === 'cyber';
  const cPrimary = isCyber ? '#06b6d4' : '#f97316';   // Cyan vs Orange
  const cSecondary = isCyber ? '#0891b2' : '#ea580c'; // Cyan dark vs Orange dark
  const cGlow = isCyber ? '#22d3ee' : '#facc15';      // Cyan glow vs Yellow glow
  const cVisor = isCyber ? '#22d3ee' : '#ef4444';     // Cyan visor vs Red visor
  const cScarf = isCyber ? '#06b6d4' : '#ef4444';     // Cyan scarf vs Red scarf
  const cBooster = isCyber ? '#22d3ee' : '#f97316';   // Cyan booster vs Orange booster
  const cSpark = isCyber ? '#22d3ee' : '#facc15';     // Cyan spark vs Yellow spark
  const cBlade = isCyber ? 'rgba(34,211,238,0.7)' : 'rgba(239,68,68,0.7)'; // Laser blue vs Laser red
  
  let content = '';
  
  if (state === 'idle') {
    const bob = frame === 1 ? 4 : 0;
    content = `
      <!-- Shadow -->
      <ellipse cx="75" cy="130" rx="32" ry="7" fill="rgba(0,0,0,0.4)" />
      <!-- Back Arm -->
      <path d="M55,${60+bob} L35,${75+bob} L40,${85+bob}" fill="none" stroke="${isCyber ? '#083344' : '#431407'}" stroke-width="8" stroke-linecap="round" />
      <!-- Back Leg -->
      <path d="M62,100 L50,118 L42,126" fill="none" stroke="#0f172a" stroke-width="9" stroke-linecap="round" />
      <!-- Front Leg -->
      <path d="M88,100 L100,120 L110,126" fill="none" stroke="#1e293b" stroke-width="9" stroke-linecap="round" />
      <!-- Body Torso -->
      <rect x="55" y="${55+bob}" width="40" height="48" rx="8" fill="url(#${armorGradId})" stroke="${cSecondary}" stroke-width="3" />
      <circle cx="75" cy="${70+bob}" r="6" fill="#ffffff" filter="url(#${glowId})" />
      <!-- Head / Helmet -->
      <circle cx="75" cy="${35+bob}" r="17" fill="#0f172a" stroke="${cSecondary}" stroke-width="2.5" />
      <rect x="63" y="${28+bob}" width="24" height="5" rx="2.5" fill="${cVisor}" filter="url(#${glowId})" />
      <!-- Scarf -->
      <path d="M59,${35+bob} Q40,${30+bob} 25,${45+bob}" fill="none" stroke="${cScarf}" stroke-width="4.5" stroke-linecap="round" />
      <!-- Front Arm -->
      <path d="M95,${60+bob} L112,${76+bob} L108,${88+bob}" fill="none" stroke="${isCyber ? '#0e7490' : '#c2410c'}" stroke-width="8.5" stroke-linecap="round" />
      <circle cx="108" cy="${88+bob}" r="5" fill="${cGlow}" filter="url(#${glowId})" />
    `;
  } else if (state === 'jump') {
    content = `
      <!-- Booster Thruster Flame -->
      <path d="M50,115 L40,138 L60,115" fill="${cBooster}" filter="url(#${glowId})" />
      <path d="M75,115 L85,138 L65,115" fill="${cBooster}" filter="url(#${glowId})" />
      <!-- Back Leg -->
      <path d="M55,90 L40,115" fill="none" stroke="#0f172a" stroke-width="9" stroke-linecap="round" />
      <!-- Front Leg -->
      <path d="M80,90 L70,115" fill="none" stroke="#1e293b" stroke-width="9" stroke-linecap="round" />
      <!-- Torso -->
      <rect x="52" y="40" width="40" height="46" rx="8" fill="url(#${armorGradId})" stroke="${cSecondary}" stroke-width="3" />
      <circle cx="72" cy="55" r="5" fill="#ffffff" filter="url(#${glowId})" />
      <!-- Head -->
      <circle cx="72" cy="22" r="15" fill="#0f172a" stroke="${cSecondary}" stroke-width="2.5" />
      <rect x="62" y="16" width="20" height="4.5" rx="2" fill="${cVisor}" filter="url(#${glowId})" />
      <!-- Front Arm -->
      <path d="M90,45 L110,65 L98,75" fill="none" stroke="${isCyber ? '#0e7490' : '#c2410c'}" stroke-width="8.5" stroke-linecap="round" />
      <circle cx="98" cy="75" r="5" fill="${cGlow}" filter="url(#${glowId})" />
    `;
  } else if (state === 'punch') {
    const ext = frame === 1 ? 15 : frame === 2 ? 35 : frame === 3 ? 10 : 0;
    content = `
      <!-- Shadow -->
      <ellipse cx="70" cy="130" rx="35" ry="7" fill="rgba(0,0,0,0.4)" />
      <!-- Back Arm -->
      <path d="M55,60 L30,50 L40,40" fill="none" stroke="${isCyber ? '#083344' : '#431407'}" stroke-width="8" stroke-linecap="round" />
      <!-- Legs -->
      <path d="M60,100 L45,125 L35,127" fill="none" stroke="#0f172a" stroke-width="9" stroke-linecap="round" />
      <path d="M85,100 L102,125 L112,127" fill="none" stroke="#1e293b" stroke-width="9" stroke-linecap="round" />
      <!-- Torso -->
      <rect x="50" y="55" width="42" height="48" rx="8" fill="url(#${armorGradId})" stroke="${cSecondary}" stroke-width="3" />
      <circle cx="70" cy="70" r="6" fill="#ffffff" filter="url(#${glowId})" />
      <!-- Head -->
      <circle cx="70" cy="35" r="17" fill="#0f172a" stroke="${cSecondary}" stroke-width="2.5" />
      <rect x="58" y="28" width="24" height="5" rx="2.5" fill="${cVisor}" filter="url(#${glowId})" />
      <!-- Front Punching Arm -->
      <path d="M90,60 L${105+ext/2},${55-ext/8} L${110+ext},${55}" fill="none" stroke="${isCyber ? '#0e7490' : '#c2410c'}" stroke-width="9" stroke-linecap="round" />
      <circle cx="${110+ext}" cy="55" r="${6+ext/15}" fill="#ffffff" stroke="${cGlow}" stroke-width="2" filter="url(#${glowId})" />
      ${ext > 20 ? `
        <!-- Electric / Fire sparks -->
        <path d="M145,45 L155,52 L148,60" fill="none" stroke="${cSpark}" stroke-width="2.5" />
        <circle cx="155" cy="40" r="2" fill="#fff" filter="url(#${glowId})" />
      ` : ''}
    `;
  } else if (state === 'kick') {
    const ext = frame === 1 ? 15 : frame === 2 ? 40 : frame === 3 ? 20 : 0;
    content = `
      <!-- Shadow -->
      <ellipse cx="65" cy="130" rx="30" ry="7" fill="rgba(0,0,0,0.4)" />
      <!-- Back Arm -->
      <path d="M50,60 L30,70" fill="none" stroke="${isCyber ? '#083344' : '#431407'}" stroke-width="8" stroke-linecap="round" />
      <!-- Standing Leg -->
      <path d="M60,100 L50,128 L40,128" fill="none" stroke="#0f172a" stroke-width="10" stroke-linecap="round" />
      <!-- Torso -->
      <rect x="45" y="55" width="40" height="48" rx="8" fill="url(#${armorGradId})" stroke="${cSecondary}" stroke-width="3" />
      <!-- Head -->
      <circle cx="65" cy="35" r="17" fill="#0f172a" stroke="${cSecondary}" stroke-width="2.5" />
      <rect x="53" y="28" width="24" height="5" rx="2.5" fill="${cVisor}" filter="url(#${glowId})" />
      <!-- Front Kicking Leg -->
      <path d="M80,95 L${90+ext/2},${95-ext/4} L${100+ext},${95-ext/2}" fill="none" stroke="${isCyber ? '#0e7490' : '#c2410c'}" stroke-width="10" stroke-linecap="round" />
      <rect x="${95+ext}" y="${88-ext/2}" width="15" height="12" rx="3" fill="${cGlow}" filter="url(#${glowId})" />
      ${ext > 25 ? `
        <!-- Cyber Laser/Fiery Blade outline -->
        <path d="M100,50 Q130,65 112,100" fill="none" stroke="${cBlade}" stroke-width="5" stroke-linecap="round" filter="url(#${glowId})" />
      ` : ''}
    `;
  } else if (state === 'block') {
    content = `
      <!-- Shadow -->
      <ellipse cx="75" cy="130" rx="28" ry="6.5" fill="rgba(0,0,0,0.4)" />
      <!-- Back Leg -->
      <path d="M65,100 L50,125" fill="none" stroke="#0f172a" stroke-width="9" stroke-linecap="round" />
      <!-- Front Leg -->
      <path d="M80,100 L95,125" fill="none" stroke="#1e293b" stroke-width="9" stroke-linecap="round" />
      <!-- Torso (huddled) -->
      <rect x="55" y="60" width="38" height="46" rx="8" fill="url(#${armorGradId})" stroke="${cSecondary}" stroke-width="3" />
      <!-- Head (tucked down) -->
      <circle cx="70" cy="42" r="16" fill="#0f172a" stroke="${cSecondary}" stroke-width="2.5" />
      <rect x="58" y="36" width="20" height="5" rx="2.5" fill="${cVisor}" filter="url(#${glowId})" />
      <!-- Crossing Guards -->
      <path d="M85,70 L102,65" fill="none" stroke="${isCyber ? '#0e7490' : '#c2410c'}" stroke-width="9.5" stroke-linecap="round" />
      <path d="M85,80 L102,75" fill="none" stroke="${isCyber ? '#083344' : '#431407'}" stroke-width="9.5" stroke-linecap="round" />
      <!-- Energy Shield Shield! -->
      <path d="M112,40 Q125,75 112,110" fill="none" stroke="${cBlade}" stroke-width="6" stroke-linecap="round" filter="url(#${glowId})" />
    `;
  } else {
    content = `
      <circle cx="75" cy="70" r="25" fill="url(#${armorGradId})" />
    `;
  }

  return `
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 150 140">
      <defs>
        <linearGradient id="${armorGradId}" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stop-color="${cPrimary}" />
          <stop offset="100%" stop-color="${cSecondary}" />
        </linearGradient>
        <filter id="${glowId}" x="-30%" y="-30%" width="160%" height="160%">
          <feGaussianBlur stdDeviation="3.5" result="blur" />
          <feComposite in="SourceGraphic" in2="blur" operator="over" />
        </filter>
      </defs>
      ${content}
    </svg>
  `;
};

const getFighterDataUrl = (type: 'cyber' | 'blaze', state: string, frame: number): string => {
  const svg = getFighterSvg(type, state, frame);
  return `data:image/svg+xml;utf8,${encodeURIComponent(svg.trim())}`;
};

export const defaultCharacters: CharacterConfig[] = [
  {
    id: 'custom_fighter',
    name: 'Cyber Fighter',
    nameFa: 'مبارز سایبری (آبی)',
    avatar: '🤖',
    avatarColor: '#06b6d4',
    speed: 4,
    maxHealth: 100,
    customWidth: 60,
    customHeight: 115,
    hitboxConfig: {
      hurtboxWidthPercent: 100,
      hurtboxHeightPercent: 100,
      hurtboxOffsetX: 0,
      hurtboxOffsetY: 0,
      punchRange: 65,
      punchHeight: 50,
      punchOffsetY: 15,
      kickRange: 75,
      kickHeight: 50,
      kickOffsetY: 35,
    },
    customSprites: {
      idle: [
        getFighterDataUrl('cyber', 'idle', 0),
        getFighterDataUrl('cyber', 'idle', 1)
      ],
      jump: [
        getFighterDataUrl('cyber', 'jump', 0)
      ],
      punch: [
        getFighterDataUrl('cyber', 'punch', 0),
        getFighterDataUrl('cyber', 'punch', 1),
        getFighterDataUrl('cyber', 'punch', 2),
        getFighterDataUrl('cyber', 'punch', 3)
      ],
      kick: [
        getFighterDataUrl('cyber', 'kick', 0),
        getFighterDataUrl('cyber', 'kick', 1),
        getFighterDataUrl('cyber', 'kick', 2),
        getFighterDataUrl('cyber', 'kick', 3)
      ],
      block: [
        getFighterDataUrl('cyber', 'block', 0)
      ]
    },
    sprites: {
      idle: createFallbackSprite(55, 115, '#06b6d4'),
      walk: createFallbackSprite(55, 115, '#0891b2'),
      jump: createFallbackSprite(55, 105, '#0e7490'),
      punch: createFallbackSprite(75, 115, '#06b6d4'),
      kick: createFallbackSprite(85, 115, '#06b6d4'),
      special: createFallbackSprite(80, 115, '#0891b2'),
      hit: createFallbackSprite(55, 115, '#ef4444'),
      block: createFallbackSprite(50, 115, '#eab308'),
      ko: createFallbackSprite(115, 45, '#7f1d1d'),
    },
    moves: cyberMoves,
  },
  {
    id: 'blaze_fighter',
    name: 'Blaze Fighter',
    nameFa: 'مبارز آتشین (سرخ)',
    avatar: '🔥',
    avatarColor: '#f97316',
    speed: 4.6,
    maxHealth: 90,
    customWidth: 60,
    customHeight: 115,
    hitboxConfig: {
      hurtboxWidthPercent: 100,
      hurtboxHeightPercent: 100,
      hurtboxOffsetX: 0,
      hurtboxOffsetY: 0,
      punchRange: 60,
      punchHeight: 50,
      punchOffsetY: 15,
      kickRange: 80,
      kickHeight: 50,
      kickOffsetY: 35,
    },
    customSprites: {
      idle: [
        getFighterDataUrl('blaze', 'idle', 0),
        getFighterDataUrl('blaze', 'idle', 1)
      ],
      jump: [
        getFighterDataUrl('blaze', 'jump', 0)
      ],
      punch: [
        getFighterDataUrl('blaze', 'punch', 0),
        getFighterDataUrl('blaze', 'punch', 1),
        getFighterDataUrl('blaze', 'punch', 2),
        getFighterDataUrl('blaze', 'punch', 3)
      ],
      kick: [
        getFighterDataUrl('blaze', 'kick', 0),
        getFighterDataUrl('blaze', 'kick', 1),
        getFighterDataUrl('blaze', 'kick', 2),
        getFighterDataUrl('blaze', 'kick', 3)
      ],
      block: [
        getFighterDataUrl('blaze', 'block', 0)
      ]
    },
    sprites: {
      idle: createFallbackSprite(55, 115, '#f97316'),
      walk: createFallbackSprite(55, 115, '#ea580c'),
      jump: createFallbackSprite(55, 105, '#c2410c'),
      punch: createFallbackSprite(75, 115, '#f97316'),
      kick: createFallbackSprite(85, 115, '#f97316'),
      special: createFallbackSprite(80, 115, '#ea580c'),
      hit: createFallbackSprite(55, 115, '#ef4444'),
      block: createFallbackSprite(50, 115, '#eab308'),
      ko: createFallbackSprite(115, 45, '#7f1d1d'),
    },
    moves: blazeMoves,
  }
];
